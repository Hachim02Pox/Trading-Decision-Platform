# Preuves et validation — promotion éditoriale du Sunday du 27 septembre 2026

Le contenu réel original est migré au contrat v6 à la demande d’Hachim. Aucune nouvelle recherche de marché n’est revendiquée. Le cutoff reste le 27 septembre 2026 à 18:57:35.740939 UTC. Le statut de procédure est PARTIAL : les phases horodatées décrivent la revue technique des archives effectuée le 28, pas une reconstitution des phases initiales. Les sources et dates originales sont conservées. Le fichier fixture du dépôt n’a pas servi à générer cette publication.

## Contrôles effectivement exécutés

- JSON Schema v6 ; références des sources/requêtes ; 32 questions F1–F6 ; six jugements et filtres futures/CFD ; dates ; graphe sans orphelin/cycle ; parité exacte JSON/Markdown ; absence de liens techniques dans la lecture : PASS.
- Handoff v13 : schéma et continuité avec cet état : PASS local avant écriture.
- npm test et npm run validate du dépôt Brain : PASS. Ces tests ne vérifient pas le déploiement externe.
- Les huit copies Drive ont été téléchargées et comparées aux quatre originaux : SHA-256 identiques ; archivées dans Control/Gold — Archives de migration — 2026-09-28, hors ingestion.
- Réparation de cohérence explicite : spread 2s10s du lundi = 4,96 − 4,76 = 20 pb ; l’ancien texte indiquait 25 pb. Aucun autre nouveau fait de marché ajouté.
- Trace GLD directe reliée au journal JSON à partir du téléchargement réellement consigné dans la revue originale (HTTP200, heure et URL conservées).
- L’entrée de version du handoff initial sans SHA est déclarée non attestée ; aucune empreinte inventée.

## Limites de validation

La parité et les contrôles de structure ne prouvent ni la vérité économique ni la capacité prédictive. Les résultats analytiques sont ceux du cutoff historique. L’actualité lundi n’a pas été confirmée. Trading Platform ne reconnaît pas encore v6 : migration backend/frontend et validation de déploiement restent nécessaires. Aucun trigger de refresh n’est envoyé avant cette intégration.

Les quatre fichiers sont figés avant livraison. Les heures, IDs, hashes et readbacks effectivement obtenus seront attestés dans le completion record séparé Control/run_records, jamais ajoutés rétroactivement à ce rapport immuable.

## Log local

```text
  PASS  unique state identity gold-sunday-2026-09-27-editorial-v6-01

official/sunday_read_2026-09-27.json
  PASS  official/sunday_read_2026-09-27.json: editorial v6 schema
  PASS  official/sunday_read_2026-09-27.json: editorial v6 evidence, gates, continuity and reader parity

official/NEXT_GOLD_RECAP.json
  PASS  official/NEXT_GOLD_RECAP.json: validates against next_gold_recap.schema.json
  PASS  official/NEXT_GOLD_RECAP.json: editorial handoff continuity

5 checks run, 0 failed.
```

## Revue originale conservée comme pièce historique

Ce qui suit décrit l’exécution expérimentale du 27 et ses contrôles d’alors. Ses mentions « expérimental », « non destiné à la production » et « schéma non applicable » décrivent cet état antérieur ; les contrôles de migration ci-dessus gouvernent le nouveau fichier v6. Les observations, limites et sources ne sont pas présentées comme actualisées.

# Revue des preuves et contrôles — BROUILLON EXPÉRIMENTAL

**Semaine préparée : 28 septembre–2 octobre 2026.** Recherche de marché arrêtée au 27 septembre à 14:57:35 New York. Cette revue décrit les observations récupérées et les limites réelles. Elle ne certifie pas le schéma ni le rendu de production.

## Résultat de la lecture

Biais macro baissier conditionnel; asymétrie directionnelle non démontrée; asymétrie de positionnement non établie. GC/MGC short éligible au filtre fondamental; CFD aucun sens éligible. Le soutien structurel et les chemins haussiers restent explicitement vivants.

## Récupérations et arbitrages qui ont changé la qualité des preuves

- Taux: FRED s’arrêtait au jeudi pour plusieurs séries. Récupération des courbes du vendredi au Trésor, vérification de l’en-tête des colonnes et du nominal/réel de même tenor. Le vendredi n’est plus déclaré inconnu.
- GLD: page SPDR AWAITING; CSV historique non exploitable, export XLSX non accepté par le lecteur web. Le téléchargement direct State Street réussit (HTTP200, 264 789 octets). Lecture de navhist A4:D10, dates et colonnes vérifiées. Les parts quotidiennes et la variation −0,90 million sont désormais établies; la lacune restante porte sur IAU et la confirmation globale, pas GLD.
- CME: bulletin préliminaire récupéré; GC décembre et GC agrégé distingués. La hausse OI décembre +5 799 est confrontée à octobre −6 669 et total −236. Les volumes PNT et Globex ne sont pas additionnés au volume Yahoo de périmètre non réconcilié. Des requêtes de captures PDF ont été faites; elles n’ont pas fourni une inspection visuelle indépendante exploitable, donc aucune validation visuelle n’est revendiquée.
- FedWatch: 71 % dans un reportage du matin et 66 % dans une édition plus tardive concernent des heures différentes. Le rapport retient le dernier instantané pour son récit, sans moyenne et sans prétendre disposer de la grille de clôture.
- COT: futures-only Gold 088691, 100 oz, Managed Money identifié. Net = longs − shorts; variation nette = −6 695 − (−968). Legacy non-commercial et micro ne sont pas mélangés. Percentiles non calculés faute de 156 points récupérés.
- PCE: confirmé futur au mercredi 30 septembre 08:30 EDT, avec mises à jour annuelles. Aucun « PCE publié vendredi » n’est retenu. JOLTS et emploi sont vérifiés auprès du BLS.
- Adjudication: récupération du PDF officiel sept ans après page générale sans résultat. Le total avec SOMA diffère du montant hors SOMA; le dénominateur des allocations compétitives est identifié. Les tails repris dans certains commentaires ne sont pas admis sans when-issued vérifié.
- Prix: endpoints GC décembre 4 424,90 et 4 321,20, seconde observation corroborée CME. Les prix spot, LBMA PM, intraday et NYAuTN SGE ne sont pas raccordés dans une fausse série.
- Rapport antérieur: le SHA brut diffère du hash déclaré, mais la sérialisation JSON canonique (UTF-8, clés triées, séparateurs compacts) reproduit exactement le SHA du completion record. Identité sémantique vérifiée; aucune égalité brute revendiquée.
- Les sorties passées de COT/GLD sont conservées comme faits. La conclusion de positionnement antérieure n’est pas recopiée: le passage aux flux futurs reste non démontré.

## Calculs reproductibles

| Mesure | Formule / résultat |
|---|---|
| weekly_real10y_bp | 15 |
| weekly_nom10y_bp | 16 |
| weekly_us2y_bp | 5 |
| weekly_us30y_bp | 15 |
| weekly_2s10s_bp | 11 |
| friday_real10y_bp | -2 |
| weekly_gc_dec_return_pct | -2.3436 |
| friday_gc_dec_return_pct | 0.5398 |
| cot_mm_net | 127389 |
| cot_mm_net_previous | 133116 |
| cot_mm_net_delta | -5727 |
| cot_mm_net_pct_oi | 30.86 |
| gld_secondary_tonnes_change | -2.56 |
| sofr_minus_iorb_bp | -2 |
| tga_weekly_change_usd_bn | 100.056 |
| auction_indirect_share_pct | 57.197 |
| gld_weekly_shares_million | -0.9 |
| gld_weekly_shares_pct | -0.2428 |

Rendements GC: (prix final / prix initial − 1) × 100. Variations de taux: (taux final − taux initial) × 100 pb. Net COT: longs − shorts. GLD: différence de parts; aucun flux cash estimé. Part indirecte adjudication: 24 869 544 500 / 43 480 804 500 × 100.

## Contrôles réellement exécutés

- PASS — 32 questions canoniques, une fois chacune
- PASS — Six familles et six jugements distincts
- PASS — Références de preuves résolubles
- PASS — Sources datées pour toutes les réponses étayées
- PASS — Motif précis pour chaque réponse partielle/inconnue/hors périmètre
- PASS — Arbre sans référence orpheline
- PASS — Absence de cycle bear
- PASS — Absence de cycle bear_position
- PASS — Absence de cycle bear
- PASS — Absence de cycle bull_rates
- PASS — Absence de cycle bull_protection
- PASS — Absence de cycle mixed
- PASS — Absence de cycle liquidity
- PASS — Chaque nœud lisible indépendamment
- PASS — Dates semaine lundi–vendredi
- PASS — COT net et variation
- PASS — Décomposition dix ans
- PASS — GLD variation hebdomadaire
- PASS — Filtres futures et CFD conformes
- PASS — Isolation de production
- PASS — Pas de valeur inventée pour percentile/corrélation/GEX
- PASS — Calendrier postérieur au cutoff
- PASS — Parité exacte Markdown et JSON
- PASS — JSON relu après écriture

**Lecture éditoriale effectuée :** distinction observation/interprétation, explication des participants, comparaison du meilleur cas contraire, trois horizons, prix déjà intégrés, conditions de retournement, scénarios autonomes et absence de veto technique supplémentaire. Les jugements analytiques sont des interprétations conditionnelles, pas des résultats prouvés par un test logiciel.

**Non exécuté / non revendiqué :** tests de schéma de production, ingestion, rendu backend/frontend existant, certification financière, coefficient de corrélation, modèle GEX, probabilité de scénarios ou simulation de rendement. Les audits rédigés ne constituent pas une validation indépendante par un second analyste.

## Chaque manque matériel, précisément

### F1_FED_PRICING — PARTIAL

**Mesure / date :** Probabilités CME par fourchette pour octobre, clôtures 18 et 21–25 septembre; fenêtres des publications

**Obstacle :** Grille dynamique sans cellules numériques; relais Reuters horodatés mais non clôtures synchronisées

**Conséquence :** Limite la mesure du potentiel de surprise; ne supprime pas le signal direct des taux réels.

**Prochaine action :** Exporter la grille CME et ses historiques datés; conserver instrument, heure et distribution complète.

- Tentative web4, terminée à 2026-09-27T18:48:09.007Z UTC. URL: https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a.htm; https://fred.stlouisfed.org/series/DGS2; https://fred.stlouisfed.org/series/DGS10; https://fred.stlouisfed.org/series/DGS30; https://fred.stlouisfed.org/series/T10YIE; https://www.cmegroup.com/markets/metals/precious/gold.volume.html; https://www.spdrgoldshares.com/usa/historical-data/
- Tentative web5, terminée à 2026-09-27T18:48:39.161Z UTC. URL: https://home.treasury.gov/resource-center-data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve&field_tdr_date_value=2026; https://home.treasury.gov/resource-center-data-chart-center/interest-rates/TextView?type=daily_treasury_real_yield_curve&field_tdr_date_value=2026; https://www.spdrgoldshares.com/assets/dynamic/GLD/GLD_US_archive_EN.csv; https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund
- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm

### F2_EVENT_DYNAMICS — PARTIAL

**Mesure / date :** Taux, dollar et GCZ26 avant/après PMI et adjudications, mêmes minutes les 23–24 septembre

**Obstacle :** Seules observations quotidiennes et reportages intraday non synchronisés obtenus

**Conséquence :** Confiance moindre dans l’attribution de la variation à chaque événement, pas dans la variation elle-même.

**Prochaine action :** Récupérer séries intraday datées, fenêtres pré/post et contrôle des annonces simultanées.

- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm
- Tentative web17, terminée à 2026-09-27T18:54:45.182Z UTC. URL: https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://www.sca.isr.umich.edu/; https://www.newyorkfed.org/markets/reference-rates/sofr; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://www.etf.com/sections/daily-etf-flows; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf
- Tentative web21, terminée à 2026-09-27T18:56:02.177Z UTC. URL: https://www.treasurydirect.gov/instit/annceresult/press/preanre/2026/R_20260924_3.pdf; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf

### F2_MOVE — PARTIAL

**Mesure / date :** MOVE ICE BofA, clôtures 18 et 21–25 septembre

**Obstacle :** Yahoo historique en erreur; recherches donnent pourcentages de fenêtres différentes et aucune série primaire exploitable

**Conséquence :** Impossible de quantifier le choc de volatilité ou de confirmer un désendettement mécanique.

**Prochaine action :** Obtenir série ICE/licenciée datée; confronter à financement, marges et positions.

- Tentative web12, terminée à 2026-09-27T18:53:19.942Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.tbsnews.net/worldbiz/middle-east/iran-insists-diplomatic-solution-after-trump-rejects-peace-plan-1554716; https://www.24k99.com/data/etf; https://www.gold.org/goldhub/research/gold-etfs-holdings-and-flows/2026/09; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://en.sge.com.cn/data_CashSettlement/10002702
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows
- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september

### F3_DXY — PARTIAL

**Mesure / date :** DXY cinq clôtures 21–25 septembre, baseline 18 et contrôle dollar large

**Obstacle :** Historique Yahoo DX-Y.NYB non récupéré; instantanés Reuters et devises disponibles, pas série close-to-close

**Conséquence :** Ne permet pas un rendement hebdomadaire DXY précis ni une confirmation de force universelle.

**Prochaine action :** Récupérer clôtures ICE et indice broad dollar de même fenêtre.

- Tentative web11, terminée à 2026-09-27T18:53:05.471Z UTC. Recherche ciblée: requête exacte consignée au journal.
- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows

### F3_GOLD_DXY_30D — UNKNOWN

**Mesure / date :** Corrélation Pearson des rendements quotidiens GC décembre et DXY, 30 séances communes au 25 septembre

**Obstacle :** Historique Gold partiellement indexé; DXY non extrait; API Yahoo HTTP429; changements de contrat et fixings à contrôler

**Conséquence :** La relation USD n’est pas une confirmation statistique autonome.

**Prochaine action :** Obtenir 31 niveaux alignés; calculer 30 rendements, contrôler calendrier et contrat, publier méthode et dates.

- Tentative web13, terminée à 2026-09-27T18:53:30.315Z UTC. URL: https://finance.yahoo.com/quote/GC%3DF/history/?frequency=1d; https://www.gold.org/goldhub/gold-focus/2026/09/central-bank-gold-statistics-central-banks-make-positive-headlines-gold; https://www.gold.org/goldhub/data/gold-premium; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows
- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september

### F3_USD_LIQUIDITY — PARTIAL

**Mesure / date :** Funding complet au 25: SOFR distribué, réserves, basis cross-currency, spreads non garantis

**Obstacle :** SOFR publié seulement jusqu’au 24; TGA moyenne hebdomadaire, aucune série basis actuelle capturée

**Conséquence :** Limite un diagnostic de liquidation systémique; ne constitue pas un veto au biais macro.

**Prochaine action :** Actualiser NY Fed après publication du 28, ajouter réserves et basis, comparer mêmes dates.

- Tentative web9, terminée à 2026-09-27T18:49:27.333Z UTC. URL: https://www.bea.gov/news/schedule; https://www.bls.gov/schedule/2026/10_sched.htm; https://www.dol.gov/ui/data.pdf; https://fred.stlouisfed.org/series/SOFR; https://fred.stlouisfed.org/series/RRPONTSYD; https://fred.stlouisfed.org/series/WTREGEN; https://fred.stlouisfed.org/series/DEXJPUS; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_real_yield_curve
- Tentative web10, terminée à 2026-09-27T18:52:55.515Z UTC. URL: https://www.bea.gov/news/schedule; https://www.dol.gov/ui/data.pdf; https://fred.stlouisfed.org/series/SOFR; https://fred.stlouisfed.org/series/RRPONTSYD; https://fred.stlouisfed.org/series/WTREGEN; https://fred.stlouisfed.org/series/DEXJPUS; https://www.bls.gov/schedule/2026/10_sched.htm
- Tentative web17, terminée à 2026-09-27T18:54:45.182Z UTC. URL: https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://www.sca.isr.umich.edu/; https://www.newyorkfed.org/markets/reference-rates/sofr; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://www.etf.com/sections/daily-etf-flows; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf
- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24

### F4_RELEASES — PARTIAL

**Mesure / date :** Consensus PMI composite septembre et révisions détaillées de toutes ses composantes

**Obstacle :** Publication primaire fournit le réalisé mais pas le consensus; calendriers secondaires retournent séries incohérentes

**Conséquence :** Impossible de chiffrer la surprise composite; la hausse observée reste vérifiée.

**Prochaine action :** Récupérer sondage daté antérieur au 23 septembre; ne pas reconstruire le consensus après coup.

- Tentative web13, terminée à 2026-09-27T18:53:30.315Z UTC. URL: https://finance.yahoo.com/quote/GC%3DF/history/?frequency=1d; https://www.gold.org/goldhub/gold-focus/2026/09/central-bank-gold-statistics-central-banks-make-positive-headlines-gold; https://www.gold.org/goldhub/data/gold-premium; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund
- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows
- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september

### F4_OIL — PARTIAL

**Mesure / date :** Règlements Brent novembre et WTI novembre 18–25, réaction après nouvelles du week-end

**Obstacle :** Article récupéré intraday sans série homogène; aucune séance post-week-end avant cutoff

**Conséquence :** Pas de rendement hebdomadaire pétrole exact ni de confirmation du canal dominant du week-end.

**Prochaine action :** Récupérer règlements ICE/CME identifiés et comparer après réouverture pétrole, réel, dollar et or.

- Tentative web11, terminée à 2026-09-27T18:53:05.471Z UTC. Recherche ciblée: requête exacte consignée au journal.
- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows

### F4_AUCTIONS_FISCAL — PARTIAL

**Mesure / date :** Tail 5 ans du 23 et 7 ans du 24, when-issued exact, historique comparable

**Obstacle :** Page générale Treasury sans tableau; PDF sept ans récupéré via lien secondaire; pas de when-issued dans le PDF; chiffres secondaires non admis comme preuve primaire de tail

**Conséquence :** La prime de terme/fiscal reste une explication concurrente non quantifiée.

**Prochaine action :** Obtenir résultats cinq ans et cotations when-issued de même instant; analyser allocations et réaction sans extrapoler à une crise.

- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows
- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september
- Tentative web19, terminée à 2026-09-27T18:55:27.300Z UTC. URL: https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24; https://www.tftc.io/5-year-treasury-auction-5-percent-yield-second-biggest-tail-record; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm
- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24
- Tentative web21, terminée à 2026-09-27T18:56:02.177Z UTC. URL: https://www.treasurydirect.gov/instit/annceresult/press/preanre/2026/R_20260924_3.pdf; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf

### F5_COT — PARTIAL

**Mesure / date :** Percentiles 156 semaines des longs, shorts et net MM Gold futures-only 088691 au 22 septembre

**Obstacle :** ZIP 2026 indisponible via web et HTTP403; environnement PRE vide dans extraction; historique complet non téléchargé

**Conséquence :** Interdit de qualifier le positionnement d’extrême; baisse passée insuffisante pour asymétrie baissière future.

**Prochaine action :** Télécharger 2023–2026 CFTC, conserver 156 rapports comparables, contrôler doublons et calculer rangs empiriques.

- Tentative web14, terminée à 2026-09-27T18:53:45.634Z UTC. URL: https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702
- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm

### F5_OPEN_INTEREST — PARTIAL

**Mesure / date :** Série définitive prix/volume/OI GCZ26 et GC agrégé, clôtures 18–25 et date clearing exacte

**Obstacle :** Page volume dynamique; bulletin courant préliminaire seulement, série réconciliée multi-séances absente; volume Yahoo différent du périmètre CME

**Conséquence :** Ne permet pas de conclure à achats nouveaux ou liquidation persistante à partir du seul décembre.

**Prochaine action :** Obtenir bulletins finaux datés, aligner prix/OI et isoler rolls, spreads, livraisons et ajustements.

- Tentative web3, terminée à 2026-09-27T18:47:56.271Z UTC. URL: https://www.cftc.gov/dea/futures/other_sf.htm; https://www.spdrgoldshares.com/usa/historical-data/; https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm
- Tentative web6, terminée à 2026-09-27T18:48:51.784Z UTC. URL: https://www.reuters.com/business/wall-st-week-ahead-jobs-report-inflation-data-test-us-rate-path-economic-2026-09-25/; https://finance.yahoo.com/markets/commodities/articles/bc-gold-silver-190014825.html; https://finance.yahoo.com/markets/commodities/articles/bc-gold-futures-140025259.html; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf; https://www.spdrgoldshares.com/assets/dynamic/GLD/GLD_US_archive_EN.csv; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund; https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html
- Tentative web17, terminée à 2026-09-27T18:54:45.182Z UTC. URL: https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://www.sca.isr.umich.edu/; https://www.newyorkfed.org/markets/reference-rates/sofr; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://www.etf.com/sections/daily-etf-flows; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf
- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september

### F5_ETF_FLOWS — PARTIAL

**Mesure / date :** IAU parts/tonnes aux clôtures 18 et 21–24 septembre; flux ETF globaux de la semaine

**Obstacle :** GLD résolu par téléchargement direct XLSX; IAU historique toujours non récupéré, page fournit un stock unique; WGC août ne remplace pas septembre

**Conséquence :** GLD réduit l’incertitude et confirme des rachats nets modestes; persistance globale et fragilité future non établies.

**Prochaine action :** Récupérer historique IAU/émetteur et données hebdomadaires WGC, sans substituer performance/AUM aux flux.

- Tentative web4, terminée à 2026-09-27T18:48:09.007Z UTC. URL: https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a.htm; https://fred.stlouisfed.org/series/DGS2; https://fred.stlouisfed.org/series/DGS10; https://fred.stlouisfed.org/series/DGS30; https://fred.stlouisfed.org/series/T10YIE; https://www.cmegroup.com/markets/metals/precious/gold.volume.html; https://www.spdrgoldshares.com/usa/historical-data/
- Tentative web13, terminée à 2026-09-27T18:53:30.315Z UTC. URL: https://finance.yahoo.com/quote/GC%3DF/history/?frequency=1d; https://www.gold.org/goldhub/gold-focus/2026/09/central-bank-gold-statistics-central-banks-make-positive-headlines-gold; https://www.gold.org/goldhub/data/gold-premium; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows
- Tentative web23, terminée à 2026-09-27T18:57:14.930Z UTC. URL: https://www.ssga.com/us/en/intermediary/etfs/spdr-gold-shares-gld

### F5_OPTIONS — NOT_APPLICABLE

**Mesure / date :** IV/skew/GEX par échéance, contexte de contrat et heure

**Obstacle :** Hors périmètre explicite du mode expérimental, non une défaillance de collecte obligatoire

**Conséquence :** Aucune conséquence sur les deux filtres fondamentaux.

**Prochaine action :** Seulement à la demande distincte de l’utilisateur avec données, échéance et méthode.


### F5_MARGINAL_FLOW — PARTIAL

**Mesure / date :** Acheteur/vendeur marginal après PMI, 23–25 septembre, et motivations

**Obstacle :** COT antérieur aux principales publications; données agrégées ne révèlent ni identité complète ni motivation

**Conséquence :** Empêche de présenter la transmission théorique comme flux effectif confirmé.

**Prochaine action :** Confronter prochain COT, créations/rachats ETF et OI réconcilié, sans attribuer des intentions non observées.

- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24
- Tentative web17, terminée à 2026-09-27T18:54:45.182Z UTC. URL: https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://www.sca.isr.umich.edu/; https://www.newyorkfed.org/markets/reference-rates/sofr; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://www.etf.com/sections/daily-etf-flows; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf
- Tentative web22, terminée à 2026-09-27T18:56:50.311Z UTC. URL: https://www.ssga.com/us/en/intermediary/etfs/spdr-gold-shares-gld

### F5_FORCED_ACTOR — UNKNOWN

**Mesure / date :** Acteur, exposition, contrainte et obligation d’agir sur Gold au 25 septembre

**Obstacle :** Données CFTC agrégées; aucune déclaration vérifiée de contrainte individuelle; table de marges non extraite

**Conséquence :** L’asymétrie de positionnement demeure non établie.

**Prochaine action :** Chercher annonce de marge/rachat/liquidation datée et participation concordante; ne pas exiger un inventaire dealer non observable.

- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september
- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24

### F5_FUNDING — PARTIAL

**Mesure / date :** Haircuts, appels de marge et financement des positions Gold à levier 21–25 septembre

**Obstacle :** Benchmarks publics disponibles mais contraintes bilatérales non révélées; table CME non extraite

**Conséquence :** Ne permet pas de convertir vulnérabilité théorique en flux contraint.

**Prochaine action :** Actualiser benchmarks et avis clearing; rechercher un événement contraignant documenté.

- Tentative web10, terminée à 2026-09-27T18:52:55.515Z UTC. URL: https://www.bea.gov/news/schedule; https://www.dol.gov/ui/data.pdf; https://fred.stlouisfed.org/series/SOFR; https://fred.stlouisfed.org/series/RRPONTSYD; https://fred.stlouisfed.org/series/WTREGEN; https://fred.stlouisfed.org/series/DEXJPUS; https://www.bls.gov/schedule/2026/10_sched.htm
- Tentative web17, terminée à 2026-09-27T18:54:45.182Z UTC. URL: https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://www.sca.isr.umich.edu/; https://www.newyorkfed.org/markets/reference-rates/sofr; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://www.etf.com/sections/daily-etf-flows; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf
- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24

### F5_FUSE — UNKNOWN

**Mesure / date :** Déclencheur mécanique et population contrainte à agir pendant la prochaine semaine

**Obstacle :** Événements macro datés connus; aucune contrainte exécutoire observable reliée aux porteurs Gold

**Conséquence :** Pas de vente forcée présentée comme inévitable.

**Prochaine action :** Identifier contrainte, échéance et exposition résiduelle, puis vérifier sa transmission effective.

- Tentative web18, terminée à 2026-09-27T18:55:11.487Z UTC. URL: https://www.sca.isr.umich.edu/; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september
- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24

### F5_PRICE_FLOW_DIVERGENCE — PARTIAL

**Mesure / date :** Participation nette alignée sur le rebond GCZ26 du 25 septembre

**Obstacle :** GLD vendredi résolu et stable; IAU historique incomplet, OI préliminaire/roll et COT mardi ne partagent pas exactement la même fenêtre.

**Conséquence :** Aucune confirmation de capital neuf ou de piège de positionnement.

**Prochaine action :** Aligner flux émetteurs, OI finaux et prochains relevés; tester persistance après les catalyseurs.

- Tentative web17, terminée à 2026-09-27T18:54:45.182Z UTC. URL: https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html; https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf; https://www.sca.isr.umich.edu/; https://www.newyorkfed.org/markets/reference-rates/sofr; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://www.etf.com/sections/daily-etf-flows; https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&trk=article-ssr-frontend-pulse_little-text-block&type=daily_treasury_yield_curve; https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf
- Tentative web20, terminée à 2026-09-27T18:55:40.295Z UTC. URL: https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm; https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24
- Tentative web22, terminée à 2026-09-27T18:56:50.311Z UTC. URL: https://www.ssga.com/us/en/intermediary/etfs/spdr-gold-shares-gld
- Tentative web23, terminée à 2026-09-27T18:57:14.930Z UTC. URL: https://www.ssga.com/us/en/intermediary/etfs/spdr-gold-shares-gld

### F6_CENTRAL_BANKS — PARTIAL

**Mesure / date :** Achats officiels mondiaux août/septembre, déclarés et estimés séparément

**Obstacle :** Compilation détaillée obtenue jusqu’à juillet; aucune mise à jour mondiale comparable capturée au cutoff

**Conséquence :** Soutien d’horizon long, pas confirmation du timing hebdomadaire.

**Prochaine action :** Actualiser IMF et déclarations nationales; distinguer dates de transaction, publication et estimations.

- Tentative web11, terminée à 2026-09-27T18:53:05.471Z UTC. Recherche ciblée: requête exacte consignée au journal.
- Tentative web12, terminée à 2026-09-27T18:53:19.942Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.tbsnews.net/worldbiz/middle-east/iran-insists-diplomatic-solution-after-trump-rejects-peace-plan-1554716; https://www.24k99.com/data/etf; https://www.gold.org/goldhub/research/gold-etfs-holdings-and-flows/2026/09; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://en.sge.com.cn/data_CashSettlement/10002702
- Tentative web13, terminée à 2026-09-27T18:53:30.315Z UTC. URL: https://finance.yahoo.com/quote/GC%3DF/history/?frequency=1d; https://www.gold.org/goldhub/gold-focus/2026/09/central-bank-gold-statistics-central-banks-make-positive-headlines-gold; https://www.gold.org/goldhub/data/gold-premium; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund

### F6_CHINA_PHYSICAL — PARTIAL

**Mesure / date :** Prime Shanghai vs Londres du 25 septembre et retraits/importations récents comparables

**Obstacle :** WGC graphique non extrait et décalé; SGE NYAuTN autre instrument/fixing; recherche secondaire sans benchmark aligné

**Conséquence :** La demande physique ne confirme ni ne réfute le biais tactique de manière contemporaine.

**Prochaine action :** Obtenir SGE Au99.99/benchmark, spot Londres, FX même heure, fiscalité/frictions et calendrier local; rapporter imports séparément.

- Tentative web12, terminée à 2026-09-27T18:53:19.942Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.tbsnews.net/worldbiz/middle-east/iran-insists-diplomatic-solution-after-trump-rejects-peace-plan-1554716; https://www.24k99.com/data/etf; https://www.gold.org/goldhub/research/gold-etfs-holdings-and-flows/2026/09; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://en.sge.com.cn/data_CashSettlement/10002702
- Tentative web13, terminée à 2026-09-27T18:53:30.315Z UTC. URL: https://finance.yahoo.com/quote/GC%3DF/history/?frequency=1d; https://www.gold.org/goldhub/gold-focus/2026/09/central-bank-gold-statistics-central-banks-make-positive-headlines-gold; https://www.gold.org/goldhub/data/gold-premium; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026; https://www.ishares.com/us/products/239561/ishares-gold-trust-fund
- Tentative web15, terminée à 2026-09-27T18:53:57.979Z UTC. URL: https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702; https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm
- Tentative web16, terminée à 2026-09-27T18:54:31.292Z UTC. URL: https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september; https://www.treasurydirect.gov/auctions/announcements-data-results/; https://finance.yahoo.com/quote/%5EMOVE/history/; https://finance.yahoo.com/quote/DX-Y.NYB/history/; https://www.etf.com/sections/daily-etf-flows

### F6_DEBASEMENT — PARTIAL

**Mesure / date :** Nouveau transfert observable dette/dollar vers Gold et action monétaire/fiscale correspondante 21–27 septembre

**Obstacle :** Prix compatibles avec plusieurs mécanismes; aucune mesure directe du transfert ni annonce primaire de programme nouveau capturée

**Conséquence :** Empêche de traiter debasement comme moteur tactique dominant.

**Prochaine action :** Vérifier annonces officielles et combinaison persistante dollar faible, flux Gold, taux/prime de terme et demande obligataire.

- Tentative web14, terminée à 2026-09-27T18:53:45.634Z UTC. URL: https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm; https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm; https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368; https://en.sge.com.cn/data_CashSettlement/10002702
- Tentative web19, terminée à 2026-09-27T18:55:27.300Z UTC. URL: https://thefile.news/story/treasury-auctions-4w-8w-7y-sept24; https://www.tftc.io/5-year-treasury-auction-5-percent-yield-second-biggest-tail-record; https://fred.stlouisfed.org/series/IORB; https://www.cmegroup.com/markets/metals/precious/gold.margins.html; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf; https://www.cftc.gov/dea/futures/other_sf.htm
- Tentative web21, terminée à 2026-09-27T18:56:02.177Z UTC. URL: https://www.treasurydirect.gov/instit/annceresult/press/preanre/2026/R_20260924_3.pdf; https://www.spglobal.com/content/dam/spglobal/mi/en/documents/news-insights/research/2026/09/6293416_6293414_0.1.pdf

## Journal de recherche horodaté

Les horaires sont les fins réelles des appels, pas les heures de publication des sources. Une requête n’atteste pas que tous ses résultats ont été retenus. Les pages primaires obtenues et retenues figurent dans le registre du rapport. Les résultats non pertinents, anciens ou incompatibles ont été écartés.

### web1 — 2026-09-27T18:47:34.850Z

```json
{
  "system1_search_query": [
    {
      "q": "gold futures September 25 2026 settlement week September 21 2026 Reuters",
      "recency": 10
    },
    {
      "q": "September 25 2026 Treasury real yields Federal Reserve gold dollar PCE",
      "recency": 10
    },
    {
      "q": "site.cftc.gov gold September 22 2026 commitments traders",
      "recency": 10
    }
  ],
  "response_length": "long"
}
```

### web2 — 2026-09-27T18:47:46.500Z

```json
{
  "open": [
    {
      "ref_id": "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/DFII10"
    },
    {
      "ref_id": "https://www.cftc.gov/dea/futures/other_sf.htm"
    },
    {
      "ref_id": "https://www.spdrgoldshares.com/usa/historical-data/"
    }
  ],
  "response_length": "long"
}
```

### web3 — 2026-09-27T18:47:56.271Z

```json
{
  "click": [
    {
      "ref_id": "turn1view0",
      "id": 51
    }
  ],
  "find": [
    {
      "ref_id": "turn1view2",
      "pattern": "GOLD"
    },
    {
      "ref_id": "turn1view3",
      "pattern": "Historical"
    },
    {
      "ref_id": "turn1view3",
      "pattern": "Tonnes"
    }
  ],
  "system2_search_query": [
    {
      "q": "gold \"September 25, 2026\" futures settle"
    },
    {
      "q": "gold \"September 24, 2026\" futures settlement"
    },
    {
      "q": "gold \"September 23, 2026\" futures settle"
    }
  ],
  "response_length": "long"
}
```

### web4 — 2026-09-27T18:48:09.007Z

```json
{
  "open": [
    {
      "ref_id": "turn2view0"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/DGS2"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/DGS10"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/DGS30"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/T10YIE"
    },
    {
      "ref_id": "https://www.cmegroup.com/markets/metals/precious/gold.volume.html"
    }
  ],
  "click": [
    {
      "ref_id": "turn1view3",
      "id": 6
    }
  ],
  "response_length": "long"
}
```

### web5 — 2026-09-27T18:48:39.161Z

```json
{
  "open": [
    {
      "ref_id": "https://home.treasury.gov/resource-center-data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve&field_tdr_date_value=2026"
    },
    {
      "ref_id": "https://home.treasury.gov/resource-center-data-chart-center/interest-rates/TextView?type=daily_treasury_real_yield_curve&field_tdr_date_value=2026"
    },
    {
      "ref_id": "https://www.spdrgoldshares.com/assets/dynamic/GLD/GLD_US_archive_EN.csv"
    },
    {
      "ref_id": "https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html"
    },
    {
      "ref_id": "https://www.ishares.com/us/products/239561/ishares-gold-trust-fund"
    }
  ],
  "system1_search_query": [
    {
      "q": "gold Friday September 25 2026 Reuters PCE interest rates",
      "recency": 4
    },
    {
      "q": "site.bea.gov \"August 2026\" \"Personal Income\" September",
      "recency": 10
    }
  ],
  "response_length": "long"
}
```

### web6 — 2026-09-27T18:48:51.784Z

```json
{
  "find": [
    {
      "ref_id": "turn4view2",
      "pattern": "25-Sep-2026"
    },
    {
      "ref_id": "turn4view4",
      "pattern": "Tonnes"
    },
    {
      "ref_id": "turn4view3",
      "pattern": "October"
    }
  ],
  "open": [
    {
      "ref_id": "turn4news1"
    },
    {
      "ref_id": "turn2search4"
    },
    {
      "ref_id": "turn2search7"
    },
    {
      "ref_id": "https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf"
    }
  ],
  "system2_search_query": [
    {
      "q": "\"gold\" \"2026-09-25\" Reuters"
    },
    {
      "q": "\"Daily Treasury\" \"09/25/2026\""
    },
    {
      "q": "\"gold\" \"September 25, 2026\" \"settled\""
    }
  ],
  "response_length": "long"
}
```

### web7 — 2026-09-27T18:49:04.121Z

```json
{
  "open": [
    {
      "ref_id": "turn5search4"
    },
    {
      "ref_id": "turn5search5"
    },
    {
      "ref_id": "turn5search12"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/BAMLH0A0HYM2"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/BAMLC0A0CM"
    }
  ],
  "find": [
    {
      "ref_id": "turn5view3",
      "pattern": "GC"
    },
    {
      "ref_id": "turn5view3",
      "pattern": "SEP 25"
    },
    {
      "ref_id": "turn5view0",
      "pattern": "100,000"
    }
  ],
  "response_length": "long"
}
```

### web8 — 2026-09-27T18:49:14.682Z

```json
{
  "open": [
    {
      "ref_id": "turn5view3",
      "lineno": 236
    },
    {
      "ref_id": "turn6view0",
      "lineno": 740
    },
    {
      "ref_id": "turn6view1",
      "lineno": 740
    },
    {
      "ref_id": "turn6view3",
      "lineno": 18
    },
    {
      "ref_id": "turn6view4",
      "lineno": 18
    },
    {
      "ref_id": "turn6view2",
      "lineno": 788
    }
  ],
  "response_length": "long"
}
```

### web9 — 2026-09-27T18:49:27.333Z

```json
{
  "find": [
    {
      "ref_id": "turn6view0",
      "pattern": "09/25/2026"
    },
    {
      "ref_id": "turn6view1",
      "pattern": "09/25/2026"
    }
  ],
  "open": [
    {
      "ref_id": "https://www.bea.gov/news/schedule"
    },
    {
      "ref_id": "https://www.bls.gov/schedule/2026/10_sched.htm"
    },
    {
      "ref_id": "https://www.dol.gov/ui/data.pdf"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/SOFR"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/RRPONTSYD"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/WTREGEN"
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/DEXJPUS"
    }
  ],
  "response_length": "long"
}
```

### web10 — 2026-09-27T18:52:55.515Z

```json
{
  "open": [
    {
      "ref_id": "turn8view0"
    },
    {
      "ref_id": "turn8view2",
      "lineno": 0
    },
    {
      "ref_id": "turn8view3",
      "lineno": 35
    },
    {
      "ref_id": "turn8view4",
      "lineno": 35
    },
    {
      "ref_id": "turn8view5",
      "lineno": 35
    },
    {
      "ref_id": "turn8view6",
      "lineno": 35
    }
  ],
  "find": [
    {
      "ref_id": "turn8view1",
      "pattern": "Employment Situation"
    }
  ],
  "response_length": "long"
}
```

### web11 — 2026-09-27T18:53:05.471Z

```json
{
  "system1_search_query": [
    {
      "q": "site.reuters.com September 25 2026 dollar yen yuan oil settlement gold",
      "recency": 7
    },
    {
      "q": "site.gold.org September 2026 central bank gold reserves August ETF flows",
      "recency": 45
    },
    {
      "q": "site.reuters.com September 27 2026 Iran ceasefire sanctions oil",
      "recency": 3
    },
    {
      "q": "September 25 2026 GLD gold holdings tonnes September 18"
    }
  ],
  "response_length": "long"
}
```

### web12 — 2026-09-27T18:53:19.942Z

```json
{
  "system2_search_query": [
    {
      "q": "site.gold.org \"2026\" \"September\" \"Central bank\" \"July\""
    },
    {
      "q": "site.gold.org \"2026\" \"September\" \"China\" \"premium\""
    },
    {
      "q": "\"September 25, 2026\" \"MOVE\" index"
    },
    {
      "q": "\"September 25, 2026\" \"gold\" \"4,321.20\""
    }
  ],
  "open": [
    {
      "ref_id": "turn10search4"
    },
    {
      "ref_id": "turn10news19"
    },
    {
      "ref_id": "turn10search3"
    },
    {
      "ref_id": "turn10search2"
    },
    {
      "ref_id": "https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026"
    },
    {
      "ref_id": "https://en.sge.com.cn/data_CashSettlement/10002702"
    }
  ],
  "response_length": "long"
}
```

### web13 — 2026-09-27T18:53:30.315Z

```json
{
  "open": [
    {
      "ref_id": "turn11search6"
    },
    {
      "ref_id": "turn11search0"
    },
    {
      "ref_id": "turn11search1"
    },
    {
      "ref_id": "turn11view0",
      "lineno": 65
    },
    {
      "ref_id": "turn11view4",
      "lineno": 25
    }
  ],
  "click": [
    {
      "ref_id": "turn4view4",
      "id": 15
    }
  ],
  "system2_search_query": [
    {
      "q": "September 2026 site.cftc.gov \"Disaggregated\" \"Historical\""
    },
    {
      "q": "\"September 23, 2026\" \"PMI\" \"S&P Global\" US"
    },
    {
      "q": "\"September 24, 2026\" \"claims\" \"Reuters\" 197000"
    },
    {
      "q": "\"September 25, 2026\" \"Brent\" \"settled\" Reuters"
    }
  ],
  "response_length": "long"
}
```

### web14 — 2026-09-27T18:53:45.634Z

```json
{
  "open": [
    {
      "ref_id": "turn12search1"
    },
    {
      "ref_id": "turn12search6"
    },
    {
      "ref_id": "turn11view0",
      "lineno": 70
    },
    {
      "ref_id": "turn11view5",
      "lineno": 150
    }
  ],
  "system1_search_query": [
    {
      "q": "site.spglobal.com \"September\" \"2026\" \"58.4\""
    },
    {
      "q": "site.reuters.com \"2026-09-25\" \"oil\" \"settled\""
    },
    {
      "q": "site.reuters.com \"2026-09-25\" \"China\" \"gold\" premium"
    },
    {
      "q": "site.reuters.com \"2026-09-24\" \"Treasury\" \"auction\""
    }
  ],
  "response_length": "long"
}
```

### web15 — 2026-09-27T18:53:57.979Z

```json
{
  "find": [
    {
      "ref_id": "turn11view0",
      "pattern": "100."
    },
    {
      "ref_id": "turn11view0",
      "pattern": "157"
    },
    {
      "ref_id": "turn11view5",
      "pattern": "COMEX"
    }
  ],
  "click": [
    {
      "ref_id": "turn13view0",
      "id": 52
    },
    {
      "ref_id": "turn13view1",
      "id": 55
    }
  ],
  "system2_search_query": [
    {
      "q": "S&P Global flash US PMI September 2026 58.4 spglobal release"
    },
    {
      "q": "Oil settles September 25 2026 Brent 103 Reuters"
    },
    {
      "q": "Asian gold September 25 2026 China premiums Reuters"
    },
    {
      "q": "\"Gold Dec 26\" \"Sep 18, 2026\""
    }
  ],
  "response_length": "long"
}
```

### web16 — 2026-09-27T18:54:31.292Z

```json
{
  "open": [
    {
      "ref_id": "turn14search0"
    },
    {
      "ref_id": "https://www.treasurydirect.gov/auctions/announcements-data-results/"
    },
    {
      "ref_id": "https://finance.yahoo.com/quote/%5EMOVE/history/"
    },
    {
      "ref_id": "https://finance.yahoo.com/quote/DX-Y.NYB/history/"
    },
    {
      "ref_id": "https://www.etf.com/sections/daily-etf-flows"
    }
  ],
  "system2_search_query": [
    {
      "q": "\"September 25, 2026\" \"durable\" \"0.\" Reuters"
    },
    {
      "q": "\"September 25, 2026\" \"gold\" \"premium\" China India"
    },
    {
      "q": "\"September 25, 2026\" \"Brent\" \"settled\" \"103\""
    },
    {
      "q": "\"September 25, 2026\" \"IAU\" \"holdings\""
    }
  ],
  "response_length": "long"
}
```

### web17 — 2026-09-27T18:54:45.182Z

```json
{
  "open": [
    {
      "ref_id": "turn16search22"
    },
    {
      "ref_id": "https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf"
    },
    {
      "ref_id": "https://www.sca.isr.umich.edu/"
    },
    {
      "ref_id": "https://www.newyorkfed.org/markets/reference-rates/sofr"
    }
  ],
  "find": [
    {
      "ref_id": "turn16view1",
      "pattern": "2026"
    },
    {
      "ref_id": "turn16view4",
      "pattern": "September"
    },
    {
      "ref_id": "turn6view0",
      "pattern": "1.5"
    },
    {
      "ref_id": "turn5view3",
      "pattern": "PRELIMINARY"
    }
  ],
  "response_length": "long"
}
```

### web18 — 2026-09-27T18:55:11.487Z

```json
{
  "open": [
    {
      "ref_id": "turn17view2",
      "lineno": 0
    },
    {
      "ref_id": "turn17view1",
      "lineno": 0
    },
    {
      "ref_id": "https://fred.stlouisfed.org/series/IORB"
    },
    {
      "ref_id": "https://www.cmegroup.com/markets/metals/precious/gold.margins.html"
    }
  ],
  "click": [
    {
      "ref_id": "turn16view0",
      "id": 141
    }
  ],
  "system2_search_query": [
    {
      "q": "\"Gold Dec 26\" \"Sep 21, 2026\" \"Sep 22, 2026\""
    },
    {
      "q": "\"Gold Dec 26\" \"Sep 23, 2026\" \"Sep 24, 2026\""
    },
    {
      "q": "\"September 24, 2026\" Treasury auction seven year bid cover"
    },
    {
      "q": "\"September 25, 2026\" \"MOVE\" \"index\" bonds"
    }
  ],
  "response_length": "long"
}
```

### web19 — 2026-09-27T18:55:27.300Z

```json
{
  "find": [
    {
      "ref_id": "turn18view2",
      "pattern": "2026-09-24"
    },
    {
      "ref_id": "turn18view3",
      "pattern": "2026"
    },
    {
      "ref_id": "turn18view4",
      "pattern": "58.7"
    },
    {
      "ref_id": "turn1view2",
      "pattern": "GOLD -"
    }
  ],
  "open": [
    {
      "ref_id": "turn18search4"
    },
    {
      "ref_id": "turn18search7"
    }
  ],
  "response_length": "long"
}
```

### web20 — 2026-09-27T18:55:40.295Z

```json
{
  "click": [
    {
      "ref_id": "turn19view0",
      "id": 14
    }
  ],
  "find": [
    {
      "ref_id": "turn18view2",
      "pattern": "Observations"
    },
    {
      "ref_id": "turn18view3",
      "pattern": "Maintenance"
    },
    {
      "ref_id": "turn18view4",
      "pattern": "58.7"
    },
    {
      "ref_id": "turn1view2",
      "pattern": "135,699"
    }
  ],
  "response_length": "long"
}
```

### web21 — 2026-09-27T18:56:02.177Z

```json
{
  "open": [
    {
      "ref_id": "turn20view0",
      "lineno": 0
    },
    {
      "ref_id": "turn18view4",
      "lineno": 0
    }
  ],
  "response_length": "long"
}
```

### web22 — 2026-09-27T18:56:50.311Z

```json
{
  "open": [
    {
      "ref_id": "https://www.ssga.com/us/en/intermediary/etfs/spdr-gold-shares-gld"
    }
  ],
  "response_length": "long"
}
```

### web23 — 2026-09-27T18:57:14.930Z

```json
{
  "click": [
    {
      "ref_id": "turn22view0",
      "id": 8
    },
    {
      "ref_id": "turn22view0",
      "id": 18
    }
  ],
  "response_length": "short"
}
```

### Téléchargements directs complémentaires

| Heure UTC du 27 septembre | URL | Résultat |
|---|---|---|
| 18:54:42.746465 | https://www.cftc.gov/files/dea/history/fut_disagg_txt_2026.zip | HTTP403 |
| 18:54:50.019352 | https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF?range=3mo&interval=1d | HTTP429 |
| 18:54:56.907579 | https://www.spdrgoldshares.com/assets/dynamic/GLD/GLD_US_archive_EN.csv | HTTP403 |
| 18:57:35.740939 | https://www.ssga.com/library-content/products/fund-data/etfs/us/navhist-us-en-gld.xlsx | HTTP200; 264 789 octets; lecture seule |

L’absence initiale du module Python requests était un problème local, pas une indisponibilité fournisseur; la récupération a utilisé urllib. Les essais antérieurs sont consignés dans la trace de conversation; seuls les horaires explicitement conservés sont reportés ici.

## Registre de sources et horaires

**FED — [Federal Reserve — décision du 16 septembre](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a.htm)** — PRIMARY. Mesure: 2026-09-16T14:00:00-04:00. 

Récupérations: 2026-09-27T18:47:46.500Z (web2); 2026-09-27T18:47:56.271Z (web3)

**FOMC — [Calendrier officiel du FOMC](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm)** — PRIMARY. Mesure: Calendrier 2026. 

Récupérations: 2026-09-27T18:47:34.850Z (web1)

**NOM — [Treasury — courbe nominale quotidienne](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve&field_tdr_date_value=2026)** — PRIMARY. Mesure: 2026-09-18/2026-09-25. Cotations indicatives vers 15 h 30 New York; colonnes vérifiées. Pas des transactions ni des observations intraday synchronisées.

Récupérations: 2026-09-27T18:49:04.121Z (web7); 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:54:45.182Z (web17)

**REAL — [Treasury — courbe réelle quotidienne](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?type=daily_treasury_real_yield_curve&field_tdr_date_value=2026)** — PRIMARY. Mesure: 2026-09-18/2026-09-25. 

Récupérations: 2026-09-27T18:49:04.121Z (web7); 2026-09-27T18:49:27.333Z (web9)

**DFII — [FRED — DFII10](https://fred.stlouisfed.org/series/DFII10)** — PRIMARY. Mesure: 2026-09-24. Dernière valeur FRED jeudi; vendredi récupéré directement au Trésor.

Récupérations: 2026-09-27T18:47:34.850Z (web1)

**BE — [FRED — T10YIE](https://fred.stlouisfed.org/series/T10YIE)** — PRIMARY. Mesure: 2026-09-25. Breakeven 10 ans; mesure de marché incluant primes de risque et de liquidité.

Récupérations: 2026-09-27T18:47:56.271Z (web3)

**FX — [Reuters — dollar, yen et FedWatch, édition tardive du vendredi](https://www.investing.com/news/economy-news/dollar-falls-as-oil-cools-but-set-for-weekly-gain-yen-rallies-4917368)** — SECONDARY. Mesure: 2026-09-25, article actualisé 15:12 affiché. Instantanés intraday; fuseau de la page non explicitement certifié. Ne pas utiliser les widgets de cours changeants sous l’article.

Récupérations: 2026-09-27T18:53:19.942Z (web12); 2026-09-27T18:53:57.979Z (web15)

**FXMON — [Reuters — yuan du lundi](https://www.reuters.com/world/asia-pacific/yuan-hits-fresh-multi-year-peak-pboc-eases-curb-ahead-trump-xi-summit-2026-09-21/)** — SECONDARY. Mesure: 2026-09-21, séance asiatique. 

Récupérations: 2026-09-27T18:53:05.471Z (web11); 2026-09-27T18:53:57.979Z (web15)

**FEDWATCH — [CME FedWatch](https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html)** — PRIMARY. Mesure: Fenêtre visée 2026-09-18/25. Application accessible mais grille numérique non extraite.

Récupérations: 2026-09-27T18:48:09.007Z (web4); 2026-09-27T18:48:39.161Z (web5)

**GOLDAM — [Reuters — or du vendredi, matin](https://ca.marketscreener.com/news/gold-rises-but-on-track-for-weekly-loss-as-fed-rate-hike-expectations-build-ce785adfdc8dff2c)** — SECONDARY. Mesure: 2026-09-25T12:10:00Z. Probabilité octobre 71 % dans une édition antérieure, non clôture. Ne pas mélanger avec 66 % de l’édition FX tardive.

Récupérations: 2026-09-27T18:48:51.784Z (web6); 2026-09-27T18:49:04.121Z (web7); 2026-09-27T18:49:14.682Z (web8)

**CME — [CME — bulletin métaux 185, préliminaire](https://www.cmegroup.com/daily_bulletin/current/Section62_Metals_Futures_Products.pdf)** — PRIMARY. Mesure: 2026-09-25. GC décembre 2026, prix de règlement; volumes Globex et PNT séparés. OI et variations du bulletin préliminaire, révisables; aucune attribution à un acteur.

Récupérations: 2026-09-27T18:48:51.784Z (web6); 2026-09-27T18:49:04.121Z (web7); 2026-09-27T18:49:14.682Z (web8); 2026-09-27T18:54:45.182Z (web17)

**YGC — [Yahoo — historique Gold Dec 26](https://finance.yahoo.com/quote/GC%3DF/history/?frequency=1d)** — SECONDARY. Mesure: 2026-09-18/25. Lignes indexées récupérées; ouverture directe en erreur. Le symbole continu peut changer de contrat; seuls les endpoints identifiés décembre sont utilisés, celui du 25 corroboré CME.

Récupérations: 2026-09-27T18:53:19.942Z (web12); 2026-09-27T18:53:30.315Z (web13); 2026-09-27T18:53:57.979Z (web15); 2026-09-27T18:55:11.487Z (web18)

**COT — [CFTC — disaggregated futures only, Gold 088691](https://www.cftc.gov/dea/futures/other_sf.htm)** — PRIMARY. Mesure: Positions 2026-09-22; publication hebdomadaire 2026-09-25. 100 onces par contrat, Managed Money; ni legacy non-commercial, ni micro, ni futures+options.

Récupérations: 2026-09-27T18:47:34.850Z (web1); 2026-09-27T18:47:46.500Z (web2); 2026-09-27T18:55:40.295Z (web20)

**COTH — [CFTC — archives annuelles futures only](https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm)** — PRIMARY. Mesure: Historique requis: 156 observations jusqu’au 2026-09-22. Lien ZIP 2026 en erreur via web et HTTP403 via téléchargement; série non obtenue.

Récupérations: 2026-09-27T18:53:45.634Z (web14); 2026-09-27T18:53:57.979Z (web15)

**GLD — [State Street — GLD](https://www.ssga.com/us/en/intermediary/etfs/spdr-gold-shares-gld)** — PRIMARY. Mesure: 2026-09-25. 369,70 millions de parts au 25 confirmé; baseline et chemin quotidien revérifiés dans GLDH après la comparaison au rapport précédent.

Récupérations: 2026-09-27T18:56:50.311Z (web22); 2026-09-27T18:57:14.930Z (web23)

**GLDA — [SPDR — archives GLD](https://www.spdrgoldshares.com/usa/gld/)** — PRIMARY. Mesure: Fenêtre visée 2026-09-18/25. Champs AWAITING; archive XLSX non récupérée. Ancienne URL CSV renvoie un PDF de barres dans le lecteur, HTTP403 en téléchargement.

Récupérations: 2026-09-27T18:47:34.850Z (web1); 2026-09-27T18:47:46.500Z (web2); 2026-09-27T18:47:56.271Z (web3); 2026-09-27T18:53:05.471Z (web11)

**GLDSEC — [24K99 — historique de tonnes GLD](https://www.24k99.com/data/etf)** — SECONDARY. Mesure: 2026-09-18/25, dates affichées Pékin. 1 057,12→1 054,56 tonnes; alignement date US/Pékin non confirmé, secondaire seulement. Pas une preuve de flux cash ni un substitut à l’émetteur.

Récupérations: 2026-09-27T18:53:05.471Z (web11); 2026-09-27T18:53:19.942Z (web12)

**IAU — [iShares — IAU](https://www.ishares.com/us/products/239561/ishares-gold-trust-fund)** — PRIMARY. Mesure: 2026-09-25. 792,15 millions de parts; 463,20 t; un point de stock, pas une variation. Téléchargement historique en erreur.

Récupérations: 2026-09-27T18:48:09.007Z (web4); 2026-09-27T18:48:39.161Z (web5); 2026-09-27T18:53:30.315Z (web13)

**ETFAUG — [World Gold Council — ETF août](https://www.gold.org/goldhub/research/gold-etfs-holdings-and-flows/2026/09)** — INDUSTRY. Mesure: 2026-08-31; publié 2026-09-09. +121 t, +18 Md USD sur août; ne représente pas la semaine du 21 au 25 septembre.

Récupérations: 2026-09-27T18:53:05.471Z (web11); 2026-09-27T18:53:19.942Z (web12)

**PMI — [S&P Global — flash septembre](https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/09/us-flash-pmi-signals-fastest-growth-for-over-five-years-in-september)** — PRIMARY. Mesure: 2026-09-23. Composite 58,4 contre 56,0; enquête, pas PIB réalisé. Consensus composite non établi.

Récupérations: 2026-09-27T18:53:57.979Z (web15); 2026-09-27T18:54:31.292Z (web16); 2026-09-27T18:55:11.487Z (web18); 2026-09-27T18:56:02.177Z (web21)

**CLAIMS — [Department of Labor — demandes d’allocations](https://www.dol.gov/ui/data.pdf)** — PRIMARY. Mesure: Semaine finissant 2026-09-19; publication 2026-09-24 08:30 EDT. 

Récupérations: 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:52:55.515Z (web10)

**CLAIMSC — [Reuters — consensus claims](https://gvwire.com/2026/09/24/us-weekly-jobless-claims-near-57-year-lows-as-labor-market-regains-footing/)** — SECONDARY. Mesure: 2026-09-24. Consensus 201 000; chiffres réalisés corroborés DOL.

Récupérations: 2026-09-27T18:53:30.315Z (web13)

**DUR — [Census — biens durables août](https://www.census.gov/manufacturing/m3/adv/pdf/durgd.pdf)** — PRIMARY. Mesure: Août 2026; publication 2026-09-25 08:30 EDT. 

Récupérations: 2026-09-27T18:54:45.182Z (web17); 2026-09-27T18:55:11.487Z (web18)

**CAPEX — [Reuters — biens d’équipement et consensus](https://www.streetinsider.com/Reuters/US%2Bcore%2Bcapital%2Bgoods%2Borders%2Bpoint%2Bto%2Brobust%2Bgrowth%2Bin%2Bbusiness%2Bspending%2Bon%2Bequipment/27104480.html)** — SECONDARY. Mesure: 2026-09-25, article affiché 08:47 EDT. Commandes hors défense et aviation +1,6 %; attendu +0,5 %; juillet révisé +0,6 % contre 0 initial. Date affichée initiale, article peut être actualisé.

Récupérations: 2026-09-27T18:54:45.182Z (web17)

**MICH — [University of Michigan — résultats finaux septembre](https://www.sca.isr.umich.edu/)** — PRIMARY. Mesure: 2026-09-25. 

Récupérations: 2026-09-27T18:54:45.182Z (web17); 2026-09-27T18:55:11.487Z (web18)

**OIL — [Reuters — pétrole vendredi intraday](https://ca.marketscreener.com/news/oil-prices-fall-as-markets-look-to-iran-truce-but-remain-wary-of-attacks-on-oil-facilities-ce785adfdb8cf525)** — SECONDARY. Mesure: 2026-09-25, 12:12 p.m. dans l’article. Brent 103,64 USD/b, −2,96; observation intraday, pas règlement. Contrat non spécifié dans l’extrait, aucune série continue calculée.

Récupérations: 2026-09-27T18:53:57.979Z (web15)

**IRAN — [Reuters via TBS — diplomatie après rejet du plan](https://www.tbsnews.net/worldbiz/middle-east/iran-insists-diplomatic-solution-after-trump-rejects-peace-plan-1554716)** — SECONDARY. Mesure: 2026-09-26/27; page modifiée 28 septembre 00:27, heure locale affichée. Le 28 septembre à Dhaka correspond encore au 27 aux États-Unis; heure de publication exacte et version initiale non certifiées. Aucun prix de réouverture consommé.

Récupérations: 2026-09-27T18:53:05.471Z (web11); 2026-09-27T18:53:19.942Z (web12)

**AUCTION — [TreasuryDirect — adjudication 7 ans](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2026/R_20260924_3.pdf)** — PRIMARY. Mesure: 2026-09-24. 5,085 %, couverture 2,42; 44,0000551 Md USD hors SOMA. Pas de when-issued dans le PDF: tail non calculé.

Récupérations: 2026-09-27T18:55:40.295Z (web20); 2026-09-27T18:56:02.177Z (web21)

**HY — [ICE BofA HY OAS via FRED](https://fred.stlouisfed.org/series/BAMLH0A0HYM2)** — PRIMARY_DISTRIBUTOR. Mesure: 2026-09-18/24. 

Récupérations: 2026-09-27T18:49:04.121Z (web7); 2026-09-27T18:49:14.682Z (web8)

**IG — [ICE BofA IG OAS via FRED](https://fred.stlouisfed.org/series/BAMLC0A0CM)** — PRIMARY_DISTRIBUTOR. Mesure: 2026-09-18/24. 

Récupérations: 2026-09-27T18:49:04.121Z (web7); 2026-09-27T18:49:14.682Z (web8)

**SOFR — [NY Fed SOFR via FRED](https://fred.stlouisfed.org/series/SOFR)** — PRIMARY. Mesure: 2026-09-24. 

Récupérations: 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:52:55.515Z (web10)

**IORB — [Fed IORB via FRED](https://fred.stlouisfed.org/series/IORB)** — PRIMARY. Mesure: 2026-09-24. Utilisation du 24 seulement; ligne administrative du 28 déjà affichée non traitée comme prix futur réalisé.

Récupérations: 2026-09-27T18:55:11.487Z (web18); 2026-09-27T18:55:27.300Z (web19); 2026-09-27T18:55:40.295Z (web20)

**RRP — [NY Fed reverse repo via FRED](https://fred.stlouisfed.org/series/RRPONTSYD)** — PRIMARY. Mesure: 2026-09-25. 

Récupérations: 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:52:55.515Z (web10)

**TGA — [Fed TGA moyenne hebdomadaire via FRED](https://fred.stlouisfed.org/series/WTREGEN)** — PRIMARY. Mesure: 2026-09-16/23. 

Récupérations: 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:52:55.515Z (web10)

**JPY — [Fed USD/JPY via FRED](https://fred.stlouisfed.org/series/DEXJPUS)** — PRIMARY. Mesure: 2026-09-18. Dernière publication décalée; non substituée au vendredi 25.

Récupérations: 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:52:55.515Z (web10)

**CB — [World Gold Council — achats officiels déclarés](https://www.gold.org/goldhub/gold-focus/2026/09/central-bank-gold-statistics-central-banks-make-positive-headlines-gold)** — INDUSTRY. Mesure: 2026-07-31; publié 2026-09-03. Compilation IMF/banques centrales, +23 t juillet; achats non déclarés non estimés ici.

Récupérations: 2026-09-27T18:53:19.942Z (web12); 2026-09-27T18:53:30.315Z (web13)

**PHYS — [WGC — prime physique Chine/Inde](https://www.gold.org/goldhub/data/gold-premium)** — INDUSTRY. Mesure: Données jusqu’au 2026-09-18; page 2026-09-21. Graphique sans valeur extraite; moyenne mobile 5 jours, ne pas appeler prime spot du 25.

Récupérations: 2026-09-27T18:53:19.942Z (web12); 2026-09-27T18:53:30.315Z (web13)

**SGE — [SGE — prix de référence NYAuTN](https://en.sge.com.cn/data_CashSettlement/10002702)** — PRIMARY. Mesure: 2026-09-24. Asia Marker et calendar spreads: ni clôture NY de GC décembre ni prime physique Shanghai/Londres.

Récupérations: 2026-09-27T18:53:19.942Z (web12); 2026-09-27T18:53:57.979Z (web15)

**BEA — [BEA — PCE juillet et prochaine publication](https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026)** — PRIMARY. Mesure: Juillet 2026; prochaine publication 2026-09-30 08:30 EDT. 

Récupérations: 2026-09-27T18:53:19.942Z (web12); 2026-09-27T18:53:30.315Z (web13)

**BLS — [BLS — calendrier octobre](https://www.bls.gov/schedule/2026/10_sched.htm)** — PRIMARY. Mesure: JOLTS 29 septembre; emploi 2 octobre 2026. 

Récupérations: 2026-09-27T18:49:27.333Z (web9); 2026-09-27T18:52:55.515Z (web10)

**JOBS — [Reuters — semaine à venir](https://www.reuters.com/business/wall-st-week-ahead-jobs-report-inflation-data-test-us-rate-path-economic-2026-09-25/)** — SECONDARY. Mesure: Consensus consulté 2026-09-25. Payrolls attendu +100 000, chômage 4,2 %. Consensus susceptible de changer avant la publication.

Récupérations: 2026-09-27T18:48:39.161Z (web5); 2026-09-27T18:48:51.784Z (web6); 2026-09-27T18:49:04.121Z (web7)

**MARGINS — [CME — marges Gold](https://www.cmegroup.com/markets/metals/precious/gold.margins.html)** — PRIMARY. Mesure: Fenêtre requise 2026-09-21/25. Table numérique non extraite; aucun appel de marge effectif identifié.

Récupérations: 2026-09-27T18:55:11.487Z (web18); 2026-09-27T18:55:27.300Z (web19); 2026-09-27T18:55:40.295Z (web20)

**GLDH — [State Street — archive officielle GLD, feuille navhist](https://www.ssga.com/library-content/products/fund-data/etfs/us/navhist-us-en-gld.xlsx)** — PRIMARY. Mesure: 2026-09-18/25. Téléchargement binaire HTTP200 à 18:57:35.740939Z; lecture seule XML: A4:D10. Date, NAV, parts et actifs identifiés. Les parts, non l’AUM, servent à mesurer créations/rachats.

Récupérations: 2026-09-27T18:57:14.930Z (web23); 2026-09-27T18:57:35.740939Z (direct_gld_xlsx)

**MOVENEWS — [MarketWatch via Yahoo — volatilité obligataire](https://finance.yahoo.com/markets/articles/stock-market-could-due-nasty-125200161.html)** — SECONDARY. Mesure: 2026-09-25, 08:52 EDT. Signal qualitatif découvert dans recherche indexée; niveau MOVE et série primaire non obtenus. Aucun pourcentage repris.

Récupérations: 2026-09-27T18:55:11.487Z (web18)

## Intégrité des livrables analytiques

- `GOLD_EXPERIMENTAL_2026-09-27_COMPLET.json` — SHA-256 `7c2a41a4b076951005bb7f6515134ac4e6a4478a7f10dc1935681ba45c2dc18e` — 333515 octets.
- `GOLD_EXPERIMENTAL_2026-09-27_RAPPORT.md` — SHA-256 `0da2461da8a1d9013bb85ef4c3f1e666f1b38bf94049c18b500e564ab676e2da` — 109589 octets.

Les vérifications de dépôt Drive sont ajoutées à la note de run après transfert. Les contenus analytiques ne sont pas mis à jour par l’écriture du reçu.
