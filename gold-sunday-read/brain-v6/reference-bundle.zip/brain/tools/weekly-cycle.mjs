import { requiresForwardDecision } from "./family-readout.mjs";

function easternDay(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.valueOf())) return null;
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York", weekday: "short", year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(date).reduce((acc, part) => ({ ...acc, [part.type]: part.value }), {});
}

export function weeklyCycleProblems(state, parent = undefined) {
  if (!requiresForwardDecision(state)) return [];
  const problems = [];
  const cycle = state.weekly_cycle;
  if (!cycle) return ["weekly_cycle: required for new REAL market states"];
  const index = cycle.intermediate_index;
  const sunday = state.meta.run_type === "SUNDAY";
  if (sunday && (index !== 0 || cycle.origin_run_id !== state.meta.run_id))
    problems.push("Sunday weekly_cycle must start at index 0 with its own origin");
  if (!sunday) {
    if (![1, 2].includes(index)) problems.push("intermediate index must be 1 or 2");
    if (cycle.origin_run_id !== state.meta.origin_sunday_run_id) problems.push("weekly_cycle.origin_run_id must equal meta.origin_sunday_run_id");
    const day = easternDay(state.meta.evidence_cutoff_end);
    if (!day || !["Sun", "Mon", "Tue", "Wed", "Thu"].includes(day.weekday))
      problems.push("intermediate cutoff must be before Friday 00:00 America/New_York");
    if (parent?.weekly_cycle && (index !== parent.weekly_cycle.intermediate_index + 1 || cycle.origin_run_id !== parent.weekly_cycle.origin_run_id))
      problems.push("intermediate index and origin must continue directly from supplied parent");
    if (parent && state.meta.parent_run_id !== parent.meta?.run_id) problems.push("weekly-cycle parent must be the immediate parent state");
  }
  return problems;
}

export function weeklyHandoffProblems(handoff, state = undefined) {
  if (!state || !requiresForwardDecision(state)) return [];
  const problems = [];
  const cycle = state.weekly_cycle;
  if (!cycle) return ["weekly-cycle state missing at handoff validation"];
  if (!handoff.weekly_cycle || handoff.weekly_cycle.intermediate_index !== cycle.intermediate_index || handoff.weekly_cycle.origin_run_id !== cycle.origin_run_id)
    problems.push("handoff weekly_cycle must match the sealed state");
  const closed = cycle.intermediate_index === 2;
  if (closed && (handoff.handoff_status !== "CLOSED" || handoff.next_execution !== null))
    problems.push("after the second intermediate handoff must be CLOSED with no next_execution");
  if (!closed && handoff.handoff_status === "CLOSED" && handoff.next_execution !== null)
    problems.push("CLOSED handoff cannot schedule another intermediate");
  if (handoff.handoff_status === "ACTIVE") {
    if (!handoff.next_execution?.requested_at) problems.push("ACTIVE handoff requires next_execution.requested_at");
    else {
      const when = easternDay(handoff.next_execution.requested_at);
      if (!when || !["Sun", "Mon", "Tue", "Wed", "Thu"].includes(when.weekday))
        problems.push("handoff may not schedule an intermediate on Friday or Saturday ET");
      if (state.meta?.week_of && when) {
        const monday = new Date(`${state.meta.week_of}T00:00:00Z`);
        const friday = new Date(monday.valueOf() + 4 * 24 * 60 * 60 * 1000);
        const localDay = `${when.year}-${when.month}-${when.day}`;
        if (Number.isNaN(monday.valueOf()) || localDay < state.meta.week_of || localDay >= friday.toISOString().slice(0, 10))
          problems.push("handoff requested intermediate must belong to the originating Monday–Thursday week");
      }
      if (Date.parse(handoff.next_execution.requested_at) <= Date.parse(state.meta.evidence_cutoff_end))
        problems.push("handoff cannot request a recap before or at the current evidence cutoff");
    }
  }
  if (!["ACTIVE", "CLOSED"].includes(handoff.handoff_status)) problems.push("handoff_status must be ACTIVE or CLOSED");
  return problems;
}
