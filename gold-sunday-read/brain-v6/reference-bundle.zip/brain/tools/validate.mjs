#!/usr/bin/env node
// Validator for the Gold Sunday Read / Continuous Recap canonical documents.
//
// Runs two layers of validation, matching the two layers described in the specs:
//  1. Structural (JSON Schema, draft 2020-12, via ajv) against
//     schema/sunday_read.schema.json and schema/next_gold_recap.schema.json.
//  2. Protocol-level checks that JSON Schema cannot express on its own
//     (ID leakage into human copy, glossary resolution, walkthrough
//     reference integrity, frontend-eligibility flags, FR/EN structural
//     parity) as required by GOLD_SUNDAY_READ_RUN_PROTOCOL.md,
//     GOLD_PRESENTATION_V3_SPEC.md, GOLD_CONTINUOUS_RECAP_PROTOCOL.md and
//     GOLD_NEXT_RECAP_HANDOFF_SPEC.md.
//
// Usage: node tools/validate.mjs              (historical example + all fixtures)
//        node tools/validate.mjs <file.json>… (the state, handoff and run completion
//        record of one real run, paired by run id; a REAL state without its
//        completion record fails)
//
// Procedural traces (phase order, question outcomes, source recovery, Sunday and
// intermediate proofs, run completion record) are specified in
// GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md and implemented in tools/procedural-audit.mjs.

import { readFileSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";
import { presentationCoverageProblems } from "./presentation-coverage.mjs";
import { intermediateNarrativeProblems } from "./intermediate-narrative.mjs";
import { familyReadoutProblems, continuityCheckpointProblems } from "./family-readout.mjs";
import { weeklyCycleProblems, weeklyHandoffProblems } from "./weekly-cycle.mjs";
import { proceduralAuditProblems, parentConsistencyProblems, completionRecordProblems, canonicalSha256, requiresProceduralAudit, isFrontendEligibleMarketState } from "./procedural-audit.mjs";

import { EDITORIAL_EFFECTIVE_AT, editorialProblems, editorialHandoffProblems } from './editorial.mjs';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));

function loadJSON(relPath) {
  return JSON.parse(readFileSync(join(ROOT, relPath), "utf8"));
}

const ajv = new Ajv2020({ allErrors: true, strict: true, allowUnionTypes: true });
addFormats(ajv);

const sundaySchema = loadJSON("schema/sunday_read.schema.json");
const handoffSchema = loadJSON("schema/next_gold_recap.schema.json");
const edgeCheckRequestSchema = loadJSON("schema/gold_edge_check_request.schema.json");
const edgeCheckResultSchema = loadJSON("schema/gold_edge_check_result.schema.json");
const completionRecordSchema = loadJSON("schema/run_completion_record.schema.json");

const validateEditorial = ajv.compile(loadJSON("schema/gold_editorial.schema.json"));
const validateSunday = ajv.compile(sundaySchema);
const validateHandoff = ajv.compile(handoffSchema);
const validateEdgeCheckRequest = ajv.compile(edgeCheckRequestSchema);
const validateEdgeCheckResult = ajv.compile(edgeCheckResultSchema);
const validateCompletionRecord = ajv.compile(completionRecordSchema);

let failures = 0;
let checks = 0;

function report(name, ok, details) {
  checks += 1;
  if (ok) {
    console.log(`  PASS  ${name}`);
  } else {
    failures += 1;
    console.log(`  FAIL  ${name}`);
    if (details) {
      for (const line of [].concat(details)) console.log(`        - ${line}`);
    }
  }
}

function collectIds(doc) {
  const ids = [];
  for (const n of doc.scenario_tree?.nodes ?? []) if (n.id) ids.push(n.id);
  for (const e of doc.scenario_tree?.edges ?? []) if (e.id) ids.push(e.id);
  return ids.filter((id) => id && id.length >= 2);
}

// Structured reference fields are explicitly allowed to carry raw internal
// IDs (GOLD_PRESENTATION_V3_SPEC.md #3, GOLD_SUNDAY_READ_OUTPUT_SPEC.md
// #0.3.1). Only the values reachable through other keys are prose that a
// human will actually read.
const STRUCTURED_REFERENCE_KEYS = new Set([
  "node_id", "edge_id", "from_node_id", "to_node_id",
  "node_refs", "edge_refs", "branch_refs", "branch_node_ids",
  "glossary_id", "glossary_refs", "id",
]);

function collectHumanCopyStrings(locale) {
  const strings = [];
  const walk = (val, key) => {
    if (STRUCTURED_REFERENCE_KEYS.has(key)) return;
    if (typeof val === "string") strings.push(val);
    else if (Array.isArray(val)) val.forEach((v) => walk(v, key));
    else if (val && typeof val === "object") for (const [k, v] of Object.entries(val)) walk(v, k);
  };
  if (locale) walk(locale, null);
  return strings;
}

function checkNoRawIdsInCopy(doc, docLabel) {
  const ids = collectIds(doc);
  const problems = [];
  for (const localeName of ["fr", "en"]) {
    const locale = doc.presentation?.[localeName];
    if (!locale) continue;
    const strings = collectHumanCopyStrings(locale);
    for (const id of ids) {
      for (const s of strings) {
        if (s.includes(id)) {
          problems.push(`locale ${localeName}: literal ID "${id}" found in human-facing copy: "${s.slice(0, 80)}..."`);
        }
      }
    }
  }
  report(`${docLabel}: no raw scenario node/edge IDs in human-facing copy`, problems.length === 0, problems);
}

function checkNoRawGlossaryMarkup(doc, docLabel) {
  const pattern = /\[\[[^\]|]+\|[^\]]+\]\]/;
  const problems = [];
  for (const localeName of ["fr", "en"]) {
    const locale = doc.presentation?.[localeName];
    if (!locale) continue;
    for (const s of collectHumanCopyStrings(locale)) {
      if (pattern.test(s)) problems.push(`locale ${localeName}: raw glossary markup found in "${s.slice(0, 80)}..."`);
    }
  }
  report(`${docLabel}: zero raw [[GLOSSARY_ID|text]] tokens in V3/V4 human copy`, problems.length === 0, problems);
}

function checkLocalizedEdgesHaveCausalCopy(doc, docLabel) {
  if (![3, 4].includes(doc.presentation?.version)) {
    report(`${docLabel}: every displayed relation has causal copy (skipped, not V3/V4)`, true);
    return;
  }
  const problems = [];
  for (const localeName of ["fr", "en"]) {
    const edges = doc.presentation?.[localeName]?.scenario_tree_v3?.edges ?? [];
    for (const e of edges) {
      if (!e.display_label || !e.display_explanation) {
        problems.push(`locale ${localeName}: edge ${e.edge_id} missing display_label or display_explanation`);
      }
    }
  }
  report(`${docLabel}: every displayed relation has causal copy`, problems.length === 0, problems);
}

function checkStructuredReferencesResolve(doc, docLabel) {
  const problems = [];
  const nodeIds = new Set((doc.scenario_tree?.nodes ?? []).map((n) => n.id));
  const edgeIds = new Set((doc.scenario_tree?.edges ?? []).map((e) => e.id).filter(Boolean));
  const glossaryIds = new Set((doc.glossary ?? []).map((g) => g.id));

  for (const localeName of ["fr", "en"]) {
    const locale = doc.presentation?.[localeName];
    if (!locale) continue;

    for (const step of locale.walkthrough?.steps ?? []) {
      for (const ref of step.node_refs ?? []) if (!nodeIds.has(ref)) problems.push(`${localeName} walkthrough step ${step.id}: node_ref ${ref} does not resolve`);
      for (const ref of step.edge_refs ?? []) if (!edgeIds.has(ref)) problems.push(`${localeName} walkthrough step ${step.id}: edge_ref ${ref} does not resolve`);
    }

    const v3Nodes = locale.scenario_tree_v3?.nodes ?? [];
    const v3Edges = locale.scenario_tree_v3?.edges ?? [];
    for (const n of v3Nodes) {
      if (!nodeIds.has(n.node_id)) problems.push(`${localeName} scenario_tree_v3 node_id ${n.node_id} does not resolve to scenario_tree.nodes`);
      for (const ref of n.glossary_refs ?? []) if (!glossaryIds.has(ref)) problems.push(`${localeName} node ${n.node_id}: glossary_refs ${ref} does not resolve`);
    }
    for (const e of v3Edges) {
      if (e.edge_id && !edgeIds.has(e.edge_id)) problems.push(`${localeName} scenario_tree_v3 edge_id ${e.edge_id} does not resolve to scenario_tree.edges`);
      if (!nodeIds.has(e.from_node_id)) problems.push(`${localeName} edge ${e.edge_id}: from_node_id ${e.from_node_id} does not resolve`);
      if (!nodeIds.has(e.to_node_id)) problems.push(`${localeName} edge ${e.edge_id}: to_node_id ${e.to_node_id} does not resolve`);
    }

    const collectRefs = (obj) => {
      const refs = [];
      const walk = (val, key) => {
        if (key === "glossary_refs" && Array.isArray(val)) refs.push(...val);
        else if (Array.isArray(val)) val.forEach((v) => walk(v, key));
        else if (val && typeof val === "object") for (const [k, v] of Object.entries(val)) walk(v, k);
      };
      walk(obj, null);
      return refs;
    };
    for (const ref of collectRefs(locale)) {
      if (!glossaryIds.has(ref)) problems.push(`${localeName}: glossary_refs entry "${ref}" does not resolve in glossary[]`);
    }
  }
  report(`${docLabel}: all structured references resolve`, problems.length === 0, problems);
}

function checkFrEnParity(doc, docLabel) {
  const fr = doc.presentation?.fr;
  const en = doc.presentation?.en;
  const problems = [];
  if (fr && en) {
    if (!!fr.direction_state !== !!en.direction_state) problems.push("direction_state present in one locale but not the other");
    if (fr.direction_state && en.direction_state) {
      for (const key of ["macro_direction", "directional_asymmetry", "positioning_asymmetry", "edge"]) {
        if (fr.direction_state[key]?.value !== en.direction_state[key]?.value) {
          problems.push(`FR/EN analytical conclusion mismatch on ${key}: fr=${fr.direction_state[key]?.value} en=${en.direction_state[key]?.value}`);
        }
      }
    }
  }
  if (doc.direction_state) {
    // the analytical direction_state is the single source of truth; presentation must not contradict it
    for (const localeName of ["fr", "en"]) {
      const locale = doc.presentation?.[localeName];
      if (!locale?.direction_state) continue;
      for (const key of ["macro_direction", "directional_asymmetry", "positioning_asymmetry", "edge"]) {
        if (locale.direction_state[key]?.value !== doc.direction_state[key]) {
          problems.push(`${localeName} presentation.direction_state.${key} (${locale.direction_state[key]?.value}) contradicts analytical direction_state.${key} (${doc.direction_state[key]})`);
        }
      }
    }
  }
  report(`${docLabel}: no analytical conclusion changes during presentation migration (FR/EN + analytical parity)`, problems.length === 0, problems);
}

function checkAnalyticalPresentationCoverage(doc, docLabel) {
  const problems = presentationCoverageProblems(doc);
  report(`${docLabel}: material analytical coverage is represented in final FR/EN V4 presentation`, problems.length === 0, problems);
}

function checkHandoffNotFrontendEligible(doc, docLabel) {
  const ok = doc.document_type === "NEXT_GOLD_RECAP_HANDOFF" && doc.frontend_eligible === false;
  report(`${docLabel}: handoff is not frontend eligible`, ok);
}

function checkMarketStateFrontendEligible(doc, docLabel) {
  if (!doc.meta?.run_type) {
    report(`${docLabel}: frontend_eligible metadata present (skipped, not a V3 lineage document)`, true);
    return;
  }
  const ok = doc.meta.document_type === "GOLD_MARKET_STATE" && doc.meta.frontend_eligible === true;
  report(`${docLabel}: market-state document is correctly marked frontend eligible`, ok);
}

function checkUniqueAndResolvableReferences(doc, docLabel) {
  const problems = [];
  const groups = [
    ["evidence", doc.evidence ?? [], "id"],
    ["sources", doc.sources ?? [], "source_id"],
    ["scenario nodes", doc.scenario_tree?.nodes ?? [], "id"],
    ["scenario edges", doc.scenario_tree?.edges ?? [], "id"],
    ["glossary", doc.glossary ?? [], "id"],
  ];
  const allIds = new Map();
  for (const [group, values, key] of groups) {
    const seen = new Set();
    for (const value of values) {
      const id = value[key];
      if (!id) continue;
      if (seen.has(id)) problems.push(`${group}: duplicate ID ${id}`);
      seen.add(id);
      if (allIds.has(id) && allIds.get(id) !== group) problems.push(`duplicate ID ${id} across ${allIds.get(id)} and ${group}`);
      allIds.set(id, group);
    }
  }
  const evidenceIds = new Set((doc.evidence ?? []).map((x) => x.id));
  const sourceIds = new Set((doc.sources ?? []).map((x) => x.source_id));
  for (const evidence of doc.evidence ?? []) {
    for (const ref of evidence.source_refs ?? []) if (!sourceIds.has(ref)) problems.push(`evidence ${evidence.id}: broken source_ref ${ref}`);
  }
  const checkEvidenceRefs = (obj, path = "") => {
    if (Array.isArray(obj)) return obj.forEach((x, i) => checkEvidenceRefs(x, `${path}[${i}]`));
    if (!obj || typeof obj !== "object") return;
    for (const [key, value] of Object.entries(obj)) {
      if (key === "evidence_refs" && Array.isArray(value)) for (const ref of value) if (!evidenceIds.has(ref)) problems.push(`${path}: broken evidence_ref ${ref}`);
      else checkEvidenceRefs(value, path ? `${path}.${key}` : key);
    }
  };
  checkEvidenceRefs(doc);
  report(`${docLabel}: IDs are unique and evidence/source references resolve`, problems.length === 0, problems);
}

// Scenario-explanation branch refs must resolve to real scenario-tree nodes.
// (Legacy `catalysts[].branch_refs` and `priced_in.surprise_candidates[].branch_refs`
// use an older free-form branch-label namespace and are deliberately not forced
// to resolve, to preserve historical compatibility.)
function checkScenarioBranchRefs(doc, docLabel) {
  const problems = [];
  const nodeIds = new Set((doc.scenario_tree?.nodes ?? []).map((n) => n.id));
  for (const explanation of doc.scenario_explanations ?? []) {
    for (const ref of explanation.branch_node_ids ?? []) {
      if (!nodeIds.has(ref)) problems.push(`scenario_explanations ${explanation.id}: branch_node_id ${ref} does not resolve to scenario_tree.nodes`);
    }
  }
  report(`${docLabel}: scenario-explanation branch references resolve`, problems.length === 0, problems);
}

// Chronology: a run's declared evidence window must be ordered and internally
// consistent, and no evidence may claim to predate the run's own start.
function checkChronology(doc, docLabel) {
  const problems = [];
  const asTime = (value) => {
    if (typeof value !== "string" || !value) return null;
    const t = Date.parse(value.length === 10 ? `${value}T00:00:00Z` : value);
    return Number.isNaN(t) ? null : t;
  };
  const start = asTime(doc.meta?.evidence_cutoff_start);
  const end = asTime(doc.meta?.evidence_cutoff_end);
  if (start !== null && end !== null && start > end) problems.push("meta.evidence_cutoff_start is later than meta.evidence_cutoff_end");
  const generated = asTime(doc.meta?.generated_at);
  if (generated !== null && end !== null && generated < end) problems.push("meta.generated_at precedes meta.evidence_cutoff_end");
  const catalyst = doc.dated_catalyst_assessment;
  if (catalyst?.expiry_status === "EXPIRED" && catalyst.scheduled_at && generated !== null) {
    const sched = asTime(catalyst.scheduled_at);
    if (sched !== null && sched > generated) problems.push("dated_catalyst_assessment.scheduled_at is in the future but expiry_status is EXPIRED");
  }
  if (catalyst?.expiry_status === "CURRENT" && catalyst.scheduled_at && generated !== null) {
    const sched = asTime(catalyst.scheduled_at);
    if (sched !== null && sched < generated) problems.push("dated_catalyst_assessment.scheduled_at is in the past but expiry_status is CURRENT");
  }
  report(`${docLabel}: chronology is internally consistent`, problems.length === 0, problems);
}

// A Sunday Read is a plan for its report week.  This intentionally validates
// semantic coverage rather than a word/node/source count.
function checkSundayReadScope(doc, docLabel) {
  if (doc.meta?.data_mode !== "REAL" || doc.meta?.run_type !== "SUNDAY") {
    report(`${docLabel}: Sunday planning scope (skipped, not a new REAL Sunday run)`, true);
    return;
  }
  const problems = [];
  const scope = doc.time_scope;
  const day = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d ?? "") ? new Date(`${d}T00:00:00Z`).getUTCDay() : -1;
  if (!scope) problems.push("report-week scope is missing");
  else {
    if (day(scope.reviewed_week_start) !== 1 || day(scope.reviewed_week_end) !== 5) problems.push("reviewed_week must be an explicit Monday-to-Friday market week");
    if (day(scope.report_week_start) !== 1 || day(scope.report_week_end) !== 5) problems.push("report_week must be an explicit Monday-to-Friday preparation week");
    if (scope.report_week_start <= scope.reviewed_week_end) problems.push("report_week must follow reviewed_week");
    if (doc.meta.week_of !== scope.report_week_start) problems.push("meta.week_of must designate the prepared report_week start");
    if (Date.parse(scope.information_cutoff) > Date.parse(doc.meta.generated_at)) problems.push("information_cutoff cannot be after generated_at");
    if (doc.presentation?.scope && (doc.presentation.scope.reviewed_week_start !== scope.reviewed_week_start || doc.presentation.scope.upcoming_week_start !== scope.report_week_start || doc.presentation.scope.upcoming_week_end !== scope.report_week_end)) problems.push("presentation.scope contradicts canonical time_scope");
  }
  const forbidden = /corrective rebuild|reconstruction corrective|nouvelle analyse complète|new complete analysis|contexte du lundi séparé|separate monday context|rapport de remplacement|replacement report/i;
  const titleTexts = [doc.presentation?.fr?.title, doc.presentation?.en?.title, doc.presentation?.fr?.subtitle, doc.presentation?.en?.subtitle].filter(Boolean);
  if (titleTexts.some((x) => forbidden.test(x))) problems.push("visible title/subtitle exposes corrective procedure");
  const locales = [doc.presentation?.fr, doc.presentation?.en];
  for (const locale of locales) {
    if (!locale?.market_story?.past_week || !locale?.market_story?.current_setup || !locale?.market_story?.week_ahead) problems.push("each locale must separate past_week, current_setup and week_ahead");
    if (!locale?.horizons || !locale?.priced_in || !locale?.asymmetry || !locale?.walkthrough) problems.push("each locale omits a material report-week analytical conclusion");
  }
  for (const entry of doc.weekly_timeline ?? []) if (scope && entry.date > scope.reviewed_week_end) problems.push(`post-Friday observation ${entry.date} appears in reviewed-week chronology`);
  report(`${docLabel}: explicit reviewed/report week, cutoff, forward planning scope and clean user copy`, problems.length === 0, problems);
}

// Lineage: a rolling-state document must be able to reconstruct its chain back
// to an origin Sunday run.
function checkLineage(doc, docLabel) {
  if (!doc.meta?.run_type) {
    report(`${docLabel}: rolling-state lineage (skipped, not a lineage document)`, true);
    return;
  }
  const problems = [];
  const runType = doc.meta.run_type;
  const parent = doc.meta.parent_run_id;
  const origin = doc.meta.origin_sunday_run_id;
  if (!origin) problems.push("meta.origin_sunday_run_id is required for a rolling-state document");
  if (runType === "SUNDAY") {
    if (parent !== null && parent !== undefined) problems.push("Sunday parent_run_id must be null");
    if (origin && doc.meta.run_id && origin !== doc.meta.run_id) problems.push("Sunday origin_sunday_run_id must equal its own run_id");
  }
  if (runType === "INTERMEDIATE") {
    if (!parent) problems.push("Intermediate parent_run_id must name the parent state");
    if (parent && doc.meta.run_id && parent === doc.meta.run_id) problems.push("Intermediate parent_run_id cannot be its own run_id");
  }
  if (doc.consumed_handoff_id !== undefined && !doc.handoff_version) problems.push("consumed_handoff_id is present but handoff_version is missing");
  if (doc.handoff_version !== undefined && !doc.consumed_handoff_id) problems.push("handoff_version is present but consumed_handoff_id is missing");
  report(`${docLabel}: rolling-state lineage is complete`, problems.length === 0, problems);
}

// Canonical localized display maps for the contract. Structured validation
// against these maps is preferred over keyword matching (run protocol §6B).
const QUALITY_DISPLAY_FR = {
  STRONG: "Qualité d'opportunité forte",
  MEDIUM: "Qualité d'opportunité moyenne",
  WEAK: "Qualité d'opportunité faible",
  TRAP: "Qualité d'opportunité piège",
  UNKNOWN: "Qualité d'opportunité inconnue",
};
const QUALITY_DISPLAY_EN = {
  STRONG: "Opportunity quality strong",
  MEDIUM: "Opportunity quality medium",
  WEAK: "Opportunity quality weak",
  TRAP: "Opportunity quality trap",
  UNKNOWN: "Opportunity quality unknown",
};
const READINESS_DISPLAY_FR = {
  READY_IF_TRIGGERED: "Prête si déclenchée",
  WAITING_FOR_CATALYST: "En attente du catalyseur",
  CATALYST_PRESENT_BUT_UNCONFIRMED: "Catalyseur présent mais non confirmé",
  NOT_READY: "Exécution non prête",
  UNKNOWN: "Préparation inconnue",
};
const READINESS_DISPLAY_EN = {
  READY_IF_TRIGGERED: "Ready if triggered",
  WAITING_FOR_CATALYST: "Waiting for catalyst",
  CATALYST_PRESENT_BUT_UNCONFIRMED: "Catalyst present but unconfirmed",
  NOT_READY: "Execution not ready",
  UNKNOWN: "Readiness unknown",
};

// Every structured evidence reference must resolve to a real evidence ID.
const EVIDENCE_REF_KEYS = new Set(["evidence_refs", "source_evidence_refs"]);
function collectEvidenceRefs(obj, path = "", out = []) {
  if (Array.isArray(obj)) {
    obj.forEach((x, i) => collectEvidenceRefs(x, `${path}[${i}]`, out));
  } else if (obj && typeof obj === "object") {
    for (const [key, value] of Object.entries(obj)) {
      if (EVIDENCE_REF_KEYS.has(key) && Array.isArray(value)) {
        for (const ref of value) out.push([path ? `${path}.${key}` : key, ref]);
      } else {
        collectEvidenceRefs(value, path ? `${path}.${key}` : key, out);
      }
    }
  }
  return out;
}

// An observation counts as "evidenced" only when it is declared observable
// AND carries a resolvable reference. A status enum alone is a claim, not proof.
function isEvidenced(value, evidenceIds) {
  if (!value || typeof value !== "object") return false;
  const observable = value.status && !["UNKNOWN", "NOT_APPLICABLE", "PARTIAL", "PUBLICATION_LAG"].includes(value.status);
  return Boolean(observable && (value.evidence_refs ?? []).some((r) => evidenceIds.has(r)));
}

function checkPositioningContract(doc, docLabel) {
  if (!doc.analysis_contract) {
    report(`${docLabel}: positioning/asymmetry contract (skipped, legacy document)`, true);
    return;
  }
  const problems = [];
  const p = doc.positioning_evidence;
  const evidenceIds = new Set((doc.evidence ?? []).map((x) => x.id));

  // --- 1. Contract identity -------------------------------------------------
  const contract = doc.analysis_contract;
  if (contract.version !== 1) problems.push(`analysis_contract.version must be 1, got ${JSON.stringify(contract.version)}`);
  if (contract.name !== "POSITIONING_ASYMMETRY_EXECUTION_READINESS") problems.push(`analysis_contract.name must be POSITIONING_ASYMMETRY_EXECUTION_READINESS, got ${JSON.stringify(contract.name)}`);
  if (contract.no_scoring !== true) problems.push("analysis_contract.no_scoring must be true (no score, no checklist voting)");
  if (!Array.isArray(contract.explicit_unknowns)) problems.push("analysis_contract.explicit_unknowns must be an array (possibly empty) of declared gaps");

  const cot = p?.cot;
  if (!cot) {
    problems.push("positioning_evidence.cot is missing");
  } else {
    // --- 2. COT percentile provenance --------------------------------------
    for (const metric of ["gross_longs", "gross_shorts", "net_position"]) {
      const value = cot.percentiles?.[metric];
      if (!value) continue;
      if (value.value !== null && value.value !== undefined) {
        const missing = [];
        if (cot.lookback_weeks === null || cot.lookback_weeks === undefined) missing.push("lookback_weeks");
        if (!cot.report_date) missing.push("report_date");
        if (!cot.participant_population) missing.push("participant_population");
        if (!cot.metric_identity) missing.push("metric_identity");
        if (!["OBSERVED", "CALCULATED", "ESTIMATED"].includes(value.status)) missing.push("epistemic status");
        if (missing.length) problems.push(`COT percentile ${metric} lacks ${missing.join(", ")}`);
      }
    }
    const cotObserved = ["OBSERVED", "CALCULATED", "ESTIMATED"].includes(cot.epistemic_status);
    if (cotObserved && cot.lookback_weeks !== null && cot.lookback_weeks !== undefined && cot.lookback_weeks < 156) {
      problems.push(`COT lookback (${cot.lookback_weeks}w) is below the canonical 156 weeks without an explicit limitation`);
    }
    if (cotObserved && !cot.report_date) problems.push("COT is declared observable but states no report date");
    if (cotObserved && !cot.participant_population) problems.push("COT is declared observable but states no participant population");
    if (cotObserved && !cot.metric_identity) problems.push("COT is declared observable but states no metric identity");
  }

  // --- 3. Options / FOMO ---------------------------------------------------
  const options = p?.options_iv;
  if (options?.fomo_state === "FOMO_CONFIRMED") {
    if (options.price_direction !== "UP" || options.iv_direction !== "UP") problems.push("FOMO_CONFIRMED requires price up and IV up");
    if (options.event_risk_check !== "CLEAR") problems.push("FOMO_CONFIRMED requires a clear event-premium check");
    if (options.call_put_skew_direction !== "CALLS" || !isEvidenced(options.options_volume_oi, evidenceIds)) {
      problems.push("FOMO_CONFIRMED requires evidenced call skew and reliable call demand/volume or OI");
    }
    if (!options.interpretation || !options.evidence_refs?.length) problems.push("FOMO_CONFIRMED requires an auditable interpretation and evidence refs");
  }
  if (options?.fomo_state === "EVENT_VOL_PREMIUM" && options.event_risk_check !== "PRESENT") {
    problems.push("EVENT_VOL_PREMIUM requires the event-premium check to be PRESENT");
  }
  // Gold skew must be judged against Gold's own baseline, not another asset's.
  const skew = p?.gold_skew_baseline;
  if (skew && skew.skew_direction !== "UNKNOWN" && skew.status !== "UNKNOWN") {
    if (!skew.tenor || !skew.moneyness) problems.push("a non-UNKNOWN Gold skew needs its tenor and moneyness");
    if (skew.relative_to_gold_history === "UNKNOWN" && !["UNKNOWN", "LIMITED"].includes(skew.status)) {
      problems.push("Gold skew cannot be classified without a Gold-specific historical comparison");
    }
    if (!skew.event_context) problems.push("Gold skew needs the event context against which it is read");
  }

  // --- 4. Gamma ------------------------------------------------------------
  const gamma = p?.gamma;
  if (gamma) {
    if (gamma.dealer_sign_claim === "SUPPORTED") {
      if (gamma.status === "UNKNOWN") problems.push("dealer-gamma sign cannot be claimed SUPPORTED while the gamma status is UNKNOWN");
      if (gamma.status === "MODEL_ESTIMATED" && !gamma.model_method) problems.push("model-estimated gamma needs a documented model method");
      if (gamma.status === "OBSERVED" && !(gamma.evidence_refs ?? []).some((r) => evidenceIds.has(r))) problems.push("observed dealer gamma claim lacks legitimate evidence refs");
    }
    if (gamma.status === "OBSERVED" && gamma.dealer_sign_claim === "NONE" && !(gamma.evidence_refs ?? []).length) {
      problems.push("observed gamma status needs evidence refs even when no dealer sign is claimed");
    }
  }

  // --- 5. Physical / SGE ---------------------------------------------------
  const sge = p?.physical_sge;
  if (sge?.divergence === "CONFIRMED") {
    if (sge.status !== "OBSERVED") problems.push("confirmed SGE divergence requires an OBSERVED status");
    const badComparability = Object.entries(sge.comparability ?? {}).filter(([, x]) => !x || x === "unknown");
    if (badComparability.length) problems.push(`confirmed SGE divergence lacks comparable windows/methodology: ${badComparability.map(([k]) => k).join(", ")}`);
    if (!isEvidenced(sge.sge_premium_discount, evidenceIds)) problems.push("confirmed SGE divergence requires an evidenced premium/discount observation");
  }

  // Every structured evidence reference anywhere in the contract must resolve.
  for (const scope of ["positioning_evidence", "dated_catalyst_assessment", "invalidation_fuse", "opportunity_quality", "execution_readiness"]) {
    for (const [path, ref] of collectEvidenceRefs(doc[scope], scope)) {
      if (!evidenceIds.has(ref)) problems.push(`${path}: broken evidence_ref "${ref}" does not resolve in evidence[]`);
    }
  }

  const quality = doc.opportunity_quality;
  const readiness = doc.execution_readiness;
  const catalyst = doc.dated_catalyst_assessment;
  const fuse = doc.invalidation_fuse;

  // A catalyst is "activated" only when a real activation mechanism is stated.
  const catalystActivated = catalyst?.status === "PRESENT" && Boolean(catalyst?.activation_reason) && Boolean(catalyst?.event_name);
  const activationMechanismStated = Boolean(catalyst?.activation_reason);
  const fuseIdentified = fuse?.status === "IDENTIFIED" && fuse?.bounds_thesis === true;

  const cotEvidenced = cot && ["OBSERVED", "CALCULATED", "ESTIMATED"].includes(cot.epistemic_status);
  const flowsEvidenced = (p?.etf_flows?.observations ?? []).some((o) => isEvidenced(o, evidenceIds)) && p?.etf_flows?.price_confirmation !== "UNKNOWN";
  const oiEvidenced = p?.price_open_interest?.causal_status && p.price_open_interest.causal_status !== "UNKNOWN";
  const optionsEvidenced = isEvidenced(options?.gvz, evidenceIds) || isEvidenced(options?.skew_change, evidenceIds) || isEvidenced(options?.options_volume_oi, evidenceIds);
  const hasPositioningEvidence = Boolean(cotEvidenced || flowsEvidenced || oiEvidenced || optionsEvidenced);

  // --- 6. Opportunity quality semantics ------------------------------------
  if (quality?.value === "STRONG") {
    if (!hasPositioningEvidence) problems.push("STRONG opportunity quality requires positioning evidence (COT, flows, price/OI or options)");
    if (!catalystActivated && !activationMechanismStated) problems.push("STRONG opportunity quality requires a catalyst or activation mechanism");
    if (!fuseIdentified) problems.push("STRONG opportunity quality requires a measurable invalidation/fuse that bounds the thesis");
    if (!quality.evidence_refs?.length) problems.push("STRONG opportunity quality requires evidence refs");
    if (!contract.explicit_unknowns?.length && !hasPositioningEvidence) problems.push("STRONG opportunity quality requires observability or declared unknowns");
  }
  if (quality?.value === "TRAP") {
    const positioning = doc.direction_state?.positioning_asymmetry;
    const crowded = ["CROWDED", "LATE"].includes(positioning);
    const extreme = cot && cot.epistemic_status === "CALCULATED" && Object.values(cot.percentiles ?? {}).some((v) => typeof v.value === "number" && (v.value >= 85 || v.value <= 30));
    const lateState = ["CROWDED", "LATE"].includes(doc.late?.status);
    if (!crowded && !extreme && !lateState) problems.push("TRAP requires same-direction crowding, lateness or extreme evidence");
  }

  // --- 7. Execution readiness semantics ------------------------------------
  if (readiness?.value === "READY_IF_TRIGGERED") {
    if (!catalystActivated && !activationMechanismStated) problems.push("READY_IF_TRIGGERED requires a dated catalyst or explicit activation mechanism");
    if (!fuseIdentified) problems.push("READY_IF_TRIGGERED requires an identified measurable invalidation/fuse");
  }
  if (readiness?.value === "CATALYST_PRESENT_BUT_UNCONFIRMED" && !catalyst?.event_name) {
    problems.push("CATALYST_PRESENT_BUT_UNCONFIRMED requires a named catalyst");
  }
  if (catalyst?.scheduled_at && !catalyst.timezone) problems.push("material catalyst timestamp requires a timezone");
  if (catalyst?.expiry_status === "EXPIRED" && readiness?.value === "WAITING_FOR_CATALYST") problems.push("expired catalyst cannot remain pending/current");

  // --- 8. UNKNOWN must never be relabeled as neutral ----------------------
  const declaredUnknowns = contract.explicit_unknowns ?? [];
  const positioningIsUnknown = cot && !["OBSERVED", "CALCULATED", "ESTIMATED"].includes(cot.epistemic_status);
  if (positioningIsUnknown) {
    const declared = declaredUnknowns.some((x) => /COT|position|flow|gamma/i.test(String(x)));
    // Neutrality is an assertion. It may not be produced by absent evidence.
    if (doc.direction_state?.positioning_asymmetry === "BALANCED") {
      problems.push("UNKNOWN positioning evidence must not be relabeled as neutral/balanced (positioning_asymmetry=BALANCED)");
    }
    if (quality?.value === "UNKNOWN" && !declared) {
      problems.push("UNKNOWN positioning evidence must be declared in analysis_contract.explicit_unknowns");
    }
  }

  // --- 9. Localized FR/EN copy and analytical parity -----------------------
  if (quality) {
    if (quality.display_fr !== QUALITY_DISPLAY_FR[quality.value]) problems.push(`French opportunity-quality display "${quality.display_fr}" does not match canonical ${QUALITY_DISPLAY_FR[quality.value]} for ${quality.value}`);
    if (quality.display_en !== QUALITY_DISPLAY_EN[quality.value]) problems.push(`English opportunity-quality display "${quality.display_en}" does not match canonical ${QUALITY_DISPLAY_EN[quality.value]} for ${quality.value}`);
  }
  if (readiness) {
    if (readiness.display_fr !== READINESS_DISPLAY_FR[readiness.value]) problems.push(`French execution-readiness display "${readiness.display_fr}" does not match canonical ${READINESS_DISPLAY_FR[readiness.value]} for ${readiness.value}`);
    if (readiness.display_en !== READINESS_DISPLAY_EN[readiness.value]) problems.push(`English execution-readiness display "${readiness.display_en}" does not match canonical ${READINESS_DISPLAY_EN[readiness.value]} for ${readiness.value}`);
  }

  const presentationLocalesPresent = Boolean(doc.presentation?.fr && doc.presentation?.en);
  if (presentationLocalesPresent) {
    const fr = doc.presentation.fr;
    const en = doc.presentation.en;
    // V3 presentation blocks must carry localized quality/readiness copy.
    for (const [localeName, locale] of [["fr", fr], ["en", en]]) {
      if (!locale.opportunity_quality?.display) problems.push(`presentation.${localeName}.opportunity_quality.display is required by the contract`);
      if (!locale.opportunity_quality?.explanation) problems.push(`presentation.${localeName}.opportunity_quality.explanation is required by the contract`);
      if (!locale.execution_readiness?.display) problems.push(`presentation.${localeName}.execution_readiness.display is required by the contract`);
      if (!locale.execution_readiness?.explanation) problems.push(`presentation.${localeName}.execution_readiness.explanation is required by the contract`);
    }
    // The localized display value must agree with the analytical value.
    if (fr.opportunity_quality?.display !== undefined && quality && fr.opportunity_quality.display !== quality.display_fr) {
      problems.push(`presentation.fr.opportunity_quality.display (${fr.opportunity_quality.display}) contradicts analytical display_fr (${quality.display_fr})`);
    }
    if (en.opportunity_quality?.display !== undefined && quality && en.opportunity_quality.display !== quality.display_en) {
      problems.push(`presentation.en.opportunity_quality.display (${en.opportunity_quality.display}) contradicts analytical display_en (${quality.display_en})`);
    }
    if (fr.execution_readiness?.display !== undefined && readiness && fr.execution_readiness.display !== readiness.display_fr) {
      problems.push(`presentation.fr.execution_readiness.display (${fr.execution_readiness.display}) contradicts analytical display_fr (${readiness.display_fr})`);
    }
    if (en.execution_readiness?.display !== undefined && readiness && en.execution_readiness.display !== readiness.display_en) {
      problems.push(`presentation.en.execution_readiness.display (${en.execution_readiness.display}) contradicts analytical display_en (${readiness.display_en})`);
    }
    // FR and EN must express the same structural conclusion (no silent drift).
    const frQualityPresent = Boolean(fr.opportunity_quality);
    const enQualityPresent = Boolean(en.opportunity_quality);
    if (frQualityPresent !== enQualityPresent) problems.push("FR/EN opportunity-quality copy present in one locale but not the other");
    const frReadinessPresent = Boolean(fr.execution_readiness);
    const enReadinessPresent = Boolean(en.execution_readiness);
    if (frReadinessPresent !== enReadinessPresent) problems.push("FR/EN execution-readiness copy present in one locale but not the other");
  }

  report(`${docLabel}: positioning/asymmetry/execution contract is coherent`, problems.length === 0, problems);
}

// A document participating in the rolling-state lineage is a *production* run.
// Production runs must opt into the positioning-asymmetry contract explicitly;
// silently reverting to the pre-contract V3 shape is a validation failure.
// Historical documents carry no meta.run_type and are unaffected, which is
// exactly how schema/minimal_v2_example.json stays valid.
const CONTRACT_MANDATORY_FIELDS = [
  "positioning_evidence",
  "dated_catalyst_assessment",
  "invalidation_fuse",
  "opportunity_quality",
  "execution_readiness",
  "direction_state",
];
function checkContractOptIn(doc, docLabel) {
  if (!doc.meta?.run_type) {
    report(`${docLabel}: analysis_contract opt-in (skipped, not a rolling-state production run)`, true);
    return;
  }
  const problems = [];
  if (!doc.analysis_contract) {
    problems.push(`a new ${doc.meta.run_type} production run must carry analysis_contract v1 (silent fallback to the pre-contract V3 shape is forbidden)`);
  } else {
    for (const field of CONTRACT_MANDATORY_FIELDS) {
      if (doc[field] === undefined || doc[field] === null) problems.push(`analysis_contract is present but required field ${field} is missing`);
    }
    if (!Array.isArray(doc.analysis_contract.explicit_unknowns)) problems.push("analysis_contract.explicit_unknowns must be an array");
  }
  // Localized FR/EN contract copy is mandatory for new production presentations.
  if ([3, 4].includes(doc.presentation?.version) && doc.presentation.fr && doc.presentation.en) {
    for (const localeName of ["fr", "en"]) {
      if (!doc.presentation[localeName].opportunity_quality) problems.push(`presentation.${localeName}.opportunity_quality is required by the contract for new production runs`);
      if (!doc.presentation[localeName].execution_readiness) problems.push(`presentation.${localeName}.execution_readiness is required by the contract for new production runs`);
    }
  }
  report(`${docLabel}: new production run opted into analysis_contract v1`, problems.length === 0, problems);
}

// Procedural audit (specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md): factual traces that
// the mandatory phases were attempted, in order, with an outcome or an explicit
// limitation. Required for new REAL Sunday/intermediate runs; FIXTURE and
// historical documents are checked only when they opt in by carrying the object.
function checkProceduralAudit(doc, docLabel, registry) {
  if (!doc.procedural_audit && !requiresProceduralAudit(doc)) {
    report(`${docLabel}: procedural audit (skipped, historical or non-REAL document without procedural_audit)`, true);
    return;
  }
  const problems = proceduralAuditProblems(doc);
  const parent = doc.meta?.parent_run_id ? registry.get(doc.meta.parent_run_id) : undefined;
  if (parent) problems.push(...parentConsistencyProblems(doc, parent));
  report(`${docLabel}: procedural audit proves every mandatory phase was attempted in order`, problems.length === 0, problems);
}

function validateSundayDoc(doc, label, registry = new Map()) {
  console.log(`\n${label}`);
  if (doc.format_version === "6.0") {
    const valid = validateEditorial(doc);
    report(`${label}: editorial v6 schema`, valid, valid ? null : ajv.errorsText(validateEditorial.errors, {separator:"\n"}).split("\n"));
    if (valid) {
      const problems = editorialProblems(doc, registry.get(doc.meta.parent_run_id));
      report(`${label}: editorial v6 evidence, gates, continuity and reader parity`, problems.length === 0, problems);
    }
    return;
  }
  report(`${label}: no silent fallback from current editorial contract`, !(doc.format_version || (doc.meta?.data_mode === "REAL" && Date.parse(doc.meta?.generated_at) >= Date.parse(EDITORIAL_EFFECTIVE_AT))), ["new REAL states require format_version 6.0; legacy validation is archive-only"]);
  const valid = validateSunday(doc);
  report(`${label}: validates against sunday_read.schema.json`, valid, valid ? null : ajv.errorsText(validateSunday.errors, { separator: "\n" }).split("\n"));
  checkNoRawIdsInCopy(doc, label);
  checkNoRawGlossaryMarkup(doc, label);
  checkLocalizedEdgesHaveCausalCopy(doc, label);
  checkStructuredReferencesResolve(doc, label);
  checkFrEnParity(doc, label);
  checkAnalyticalPresentationCoverage(doc, label);
  checkMarketStateFrontendEligible(doc, label);
  checkUniqueAndResolvableReferences(doc, label);
  checkScenarioBranchRefs(doc, label);
  checkChronology(doc, label);
  checkSundayReadScope(doc, label);
  checkLineage(doc, label);
  const narrativeProblems = intermediateNarrativeProblems(doc, registry.get(doc.meta?.parent_run_id));
  report(`${label}: intermediate narrative is localized, sourced, and consistent with its parent`, narrativeProblems.length === 0, narrativeProblems);
  const readoutProblems = familyReadoutProblems(doc);
  report(`${label}: family questions and rolling evolution contract`, readoutProblems.length === 0, readoutProblems);
  const cycleProblems = weeklyCycleProblems(doc, registry.get(doc.meta?.parent_run_id));
  report(`${label}: weekly origin, intermediate limit, and Friday cutoff`, cycleProblems.length === 0, cycleProblems);
  checkContractOptIn(doc, label);
  checkPositioningContract(doc, label);
  checkProceduralAudit(doc, label, registry);
}

function checkHandoffAsymmetryCheckpoints(doc, docLabel) {
  const problems = [];
  if (doc.handoff_version >= 2) {
    const checkpoints = doc.asymmetry_checkpoints ?? [];
    if (!checkpoints.length) problems.push("handoff version 2 or later must carry at least one asymmetry checkpoint");
    for (const checkpoint of checkpoints) {
      if (!checkpoint.evidence_to_refresh?.length) problems.push(`checkpoint ${checkpoint.checkpoint_id}: evidence_to_refresh must not be empty`);
      if (!checkpoint.transition_to_watch?.length) problems.push(`checkpoint ${checkpoint.checkpoint_id}: transition_to_watch must not be empty`);
    }
  }
  report(`${docLabel}: handoff carries next-run asymmetry checkpoints`, problems.length === 0, problems);
}

function validateHandoffDoc(doc, label, registry) {
  console.log(`\n${label}`);
  const valid = validateHandoff(doc);
  report(`${label}: validates against next_gold_recap.schema.json`, valid, valid ? null : ajv.errorsText(validateHandoff.errors, { separator: "\n" }).split("\n"));
  if (doc.market_state_format_version === "6.0") {
    if (valid) {
      const problems = editorialHandoffProblems(doc, registry.get(doc.created_by_run_id));
      report(`${label}: editorial handoff continuity`, problems.length === 0, problems);
    }
    return;
  }
  checkHandoffNotFrontendEligible(doc, label);
  checkHandoffAsymmetryCheckpoints(doc, label);
  const continuityProblems = continuityCheckpointProblems(doc, registry.get(doc.created_by_run_id));
  report(`${label}: next recap inherits verified state and six verdicts`, continuityProblems.length === 0, continuityProblems);
  const weeklyProblems = weeklyHandoffProblems(doc, registry.get(doc.created_by_run_id));
  report(`${label}: handoff cannot schedule an excess or Friday intermediate`, weeklyProblems.length === 0, weeklyProblems);
}

// A completion record seals the phases that cannot live inside the immutable
// market-state JSON (validation, Drive readback, handoff). It is checked against
// the state it seals whenever that state is available.
function validateCompletionDoc(doc, label, registry) {
  console.log(`\n${label}`);
  const valid = validateCompletionRecord(doc);
  report(`${label}: validates against run_completion_record.schema.json`, valid, valid ? null : ajv.errorsText(validateCompletionRecord.errors, { separator: "\n" }).split("\n"));
  report(`${label}: completion record is a control-plane file, not a frontend-eligible market state`, !isFrontendEligibleMarketState(doc) && doc.frontend_eligible === false && doc.storage_plane === "CONTROL");
  const state = registry.get(doc.market_state?.run_id);
  const problems = completionRecordProblems(doc, state);
  for (const [phase, record] of Object.entries(doc.phases ?? {})) {
    if (record.status === "FAILED" && !(doc.procedural_gaps ?? []).some((gap) => gap.phase === phase)) problems.push(`material procedural gap not declared: ${phase} is FAILED but no gap covers it`);
  }
  report(`${label}: run completion record proves validation, readback and handoff happened in order${state ? "" : " (sealed state not provided, cross-check skipped)"}`, problems.length === 0, problems);
}

function documentKind(doc) {
  if (doc.document_type === "NEXT_GOLD_RECAP_HANDOFF") return "handoff";
  if (doc.document_type === "GOLD_RUN_COMPLETION_RECORD") return "completion";
  return "state";
}

// Dot-prefixed fixture files are transient (negative-test) inputs and never act
// as a parent or as a sealed state for another document.
function validateSet(entries) {
  const stateRegistry = new Map();
  for (const { doc, transient } of entries) {
    if (!transient && documentKind(doc) === "state" && doc.meta?.run_id) {
      report(`unique state identity ${doc.meta.run_id}`, !stateRegistry.has(doc.meta.run_id));
      stateRegistry.set(doc.meta.run_id, doc);
    }
  }
  const sealed = new Set(entries.filter(({ doc }) => documentKind(doc) === "completion").map(({ doc }) => doc.market_state?.run_id));
  for (const { doc, label } of entries) {
    const kind = documentKind(doc);
    if (kind === "handoff") validateHandoffDoc(doc, label, stateRegistry);
    else if (kind === "completion") validateCompletionDoc(doc, label, stateRegistry);
    else {
      validateSundayDoc(doc, label, stateRegistry);
      if (!preflight && doc.format_version === "6.0" && doc.meta?.data_mode === "REAL") {
        const next = entries.find(x=>documentKind(x.doc)==="handoff" && x.doc.created_by_run_id===doc.meta.run_id && x.doc.market_state_format_version==="6.0")?.doc;
        report(`${label}: v6 bundle includes its next handoff`, !!next);
        const receipt = entries.find(x=>documentKind(x.doc)==="completion" && x.doc.market_state?.run_id===doc.meta.run_id)?.doc;
        if (next && receipt) report(`${label}: completion seals the supplied handoff`, receipt.handoff.handoff_id===next.handoff_id && receipt.handoff.handoff_version===next.handoff_version);
        if (doc.meta.run_type === "INTERMEDIATE") {
          const consumed = entries.find(x=>documentKind(x.doc)==="handoff" && x.doc.handoff_id===doc.consumed_handoff?.handoff_id)?.doc;
          report(`${label}: consumed handoff content matches`, !!consumed && consumed.handoff_version===doc.consumed_handoff.handoff_version && canonicalSha256(consumed)===doc.consumed_handoff.content_sha256 && consumed.parent_state_run_id===doc.meta.parent_run_id);
        }
      }
      if (!preflight && doc.meta?.data_mode === "REAL" && doc.meta?.run_type) {
        report(`${label}: REAL run has a run completion record (a state alone cannot claim the run is complete)`, sealed.has(doc.meta.run_id), [`run completion record missing for ${doc.meta.run_id}: validation, Drive readback and handoff are unproven`]);
      }
    }
  }
}

const preflight = process.argv.includes("--preflight");
const cliFiles = process.argv.slice(2).filter(x => x !== "--preflight");
if (cliFiles.length) {
  // Explicit files: validate exactly these documents (the state, handoff and
  // completion record of one real run), paired by run id.
  validateSet(cliFiles.map((file) => ({ doc: JSON.parse(readFileSync(file, "utf8")), label: file, transient: false })));
} else {
  // --- 1. Existing historical example must remain valid (backward compatibility) ---
  validateSundayDoc(loadJSON("schema/minimal_v2_example.json"), "schema/minimal_v2_example.json (historical V2 example, proxy for pre-existing production documents)");

  // Committed fixtures only. Negative/control scratch inputs are validated via
  // explicit CLI paths by their tests; an interrupted test must not poison this scan.
  const fixturesDir = join(ROOT, "tests", "fixtures");
  validateSet(readdirSync(fixturesDir).sort().filter((file) => file.endsWith(".json") && !file.startsWith(".")).map((file) => ({
    doc: loadJSON(join("tests", "fixtures", file)), label: `tests/fixtures/${file}`, transient: file.startsWith("."),
  })));
}

console.log(`\n${checks} checks run, ${failures} failed.`);
process.exit(failures > 0 ? 1 : 0);
