// Narrative obligations apply to newly produced REAL intermediate states.
// The cutoff keeps the immutable September 24 publication and older archives valid.
export const NARRATIVE_EFFECTIVE_AT = "2026-09-25T00:00:00Z";
const FIELDS = ["observed_since_parent", "what_changed", "what_remains_true", "unknowns", "next_watch", "decisive_limit"];
const CHANGE_FIELDS = ["previous", "current", "reason", "practical_consequence"];
const JUDGMENTS = ["macro_direction", "directional_asymmetry", "positioning_asymmetry", "edge", "opportunity_quality", "execution_readiness"];
const PLACEHOLDER = /(?:[Ee]xplication localisée non publiée|[Ll]ocalized explanation not published|[Uu]ne limite à documenter|[Ll]imit to be documented|\bSC-[A-Z0-9-]+\b|\bF[1-6]\s*[·:-]?\s*(?:UNCHANGED|UPDATED|PARTIAL)\b|\b(?:NO_EDGE|UNKNOWN|BEARISH|BULLISH)\b)/;

function rawJudgment(doc, key) {
  return key === "opportunity_quality" || key === "execution_readiness"
    ? doc?.[key]?.value : doc?.direction_state?.[key];
}

export function intermediateNarrativeProblems(doc, parent = null) {
  if (doc?.meta?.run_type !== "INTERMEDIATE") return [];
  const problems = [];
  const created = Date.parse(doc.meta.generated_at);
  const required = doc.meta.data_mode === "REAL" && Number.isFinite(created)
    && created >= Date.parse(NARRATIVE_EFFECTIVE_AT);
  const summary = doc.intermediate_summary;
  if (!summary) return required ? ["new REAL intermediate requires intermediate_summary"] : problems;

  if (summary.parent_run_id !== doc.meta.parent_run_id) problems.push("summary parent_run_id differs from meta.parent_run_id");
  if (parent && summary.parent_run_id !== parent.meta?.run_id) problems.push("summary parent_run_id differs from the supplied parent");
  const ids = new Set([...(doc.evidence ?? []), ...(parent?.evidence ?? [])].map((item) => item.id).filter(Boolean));
  function narrative(item, path) {
    if (!item || typeof item !== "object" || Array.isArray(item)) { problems.push(`${path} must contain FR/EN copy`); return; }
    for (const locale of ["fr", "en"]) {
      const copy = item[locale];
      if (typeof copy !== "string" || copy.trim().length < 12) problems.push(`${path}.${locale} must be meaningful`);
      else if (PLACEHOLDER.test(copy)) problems.push(`${path}.${locale} contains a placeholder or raw status code`);
    }
    if (!Array.isArray(item.evidence_refs) || item.evidence_refs.length === 0) problems.push(`${path}.evidence_refs must identify supporting evidence`);
    else for (const id of item.evidence_refs) if (!ids.has(id)) problems.push(`${path}: unknown evidence reference ${id}`);
  }
  for (const field of FIELDS) narrative(summary[field], `intermediate_summary.${field}`);
  if (summary.judgment_changes !== undefined && !Array.isArray(summary.judgment_changes)) problems.push("judgment_changes must be an array");
  const changes = Array.isArray(summary.judgment_changes) ? summary.judgment_changes : [];
  const seen = new Set();
  for (const [i, change] of changes.entries()) {
    const path = `intermediate_summary.judgment_changes[${i}]`;
    if (!JUDGMENTS.includes(change?.judgment)) problems.push(`${path}.judgment is unknown`);
    if (seen.has(change?.judgment)) problems.push(`${path}.judgment is duplicated`);
    seen.add(change?.judgment);
    for (const field of CHANGE_FIELDS) narrative(change?.[field], `${path}.${field}`);
  }
  if (required) {
    const macro = summary.macro_reading;
    if (!macro || typeof macro !== "object") problems.push("new intermediate requires macro_reading: observation, mechanism, forward conditions and invalidation");
    else for (const field of ["observed", "causal_assessment", "forward_conditions", "invalidation"]) {
      narrative(macro[field], `intermediate_summary.macro_reading.${field}`);
    }
    const gaps = summary.unknown_reasons;
    if (!Array.isArray(gaps)) problems.push("new intermediate requires unknown_reasons (empty only when no material unknown remains)");
    else {
      const topics = new Set();
      const known = ["COT_POST_FED", "OPEN_INTEREST_CURRENT", "REAL_YIELD_CURRENT", "OPTIONS_IV", "OPTIONS_SKEW", "DEALER_GAMMA", "OTHER"];
      const kinds = ["AWAITING_PUBLICATION", "SOURCE_NOT_RETRIEVED", "SOURCE_INACCESSIBLE", "COMPARABILITY_FAILED", "METHODOLOGY_NOT_VERIFIED", "STRUCTURALLY_UNOBSERVABLE", "CAUSE_UNDETERMINED"];
      for (const [i, gap] of gaps.entries()) {
        const path = `intermediate_summary.unknown_reasons[${i}]`;
        if (!known.includes(gap?.topic)) problems.push(`${path}.topic is unknown`);
        if (gap?.topic !== "OTHER" && topics.has(gap?.topic)) problems.push(`${path}.topic is duplicated`);
        topics.add(gap?.topic);
        if (!kinds.includes(gap?.reason_kind)) problems.push(`${path}.reason_kind is unknown`);
        for (const field of ["label", "explanation", "checked", "next_action"]) {
          for (const locale of ["fr", "en"]) {
            const copy = gap?.[field]?.[locale];
            if (typeof copy !== "string" || copy.trim().length < 12 || PLACEHOLDER.test(copy)) problems.push(`${path}.${field}.${locale} must give an actual explanation`);
          }
        }
        if (gap?.reason_kind === "AWAITING_PUBLICATION") {
          const when = Date.parse(gap.expected_at);
          if (!Number.isFinite(when)) problems.push(`${path}.expected_at is required for a scheduled publication`);
          else if (doc.meta.evidence_cutoff_end && when <= Date.parse(doc.meta.evidence_cutoff_end)) problems.push(`${path}.expected_at is not after the evidence cutoff`);
          if (!gap.evidence_refs?.length) problems.push(`${path}: scheduled publication requires evidence for its date`);
        } else if (gap?.expected_at) problems.push(`${path}: do not invent a publication time for this reason`);
        if (gap?.evidence_refs !== undefined && !Array.isArray(gap.evidence_refs)) problems.push(`${path}.evidence_refs must be an array`);
        else for (const id of gap?.evidence_refs ?? []) if (!ids.has(id)) problems.push(`${path}: unknown evidence reference ${id}`);
      }
      const positioning = doc.positioning_evidence;
      const expected = [];
      if (positioning?.price_open_interest?.oi_direction === "UNKNOWN") expected.push("OPEN_INTEREST_CURRENT");
      if (positioning?.options_iv?.iv_direction === "UNKNOWN") expected.push("OPTIONS_IV");
      if (positioning?.options_iv?.call_put_skew_direction === "UNKNOWN") expected.push("OPTIONS_SKEW");
      if (positioning?.gamma?.status === "UNKNOWN") expected.push("DEALER_GAMMA");
      const explicit = (doc.analysis_contract?.explicit_unknowns ?? []).join(" ");
      if (/post[- ]fed.{0,40}cot|cot.{0,40}post[- ]fed/i.test(explicit)) expected.push("COT_POST_FED");
      if (/real yield|taux r[eé]el/i.test(explicit)) expected.push("REAL_YIELD_CURRENT");
      for (const topic of expected) if (!topics.has(topic)) problems.push(`unexplained material unknown: ${topic}`);
    }
  }
  if (parent && required) for (const key of JUDGMENTS) {
    const before = rawJudgment(parent, key);
    const after = rawJudgment(doc, key);
    if (!before || !after || before === after) continue;
    if (!seen.has(key)) problems.push(`changed judgment ${key} has no explanation`);
    for (const locale of ["fr", "en"]) {
      const current = doc.presentation?.[locale]?.verdict_explanations?.[key];
      const previous = parent.presentation?.[locale]?.verdict_explanations?.[key];
      if (current?.mechanism && previous?.mechanism && current.mechanism.trim() === previous.mechanism.trim()) {
        problems.push(`changed judgment ${key} reused its parent's ${locale} mechanism`);
      }
      const state = key === "opportunity_quality" || key === "execution_readiness"
        ? doc.presentation?.[locale]?.[key] : doc.presentation?.[locale]?.direction_state?.[key];
      if (state?.value && state.value !== after) problems.push(`presentation.${locale}.${key} disagrees with current value`);
    }
  }
  return problems;
}
