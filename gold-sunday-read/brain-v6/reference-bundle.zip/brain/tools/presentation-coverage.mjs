// Semantic guard for new REAL V3 market-state publications.  Material means an
// analytical item deliberately placed in the scenario topology (or a required
// analytical section that contains content), never a count, word, or score.
const REQUIRED_LOCALE_BLOCKS = ["market_story", "horizons", "priced_in", "asymmetry", "direction_state", "scenario_tree_v3", "walkthrough"];
const REQUIRED_HORIZONS = ["tactical", "medium", "structural"];

function isNewProduction(doc) {
  return doc.meta?.data_mode === "REAL" && ["SUNDAY", "INTERMEDIATE"].includes(doc.meta?.run_type) && doc.presentation?.version === 4;
}

export const V4_VERDICTS = ["macro_direction", "directional_asymmetry", "positioning_asymmetry", "edge", "opportunity_quality", "execution_readiness"];
export const V4_VERDICT_FIELDS = ["verdict", "observations", "mechanism", "supporting_evidence", "contrary_evidence", "unknowns", "practical_meaning", "would_change", "insufficient_alone"];
export const V4_PRICED_IN_FIELDS = ["prior_expectation", "observed_outcome", "verified_reaction", "now_priced", "still_repriceable", "evidence_used", "unknowns_or_limits", "as_of"];
export const V4_CONDITIONAL_FIELDS = ["conditions", "transmission", "independent_confirmations", "positioning_confirmation", "expected_direction", "expected_directional_asymmetry", "expected_positioning_asymmetry", "expected_quality", "expected_readiness", "expected_edge", "invalidation_or_expiry", "unknowns"];
function v4Problems(doc, localeName, locale) {
  if (doc.presentation.version !== 4) return ["new REAL run must use presentation version 4"];
  const p = [];
  for (const field of ["chronology", "causal_assessment"]) if (!locale.market_story?.[field]) p.push(`${localeName}: market story lacks ${field}`);
  for (const horizon of REQUIRED_HORIZONS) for (const field of ["state", "drivers", "transmission", "supporting_evidence", "contradictions", "counter_scenario", "confirmation", "invalidation", "week_ahead_implication"]) if (!locale.horizons?.[horizon]?.[field]) p.push(`${localeName}: ${horizon} lacks ${field}`);
  for (const verdict of V4_VERDICTS) for (const field of V4_VERDICT_FIELDS) if (!locale.verdict_explanations?.[verdict]?.[field]) p.push(`${localeName}: verdict ${verdict} lacks ${field}`);
  const conditional = locale.conditional_verdicts;
  if (!Array.isArray(conditional) || conditional.length < 3) p.push(`${localeName}: requires bullish, bearish and no-edge conditional cases`);
  for (const item of conditional ?? []) for (const field of V4_CONDITIONAL_FIELDS) if (!item[field]) p.push(`${localeName}: conditional verdict lacks ${field}`);
  const conditionalEdges = new Set((conditional ?? []).map((item) => item.expected_edge));
  for (const edge of ["BULLISH", "BEARISH", "NO_EDGE"]) if (!conditionalEdges.has(edge)) p.push(`${localeName}: missing conditional ${edge} branch`);
  const pricedIn = locale.priced_in?.already_priced_analysis;
  if ((locale.priced_in?.already_priced?.length ?? 0) > 0 && !Array.isArray(pricedIn)) p.push(`${localeName}: priced-in items lack structured explanation`);
  if (Array.isArray(pricedIn) && pricedIn.length !== (locale.priced_in?.already_priced?.length ?? 0)) p.push(`${localeName}: priced-in analyses must align one-to-one by array order`);
  for (const item of pricedIn ?? []) for (const field of V4_PRICED_IN_FIELDS) if (item?.[field] === undefined || item?.[field] === null || item?.[field] === "") p.push(`${localeName}: priced-in item lacks ${field}`);
  return p;
}
function valueAtPath(root, path) {
  return path.split(".").reduce((value, part) => value !== null && value !== undefined ? value[part] : undefined, root);
}

function referencedGlossaryIds(value) {
  if (Array.isArray(value)) return value.flatMap(referencedGlossaryIds);
  if (!value || typeof value !== "object") return [];
  return Object.entries(value).flatMap(([key, child]) => key === "glossary_refs" && Array.isArray(child) ? child : referencedGlossaryIds(child));
}

function hasEnglishSentence(text) {
  // This intentionally looks for ordinary English sentence construction, not
  // legitimate shared market vocabulary (Gold, COT, ETF, open interest, skew,
  // gamma, edge, FOMC, DXY, Fed).
  return /\b(the|this|that|with|from|will|would|should|market|yields?|remains?|because|after|before|between)\b/i.test(text) && /\b(is|are|was|were|has|have|does|do|can|caught|between)\b/i.test(text);
}

export function presentationCoverageProblems(doc) {
  if (!isNewProduction(doc)) return [];
  const problems = [];
  const locales = doc.presentation;
  for (const localeName of ["fr", "en"]) {
    const locale = locales[localeName];
    for (const block of REQUIRED_LOCALE_BLOCKS) if (!locale?.[block]) problems.push(`${localeName}: missing material presentation block ${block}`);
    for (const horizon of REQUIRED_HORIZONS) if (!locale?.horizons?.[horizon]) problems.push(`${localeName}: missing material horizon ${horizon}`);
    for (const key of ["past_week", "current_setup", "week_ahead"]) if (!locale?.market_story?.[key]) problems.push(`${localeName}: missing market_story.${key}`);
    problems.push(...v4Problems(doc, localeName, locale));
    for (const annotation of locale?.annotations ?? []) {
      const target = valueAtPath(locale, annotation.path);
      if (annotation.locale !== localeName) problems.push(`${localeName}: annotation locale mismatch`);
      if (typeof annotation.id !== "string" || annotation.id.length === 0) problems.push(`${localeName}: annotation id is required`);
      if (typeof target !== "string") problems.push(`${localeName}: annotation path does not resolve to display text`);
      else {
        const count = target.split(annotation.anchor).length - 1;
        const occurrence = annotation.occurrence ?? 1;
        if (!Number.isInteger(occurrence) || occurrence < 1 || occurrence > count) problems.push(`${localeName}: annotation occurrence is invalid for its exact anchor`);
      }
      const glossary = (doc.glossary ?? []).find((entry) => entry.id === annotation.glossary_id);
      if (!glossary) problems.push(`${localeName}: annotation glossary entry does not exist`);
      else {
        const anchors = glossary[localeName]?.annotation_anchors ?? [glossary[localeName]?.term];
        if (!anchors.includes(annotation.anchor)) problems.push(`${localeName}: annotation anchor does not match its localized glossary entry`);
      }
    }
    const annotationIds = new Set((locale?.annotations ?? []).filter((a) => a.locale === localeName).map((a) => a.glossary_id));
    for (const glossaryId of new Set(referencedGlossaryIds(locale))) if (!annotationIds.has(glossaryId)) problems.push(`${localeName}: referenced glossary ${glossaryId} is never materialized by an annotation`);
  }
  const canonicalNodes = doc.scenario_tree?.nodes ?? [];
  const canonicalEdges = (doc.scenario_tree?.edges ?? []).filter((edge) => edge.id);
  for (const localeName of ["fr", "en"]) {
    const localized = locales[localeName]?.scenario_tree_v3;
    const nodeIds = new Set((localized?.nodes ?? []).map((node) => node.node_id));
    const edgeIds = new Set((localized?.edges ?? []).map((edge) => edge.edge_id));
    for (const node of canonicalNodes) if (!nodeIds.has(node.id)) problems.push(`${localeName}: material analytical node ${node.id} has no V3 presentation copy`);
    for (const edge of canonicalEdges) if (!edgeIds.has(edge.id)) problems.push(`${localeName}: material analytical relation ${edge.id} has no V3 presentation copy`);
    for (const edge of canonicalEdges) {
      const copy = (localized?.edges ?? []).find((item) => item.edge_id === edge.id);
      if (copy && (copy.from_node_id !== edge.from || copy.to_node_id !== edge.to)) problems.push(`${localeName}: localized relation ${edge.id} diverges from canonical tree`);
    }
    const explanations = (localized?.edges ?? []).map((edge) => edge.display_explanation?.trim()).filter(Boolean);
    if (explanations.length > 1 && new Set(explanations).size === 1) problems.push(`${localeName}: displayed relations reuse one generic causal explanation`);
  }
  for (const explanation of doc.scenario_explanations ?? []) {
    for (const nodeId of explanation.branch_node_ids ?? []) {
      for (const localeName of ["fr", "en"]) if (!(locales[localeName]?.scenario_tree_v3?.nodes ?? []).some((node) => node.node_id === nodeId)) problems.push(`${localeName}: material scenario ${explanation.id} loses branch node ${nodeId}`);
    }
  }
  for (const text of Object.values(locales.fr ?? {}).flatMap((value) => typeof value === "string" ? [value] : [])) if (hasEnglishSentence(text)) problems.push("fr: apparent English final-copy fallback");
  // Nested localized fields are final copy too.
  const walk = (value) => typeof value === "string" ? [value] : Array.isArray(value) ? value.flatMap(walk) : value && typeof value === "object" ? Object.values(value).flatMap(walk) : [];
  if (walk(locales.fr).some(hasEnglishSentence)) problems.push("fr: apparent English final-copy fallback");
  return [...new Set(problems)];
}
