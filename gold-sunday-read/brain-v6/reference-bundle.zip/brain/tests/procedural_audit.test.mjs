// Deterministic tests for the procedural audit (specs/legacy/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md).
//
// T01-T23 mirror the 23 mandatory cases of the phase-3 mission. Extra tests (X..)
// pin the boundaries of the contract. Every test starts from a valid fixture
// flipped to data_mode REAL (the mode that makes the audit mandatory) and applies
// one targeted mutation; none depends on volume, score or vote.
//
// Run: node tests/procedural_audit.test.mjs
import assert from "node:assert/strict";
import { readFileSync, writeFileSync, mkdtempSync, rmSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";
import { join } from "node:path";
import {
  proceduralAuditProblems, parentConsistencyProblems, completionRecordProblems, canonicalSha256, isFrontendEligibleMarketState,
  REQUIRED_QUESTIONS, PHASE_ORDER,
} from "../tools/procedural-audit.mjs";

const load = (name) => JSON.parse(readFileSync(new URL(`./fixtures/${name}`, import.meta.url), "utf8"));
const loadSchema = (name) => JSON.parse(readFileSync(new URL(`../schema/${name}`, import.meta.url), "utf8"));
const real = (doc) => { const copy = structuredClone(doc); copy.meta.data_mode = "REAL"; copy.time_scope = { reviewed_week_start: "2026-09-14", reviewed_week_end: "2026-09-18", report_week_start: "2026-09-21", report_week_end: "2026-09-25", information_cutoff: copy.meta.generated_at }; return copy; };
const sunday = () => real(load("FIXTURE_a_strong_bullish.json"));
const intermediate = () => real(load("FIXTURE_f_intermediate_transition.json"));
const parentOfIntermediate = () => load("FIXTURE_e_event_vol_premium.json");
const sunTrace = (doc, family, id) => doc.procedural_audit.collection[family].questions.find((q) => q.question_id === id);
const phase = (doc, id) => doc.procedural_audit.phases[id];

const passes = (doc) => assert.deepEqual(proceduralAuditProblems(doc), []);
const fails = (doc, text) => {
  const problems = proceduralAuditProblems(doc);
  assert.ok(problems.some((p) => p.includes(text)), `expected a problem containing "${text}", got ${JSON.stringify(problems)}`);
};
const sealRecord = (state, record = load("FIXTURE_a_run_completion_record.json")) => {
  const copy = structuredClone(record);
  copy.market_state.content_sha256 = canonicalSha256(state);
  copy.market_state.published_files.find((f) => f.role === "MARKET_STATE_JSON").content_sha256 = canonicalSha256(state);
  return copy;
};
const runValidator = (...docs) => {
  const dir = mkdtempSync(join(tmpdir(), "gold-procedural-"));
  try {
    const files = docs.map((doc, i) => { const file = join(dir, `doc-${i}.json`); writeFileSync(file, JSON.stringify(doc)); return file; });
    const result = spawnSync(process.execPath, ["tools/validate.mjs", ...files], { encoding: "utf8" });
    return { status: result.status, output: `${result.stdout}${result.stderr}` };
  } finally { rmSync(dir, { recursive: true, force: true }); }
};

const tests = [];
const test = (name, fn) => tests.push([name, fn]);

// --- T01-T05: collection, statuses, sources, recovery ------------------------

test("T01 complete Sunday with every phase traced passes", () => {
  passes(sunday());
  const state = sunday();
  const result = runValidator(state, sealRecord(state));
  assert.equal(result.status, 0, result.output);
});

test("T02 F3 absent without a status fails", () => {
  const doc = sunday();
  delete doc.procedural_audit.phases.F3;
  delete doc.procedural_audit.collection.F3;
  fails(doc, "F3 missing from procedural audit");
});

test("T03 F5 attempted but UNKNOWN, correctly documented, passes; without limitation it fails", () => {
  const doc = sunday();
  doc.procedural_audit.collection.F5.questions = REQUIRED_QUESTIONS.F5.map((question_id) => ({
    question_id, outcome: "UNKNOWN", as_of: null, measurement_window: null, evidence_refs: [], source_refs: [], source_categories: ["EXCHANGE_OR_CLEARING"],
    limitation: { reason: "SOURCE_NOT_FOUND", explanation: "FIXTURE: normal research did not establish this field." },
    source_recovery: { registry_consulted: true, attempts: [{ source: "FIXTURE: registry candidate", result: "UNAVAILABLE" }] },
  }));
  passes(doc);
  delete doc.procedural_audit.collection.F5.questions[0].limitation;
  fails(doc, "F5 marked COMPLETE without evidence or explicit limitation");
  const answered = sunday();
  sunTrace(answered, "F5", "F5.COT").evidence_refs = [];
  fails(answered, "F5 marked COMPLETE without evidence or explicit limitation");
});

test("T04 mandatory source recovery not attempted fails", () => {
  const doc = sunday();
  delete sunTrace(doc, "F3", "F3.GOLD_DXY_30D").source_recovery;
  fails(doc, "source recovery required but not recorded");
  const noRegistry = sunday();
  sunTrace(noRegistry, "F3", "F3.GOLD_DXY_30D").source_recovery = { registry_consulted: false, attempts: [] };
  fails(noRegistry, "source recovery required but not recorded");
});

test("T05 structurally non-observable data, correctly declared, passes", () => {
  const doc = sunday();
  doc.procedural_audit.collection.F5.questions.find((q) => q.question_id === "F5.Q2_FORCED_ACTOR").limitation.explanation = "FIXTURE: true dealer and forced-actor positions are not public.";
  passes(doc);
  const unexplained = sunday();
  sunTrace(unexplained, "F5", "F5.Q2_FORCED_ACTOR").limitation.explanation = "";
  fails(unexplained, "F5 marked COMPLETE without evidence or explicit limitation");
});

// --- T06-T10: phase order and dependencies ----------------------------------

test("T06 reasoning declared complete before the collection audit fails", () => {
  const doc = sunday();
  Object.assign(phase(doc, "reasoning"), { started_at: "2026-09-20T12:50:00Z", completed_at: "2026-09-20T13:00:00Z" });
  fails(doc, "reasoning completed before collection coverage audit");
  const notStarted = sunday();
  notStarted.procedural_audit.phases.collection_coverage_audit = { status: "NOT_STARTED" };
  fails(notStarted, "reasoning completed before collection coverage audit");
});

test("T07 asymmetry declared complete before reasoning fails", () => {
  const doc = sunday();
  Object.assign(phase(doc, "asymmetry_gate"), { started_at: "2026-09-20T13:50:00Z", completed_at: "2026-09-20T14:10:00Z" });
  fails(doc, "asymmetry gate completed before reasoning");
});

test("T08 presentation declared complete before the analysis fails", () => {
  const doc = sunday();
  Object.assign(phase(doc, "presentation"), { started_at: "2026-09-20T14:00:00Z", completed_at: "2026-09-20T14:30:00Z" });
  fails(doc, "presentation completed before reasoning");
  fails(doc, "presentation completed before scenario tree");
});

test("T09 handoff created before validation or readback fails", () => {
  const state = sunday();
  const noReadback = sealRecord(state);
  noReadback.phases.drive_readback = { status: "NOT_STARTED" };
  assert.ok(completionRecordProblems(noReadback, state).some((p) => p.includes("handoff completed before Drive readback")));
  const early = sealRecord(state);
  Object.assign(early.phases.handoff_generation, { started_at: "2026-09-20T18:01:00Z", completed_at: "2026-09-20T18:04:00Z" });
  assert.ok(completionRecordProblems(early, state).some((p) => p.includes("handoff completed before market-state validation")));
  const noValidation = sealRecord(state);
  noValidation.phases.market_state_validation = { status: "IN_PROGRESS" };
  assert.ok(completionRecordProblems(noValidation, state).some((p) => p.includes("handoff completed before market-state validation")));
});

test("T10 a dependent phase cannot be COMPLETE after a FAILED prerequisite", () => {
  const doc = sunday();
  doc.procedural_audit.phases.F4 = { status: "FAILED", started_at: "2026-09-20T12:10:00Z", completed_at: "2026-09-20T13:00:00Z", blocking_issue: "FIXTURE: provider outage" };
  fails(doc, "collection coverage audit completed while prerequisite F4 is FAILED");
  const state = sunday();
  const record = sealRecord(state);
  record.phases.market_state_validation = { status: "FAILED", started_at: "2026-09-20T18:00:00Z", completed_at: "2026-09-20T18:05:00Z", blocking_issue: "FIXTURE: schema failure" };
  assert.ok(completionRecordProblems(record, state).some((p) => p.includes("Drive readback completed while prerequisite market-state validation is FAILED")));
  // PARTIAL after a failed prerequisite is allowed only with a recorded limitation.
  const partial = sunday();
  partial.procedural_audit.phases.F4 = { status: "FAILED", started_at: "2026-09-20T12:10:00Z", completed_at: "2026-09-20T13:00:00Z", blocking_issue: "FIXTURE: provider outage" };
  Object.assign(phase(partial, "collection_coverage_audit"), { status: "PARTIAL" });
  fails(partial, "collection coverage audit is PARTIAL after failed F4 without a recorded limitation");
});

// --- T11-T14: lineage -------------------------------------------------------

test("T11 Sunday with a non-null parent_run_id fails", () => {
  const doc = load("FIXTURE_a_strong_bullish.json");
  doc.meta.parent_run_id = "some-earlier-run";
  const result = runValidator(doc);
  assert.notEqual(result.status, 0);
  assert.ok(result.output.includes("Sunday parent_run_id must be null"), result.output);
  const state = sunday();
  const record = sealRecord(state);
  record.parent_run_id = "some-earlier-run";
  assert.ok(completionRecordProblems(record, state).some((p) => p.includes("Sunday parent_run_id must be null")));
});

test("T12 Sunday with the wrong origin fails", () => {
  const doc = load("FIXTURE_a_strong_bullish.json");
  doc.meta.origin_sunday_run_id = "another-sunday-run";
  const result = runValidator(doc);
  assert.notEqual(result.status, 0);
  assert.ok(result.output.includes("Sunday origin_sunday_run_id must equal its own run_id"), result.output);
});

test("T13 intermediate with the right parent and origin passes", () => {
  passes(intermediate());
  assert.deepEqual(parentConsistencyProblems(intermediate(), parentOfIntermediate()), []);
});

test("T14 intermediate with the wrong parent fails", () => {
  const doc = intermediate();
  doc.meta.parent_run_id = "not-the-latest-validated-state";
  fails(doc, "is not the selected latest validated state");
  const wrongOrigin = intermediate();
  wrongOrigin.meta.origin_sunday_run_id = "r-2026-09-20-sunday";
  assert.ok(parentConsistencyProblems(wrongOrigin, parentOfIntermediate()).some((p) => p.includes("differs from parent origin")));
  const newer = intermediate();
  newer.procedural_audit.intermediate.intake.state_candidates.push({ run_id: "a-newer-state", run_type: "INTERMEDIATE", evidence_cutoff_end: "2026-09-21T10:00:00Z", validated: true });
  fails(newer, "a newer validated state a-newer-state exists than the selected parent");
});

// --- T15-T18: intermediate evidence window, F1-F6 audit, exogenous scan -----

test("T15 an intermediate using a pre-cutoff observation as new confirmation fails", () => {
  const doc = intermediate();
  doc.evidence.find((e) => e.id === "e1").as_of = "2026-09-19";
  fails(doc, "intermediate evidence predates parent cutoff without baseline label");
  const baselineOnly = intermediate();
  for (const role of baselineOnly.procedural_audit.intermediate.evidence_roles) if (["e1", "e2"].includes(role.evidence_ref)) Object.assign(role, { role: "BASELINE", baseline_label: "FIXTURE: earlier observation" });
  fails(baselineOnly, "rests only on baseline evidence");
  const oldSource = intermediate();
  oldSource.sources.find((s) => s.source_id === "s1").published_at = "2026-09-18";
  fails(oldSource, "intermediate evidence predates parent cutoff without baseline label");
});

test("T16 an old observation explicitly identified as a baseline passes", () => {
  const doc = intermediate();
  doc.evidence.find((e) => e.id === "e1").as_of = "2026-09-19";
  Object.assign(doc.procedural_audit.intermediate.evidence_roles.find((r) => r.evidence_ref === "e1"), { role: "BASELINE", baseline_label: "FIXTURE: previous Fed pricing used only as the comparison point" });
  passes(doc);
  const unlabeled = structuredClone(doc);
  delete unlabeled.procedural_audit.intermediate.evidence_roles.find((r) => r.evidence_ref === "e1").baseline_label;
  fails(unlabeled, "is a BASELINE without a baseline label");
});

test("T17 an intermediate without the F1-F6 audit fails", () => {
  const noFamilyAudit = intermediate();
  delete noFamilyAudit.family_audit;
  fails(noFamilyAudit, "F1 missing from family_audit");
  const missingPhase = intermediate();
  delete missingPhase.procedural_audit.phases.F3;
  fails(missingPhase, "F3 missing from procedural audit");
  const unchanged = intermediate();
  unchanged.family_audit.F6.checked_against_new_evidence = false;
  fails(unchanged, "family F6 is UNCHANGED without being checked against the new evidence window");
});

test("T18 an intermediate without the exogenous scan fails", () => {
  const doc = intermediate();
  delete doc.procedural_audit.intermediate.exogenous_scan;
  fails(doc, "intermediate exogenous-factor scan not recorded");
  const partialScan = intermediate();
  partialScan.procedural_audit.intermediate.exogenous_scan.categories.pop();
  fails(partialScan, "exogenous scan omits category REGULATORY_SANCTIONS_ACTION");
  const lateScan = intermediate();
  lateScan.procedural_audit.intermediate.exogenous_scan.completed_at = "2026-09-23T19:00:00Z";
  fails(lateScan, "exogenous scan completed after reasoning started");
});

// --- T19-T22: gaps, partial runs, length, honesty ---------------------------

const markF4Partial = (doc, { declareGaps = true, surface = true, status = "PARTIAL" } = {}) => {
  const audit = doc.procedural_audit;
  audit.phases.F4 = { status: "PARTIAL", started_at: "2026-09-20T12:10:00Z", completed_at: "2026-09-20T13:00:00Z", artifact: "collection/F4_macro_fiscal_credit.md", limitations: ["FIXTURE: the provider stopped answering before the oil and credit questions"] };
  audit.collection.F4.questions = audit.collection.F4.questions.filter((q) => !["F4.OIL", "F4.CREDIT_HY_IG"].includes(q.question_id));
  audit.collection_coverage_audit.unresolved_required_questions = [{ phase: "F4", question_id: "F4.OIL" }, { phase: "F4", question_id: "F4.CREDIT_HY_IG" }];
  audit.collection_coverage_audit.outcome = "GAPS_RECORDED";
  const texts = ["FIXTURE: F4 stopped early; oil is unresolved.", "FIXTURE: F4 stopped early; credit spreads are unresolved.", "FIXTURE: F4 was only partially collected."];
  if (declareGaps) {
    audit.procedural_gaps = [
      { gap_id: "G1", kind: "UNRESOLVED_REQUIRED_QUESTION", phase: "F4", question_id: "F4.OIL", description: "oil not collected", material: true, surface_text: texts[0] },
      { gap_id: "G2", kind: "UNRESOLVED_REQUIRED_QUESTION", phase: "F4", question_id: "F4.CREDIT_HY_IG", description: "credit not collected", material: true, surface_text: texts[1] },
      { gap_id: "G3", kind: "PHASE_PARTIAL", phase: "F4", description: "F4 partial", material: true, surface_text: texts[2] },
    ];
  }
  if (surface) doc.unknowns.push(...texts);
  doc.meta.status = status;
  return doc;
};

test("T19 a material procedural gap that is not declared or surfaced fails", () => {
  const undeclared = markF4Partial(sunday(), { declareGaps: false });
  fails(undeclared, "material procedural gap not declared");
  const unsurfaced = markF4Partial(sunday(), { surface: false });
  fails(unsurfaced, "material procedural gap not surfaced");
  const downgraded = markF4Partial(sunday());
  downgraded.procedural_audit.procedural_gaps[0].material = false;
  fails(downgraded, "is structural and must be material");
});

test("T20 a PARTIAL run with every limit explicit passes", () => {
  passes(markF4Partial(sunday()));
  fails(markF4Partial(sunday(), { status: "COMPLETE" }), "meta.status is COMPLETE but F4 is PARTIAL");
  const hiddenCoverage = markF4Partial(sunday());
  hiddenCoverage.procedural_audit.collection_coverage_audit = { families_reviewed: ["weekly_recap", "F1", "F2", "F3", "F4", "F5", "F6"], unresolved_required_questions: [], outcome: "ALL_REQUIRED_QUESTIONS_ADDRESSED" };
  fails(hiddenCoverage, "collection coverage audit omits unresolved required question");
});

test("T21 a long analysis that skips a mandatory phase fails", () => {
  const doc = sunday();
  for (let i = 0; i < 200; i += 1) {
    doc.evidence.push({ ...doc.evidence[0], id: `long-${i}` });
    doc.unknowns.push(`FIXTURE: extra observation ${i}`);
  }
  doc.competing_hypotheses.push(...Array.from({ length: 30 }, (_, i) => ({ id: `HX${i}`, thesis: "FIXTURE: extra thesis", evidence_for: [], evidence_against: [], status: "OPEN" })));
  passes(doc);
  delete doc.procedural_audit.phases.scenario_tree;
  fails(doc, "scenario_tree missing from procedural audit");
  const skippedAudit = sunday();
  delete skippedAudit.procedural_audit.phases.collection_coverage_audit;
  fails(skippedAudit, "collection_coverage_audit missing from procedural audit");
});

test("T22 a short, honest and procedurally complete analysis passes", () => {
  const doc = sunday();
  doc.evidence = [doc.evidence[0]];
  doc.sources = [doc.sources[0]];
  const audit = doc.procedural_audit;
  for (const trace of Object.values(audit.collection)) {
    for (const q of trace.questions) {
      if (q.evidence_refs.length) q.evidence_refs = ["e1"];
      q.source_refs = q.source_refs.length ? ["s1"] : [];
      if (q.outcome === "ANSWERED" && !q.source_refs.length) q.source_refs = ["s1"];
    }
  }
  for (const key of ["competing_hypotheses", "dominant_driver", "transmission_chains", "cross_asset_reality_test"]) delete doc[key];
  audit.reasoning_components = audit.reasoning_components.map((c) => (["COMPETING_HYPOTHESES", "DOMINANT_DRIVER", "TRANSMISSION_CHAINS", "CROSS_ASSET_REALITY_TEST"].includes(c.component)
    ? { component: c.component, disposition: "EXPLICIT_UNKNOWN", reason: "FIXTURE: no defensible dominant story emerged from the single established observation." }
    : c));
  passes(doc);
});

test("T23 a historical document without procedural_audit stays compatible", () => {
  const historical = JSON.parse(readFileSync(new URL("../schema/minimal_v2_example.json", import.meta.url), "utf8"));
  assert.equal(historical.meta.data_mode, "REAL");
  assert.deepEqual(proceduralAuditProblems(historical), []);
  const result = spawnSync(process.execPath, ["tools/validate.mjs", "schema/minimal_v2_example.json"], { encoding: "utf8" });
  assert.equal(result.status, 0, result.stdout);
  const fixtureWithoutAudit = load("FIXTURE_sunday_v3_state.json");
  assert.deepEqual(proceduralAuditProblems(fixtureWithoutAudit), []);
});

// --- Extra boundaries of the contract ---------------------------------------

test("X01 a new REAL run without procedural_audit is refused; a FIXTURE run may opt out", () => {
  const doc = sunday();
  delete doc.procedural_audit;
  fails(doc, "procedural_audit missing");
  const schemaResult = runValidator(doc, sealRecord(sunday()));
  assert.notEqual(schemaResult.status, 0);
  const fixture = load("FIXTURE_a_strong_bullish.json");
  delete fixture.procedural_audit;
  assert.deepEqual(proceduralAuditProblems(fixture), []);
});

test("X02 the Sunday cutoff and completed week are verified", () => {
  const sundayNight = sunday();
  sundayNight.meta.evidence_cutoff_end = "2026-09-20T23:30:00Z";
  sundayNight.procedural_audit.sunday.cutoff.evidence_cutoff_end = "2026-09-20T23:30:00Z";
  passes(sundayNight);
  const notExcluded = sunday();
  notExcluded.procedural_audit.sunday.cutoff.sunday_night_trading_excluded = false;
  fails(notExcluded, "Sunday-night trading must be explicitly excluded");
  const duringWeek = sunday();
  duringWeek.meta.evidence_cutoff_end = "2026-09-17T18:00:00Z";
  duringWeek.procedural_audit.sunday.cutoff.evidence_cutoff_end = "2026-09-17T18:00:00Z";
  fails(duringWeek, "is not after the completed week end");
  const badWeek = sunday();
  badWeek.procedural_audit.sunday.completed_week.reviewed_week_end = "2026-09-19";
  fails(badWeek, "is not a Friday date");
  const rollHidden = sunday();
  rollHidden.procedural_audit.sunday.benchmark.roll_in_window = true;
  fails(rollHidden, "contract roll inside the window is not disclosed");
  const weeklyNotApplicable = sunday();
  weeklyNotApplicable.procedural_audit.phases.weekly_recap = { status: "NOT_APPLICABLE", not_applicable_reason: "FIXTURE: skipped" };
  fails(weeklyNotApplicable, "Weekly Recap cannot be NOT_APPLICABLE");
});

test("X03 an intermediate never reruns the Weekly Recap and must be idempotent", () => {
  const rerun = intermediate();
  rerun.procedural_audit.phases.weekly_recap = { status: "COMPLETE", started_at: "2026-09-23T14:15:00Z", completed_at: "2026-09-23T14:30:00Z", artifact: "collection/weekly_recap.md" };
  fails(rerun, "must not rerun the Weekly Recap");
  const replay = intermediate();
  replay.procedural_audit.intermediate.intake.idempotence.prior_consumers = ["another-run"];
  fails(replay, "idempotence violated");
  const wrongHandoff = intermediate();
  wrongHandoff.procedural_audit.intermediate.intake.consumed_handoff.handoff_version = 9;
  fails(wrongHandoff, "does not match handoff_version");
  const lateRead = intermediate();
  lateRead.procedural_audit.intermediate.intake.consumed_handoff.validated_at = "2026-09-23T14:20:00Z";
  fails(lateRead, "handoff was read and validated after collection began");
});

test("X04 the prior-week history is preserved or corrected with evidence", () => {
  const altered = intermediate();
  altered.weekly_timeline = [];
  fails(altered, "prior-week history was altered without a recorded correction");
  const corrected = intermediate();
  corrected.weekly_timeline = [{ ...corrected.weekly_timeline[0], price_fact: "FIXTURE: corrected price fact." }];
  Object.assign(corrected.procedural_audit.intermediate.weekly_history, { treatment: "INHERITED_WITH_VERIFIED_CORRECTION", corrections: [{ reason: "FIXTURE: verified restatement", evidence_refs: ["e1"] }] });
  passes(corrected);
  assert.deepEqual(parentConsistencyProblems(corrected, parentOfIntermediate()), []);
  const hashMismatch = intermediate();
  hashMismatch.procedural_audit.intermediate.weekly_history.inherited_weekly_timeline_sha256 = "0".repeat(64);
  assert.ok(parentConsistencyProblems(hashMismatch, parentOfIntermediate()).some((p) => p.includes("does not match the parent's weekly_timeline")));
});

test("X05 inherited scenarios are tested or explicitly deferred, and transitions recorded", () => {
  const untested = intermediate();
  untested.procedural_audit.intermediate.inherited_scenarios = [];
  fails(untested, "inherited scenario S1 was not tested or explicitly deferred");
  const noTransition = intermediate();
  noTransition.scenario_transitions = [];
  fails(noTransition, "inherited scenario S1 has no recorded scenario transition");
  const deferred = intermediate();
  deferred.scenario_transitions[0].transition_state = "NOT_TESTED";
  fails(deferred, "scenario S1 is NOT_TESTED without a recorded reason");
  Object.assign(deferred.procedural_audit.intermediate.inherited_scenarios[0], { tested: false, not_tested_reason: "FIXTURE: the scenario condition is not yet due" });
  passes(deferred);
});

test("X06 reasoning components and stage artifacts must exist", () => {
  const missing = sunday();
  missing.procedural_audit.reasoning_components.pop();
  fails(missing, "reasoning component UNKNOWNS missing from procedural audit");
  const empty = sunday();
  delete empty.competing_hypotheses;
  fails(empty, "reasoning component COMPETING_HYPOTHESES is PRODUCED but competing_hypotheses is empty or absent");
  const noReason = sunday();
  Object.assign(noReason.procedural_audit.reasoning_components.find((c) => c.component === "ANOMALIES"), { disposition: "NONE_FOUND", output_path: undefined });
  fails(noReason, "reasoning component ANOMALIES is NONE_FOUND without a reason");
  const noGate = sunday();
  delete noGate.direction_state;
  fails(noGate, "asymmetry gate marked COMPLETE but direction_state or asymmetry is absent");
});

test("X07 an unfinished or artifact-less phase cannot be published", () => {
  const unfinished = sunday();
  unfinished.procedural_audit.phases.presentation = { status: "IN_PROGRESS" };
  fails(unfinished, "a published run cannot leave a phase unfinished");
  const noArtifact = sunday();
  delete phase(noArtifact, "F2").artifact;
  fails(noArtifact, "F2 is COMPLETE without a recorded artifact");
  const badTimes = sunday();
  phase(badTimes, "F1").completed_at = "2026-09-20T11:00:00Z";
  fails(badTimes, "F1 started_at is later than completed_at");
  const kindMismatch = sunday();
  kindMismatch.procedural_audit.run_kind = "INTERMEDIATE";
  fails(kindMismatch, "contradicts meta.run_type");
});

test("X08 question outcomes stay coherent with their limitation", () => {
  const lag = sunday();
  delete sunTrace(lag, "F4", "F4.TREASURY_AUCTIONS").publication_limit;
  fails(lag, "publication lag is recorded without a publication_limit");
  const unattempted = sunday();
  Object.assign(sunTrace(unattempted, "F4", "F4.TREASURY_AUCTIONS"), { source_categories: [], source_refs: [] });
  fails(unattempted, "records no source or source category consulted");
  const brokenRef = sunday();
  sunTrace(brokenRef, "F1", "F1.US2Y").evidence_refs = ["nope"];
  fails(brokenRef, "evidence_ref nope does not resolve");
  const naWrongReason = sunday();
  sunTrace(naWrongReason, "F2", "F2.MOVE").limitation.reason = "SOURCE_NOT_FOUND";
  fails(naWrongReason, "NOT_APPLICABLE requires a not-applicable or structural limitation reason");
  const undated = sunday();
  Object.assign(sunTrace(undated, "F1", "F1.US2Y"), { as_of: null, measurement_window: null });
  fails(undated, "is ANSWERED without as_of or measurement_window");
});

test("X09 the completion record seals the exact state, files and handoff", () => {
  const state = sunday();
  assert.deepEqual(completionRecordProblems(sealRecord(state), state), []);
  const stale = load("FIXTURE_a_run_completion_record.json");
  assert.ok(completionRecordProblems(stale, state).some((p) => p.includes("does not match the market-state JSON it seals")));
  const missingFile = sealRecord(state);
  missingFile.market_state.published_files.pop();
  assert.ok(completionRecordProblems(missingFile, state).some((p) => p.includes("RUN_REPORT must be recorded exactly once")));
  const unverified = sealRecord(state);
  unverified.market_state.published_files[1].readback_verified = false;
  assert.ok(completionRecordProblems(unverified, state).some((p) => p.includes("was not verified")));
  const duplicateActive = sealRecord(state);
  duplicateActive.handoff.active_handoff_count_after = 2;
  assert.ok(completionRecordProblems(duplicateActive, state).some((p) => p.includes("exactly one active handoff")));
  const noPreRead = sealRecord(state);
  noPreRead.handoff.pre_write_readback_at = "2026-09-20T18:00:00Z";
  assert.ok(completionRecordProblems(noPreRead, state).some((p) => p.includes("not read back before it was replaced")));
  const foreignHandoff = sealRecord(state);
  foreignHandoff.handoff.created_by_run_id = "another-run";
  assert.ok(completionRecordProblems(foreignHandoff, state).some((p) => p.includes("must be created by the Sunday run itself")));
  const overclaim = sealRecord(state);
  overclaim.phases.handoff_validation = { status: "IN_PROGRESS" };
  assert.ok(completionRecordProblems(overclaim, state).some((p) => p.includes("run_state is COMPLETE but handoff validation is IN_PROGRESS")));
});

test("X10 an intermediate handoff replaces the active file in place, after success, with its own lineage", () => {
  const state = intermediate();
  const record = sealRecord(state, load("FIXTURE_f_run_completion_record.json"));
  assert.deepEqual(completionRecordProblems(record, state), []);
  const created = structuredClone(record);
  created.handoff.write_mode = "CREATED_FIRST_ACTIVE_FILE";
  assert.ok(completionRecordProblems(created, state).some((p) => p.includes("replace the active handoff in place")));
  const wrongOrigin = structuredClone(record);
  wrongOrigin.handoff.origin_sunday_run_id = "another-origin";
  assert.ok(completionRecordProblems(wrongOrigin, state).some((p) => p.includes("keep the origin Sunday run")));
  const mismatched = structuredClone(record);
  mismatched.parent_run_id = "another-parent";
  assert.ok(completionRecordProblems(mismatched, state).some((p) => p.includes("differs from the market state")));
});

test("X11 a REAL run cannot be treated as complete without its completion record", () => {
  const state = sunday();
  const alone = runValidator(state);
  assert.notEqual(alone.status, 0);
  assert.ok(alone.output.includes("run completion record missing"), alone.output);
  const sealed = runValidator(state, sealRecord(state));
  assert.equal(sealed.status, 0, sealed.output);
  const failedSeal = runValidator(state, (() => { const r = sealRecord(state); r.phases.drive_readback = { status: "NOT_STARTED" }; return r; })());
  assert.notEqual(failedSeal.status, 0);
  assert.ok(failedSeal.output.includes("handoff completed before Drive readback"), failedSeal.output);
});

test("X12 the trace is closed: no free-form reasoning field can be recorded", () => {
  const schema = loadSchema("sunday_read.schema.json");
  for (const name of ["proceduralAudit", "procPhase", "procQuestion", "procGap", "procSundayProof", "procIntermediateProof"]) {
    assert.equal(schema.$defs[name].additionalProperties, false, `${name} must reject unknown (free-form) fields`);
  }
  assert.equal(loadSchema("run_completion_record.schema.json").additionalProperties, false);
  const doc = sunday();
  doc.procedural_audit.chain_of_thought = "FIXTURE: private reasoning";
  const result = runValidator(doc, sealRecord(doc));
  assert.notEqual(result.status, 0);
});

test("X13 no volume threshold: one source, one fact and a short tree are enough", () => {
  const doc = sunday();
  doc.evidence = [doc.evidence[0]];
  doc.sources = [doc.sources[0]];
  for (const trace of Object.values(doc.procedural_audit.collection)) {
    for (const q of trace.questions) { q.evidence_refs = q.evidence_refs.length ? ["e1"] : []; q.source_refs = ["s1"]; }
  }
  doc.scenario_tree.nodes = doc.scenario_tree.nodes.slice(0, 1);
  doc.weekly_timeline = [];
  doc.competing_hypotheses = [doc.competing_hypotheses[0]];
  passes(doc);
});

test("X14 the mandatory-question table in the spec matches the validator", () => {
  const spec = readFileSync(new URL("../specs/legacy/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md", import.meta.url), "utf8");
  const documented = [...spec.matchAll(/^\|\s*`?((?:WR|F[1-6])\.[A-Z0-9_]+)`?\s*\|/gm)].map((m) => m[1]).sort();
  const enforced = Object.values(REQUIRED_QUESTIONS).flat().sort();
  assert.deepEqual(documented, enforced);
  for (const id of PHASE_ORDER) assert.ok(spec.includes(id), `spec must name phase ${id}`);
});

// --- Upload authorization and control-plane isolation of the completion record ---

test("X15 nothing is uploaded to the Output folder before the local validation passed", () => {
  const state = sunday();
  assert.deepEqual(completionRecordProblems(sealRecord(state), state), []);
  const early = sealRecord(state);
  early.market_state.published_files[0].uploaded_at = "2026-09-20T18:03:00Z"; // validation runs 18:00-18:05
  assert.ok(completionRecordProblems(early, state).some((p) => p.includes("MARKET_STATE_JSON was uploaded before the local market-state validation passed")));
  const beforeAnything = sealRecord(state);
  beforeAnything.market_state.published_files[0].uploaded_at = "2026-09-20T17:00:00Z";
  assert.ok(completionRecordProblems(beforeAnything, state).some((p) => p.includes("uploaded before the local market-state validation passed")));
  const failedValidation = sealRecord(state);
  failedValidation.phases.market_state_validation = { status: "FAILED", started_at: "2026-09-20T18:00:00Z", completed_at: "2026-09-20T18:05:00Z", blocking_issue: "FIXTURE: schema failure" };
  assert.ok(completionRecordProblems(failedValidation, state).some((p) => p.includes("uploaded before the local market-state validation passed")));
  const late = sealRecord(state);
  late.market_state.published_files[1].uploaded_at = "2026-09-20T18:20:00Z";
  assert.ok(completionRecordProblems(late, state).some((p) => p.includes("outside the Drive readback phase")));
  const backwards = sealRecord(state);
  backwards.market_state.published_files[2].uploaded_at = "2026-09-20T18:14:00Z"; // readback is at 18:11
  assert.ok(completionRecordProblems(backwards, state).some((p) => p.includes("readback of VALIDATION_REPORT precedes its upload")));
  const noUpload = sealRecord(state);
  delete noUpload.market_state.published_files[0].uploaded_at;
  assert.ok(completionRecordProblems(noUpload, state).some((p) => p.includes("has no valid uploaded_at")));
  // The frozen state is fixed before validation starts: validation cannot begin before the JSON exists.
  const unfrozen = sealRecord(state);
  unfrozen.phases.market_state_validation.started_at = "2026-09-20T17:00:00Z";
  assert.ok(completionRecordProblems(unfrozen, state).some((p) => p.includes("validation started before the JSON and reports were produced")));
});

test("X16 the completion record is a control-plane file that can never become the current state", () => {
  const ajv = new Ajv2020({ allErrors: true, strict: true, allowUnionTypes: true }); addFormats(ajv);
  const validateRecord = ajv.compile(loadSchema("run_completion_record.schema.json"));
  const validateState = ajv.compile(loadSchema("sunday_read.schema.json"));
  const record = load("FIXTURE_a_run_completion_record.json");
  assert.equal(record.frontend_eligible, false);
  assert.equal(record.storage_plane, "CONTROL");
  assert.ok(validateRecord(record), JSON.stringify(validateRecord.errors));
  // It is never an eligible market state, and it is not a valid market state document.
  assert.equal(isFrontendEligibleMarketState(record), false);
  assert.equal(isFrontendEligibleMarketState(load("FIXTURE_g_handoff_asymmetry_checkpoints.json")), false);
  assert.equal(isFrontendEligibleMarketState(load("FIXTURE_a_strong_bullish.json").meta), true);
  assert.equal(validateState(record), false);
  // Forging it into an eligible state fails on every axis.
  for (const forged of [{ frontend_eligible: true }, { storage_plane: "OUTPUT" }, { document_type: "GOLD_MARKET_STATE" }]) {
    assert.equal(validateRecord({ ...record, ...forged }), false, JSON.stringify(forged));
  }
  const disguised = { ...structuredClone(record), document_type: "GOLD_MARKET_STATE", frontend_eligible: true };
  assert.equal(validateState(disguised), false);
  const result = runValidator(disguised);
  assert.notEqual(result.status, 0, "a disguised completion record must be rejected as a market state");
  // It is not one of the four immutable Output files, and control files cannot be listed among them.
  assert.deepEqual(record.market_state.published_files.map((f) => f.role).sort(), ["HUMAN_REPORT", "MARKET_STATE_JSON", "RUN_REPORT", "VALIDATION_REPORT"]);
  assert.equal(validateRecord({ ...record, market_state: { ...record.market_state, published_files: [...record.market_state.published_files, { ...record.market_state.published_files[0], role: "RUN_COMPLETION_RECORD" }] } }), false);
  const state = sunday();
  for (const name of ["RUN_COMPLETION_RECORD_x.json", "NEXT_GOLD_RECAP.json"]) {
    const listed = sealRecord(state);
    listed.market_state.published_files[1].name = name;
    assert.ok(completionRecordProblems(listed, state).some((p) => p.includes("control-plane files, never one of the four immutable Output files")), name);
  }
});

test("X17 the documentation fixes the storage location, upload timing and ingestion filter", () => {
  const spec = readFileSync(new URL("../specs/legacy/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md", import.meta.url), "utf8");
  const continuous = readFileSync(new URL("../specs/legacy/GOLD_CONTINUOUS_RECAP_PROTOCOL.md", import.meta.url), "utf8");
  const schemaText = readFileSync(new URL("../schema/run_completion_record.schema.json", import.meta.url), "utf8");
  assert.ok(spec.includes("Gold Sunday Read Control") && spec.includes("run_records/RUN_COMPLETION_RECORD_"), "spec must name the control-plane location");
  assert.ok(spec.includes("Nothing is uploaded to the Output folder before"), "spec must state the upload rule");
  assert.ok(continuous.includes("GOLD_RUN_COMPLETION_RECORD") && /explicitly ignore/i.test(continuous), "the ingestion ignore list must name the completion record");
  for (const text of [spec, schemaText, readFileSync(new URL("../specs/GOLD_V3_INTEGRATION_CHANGELOG.md", import.meta.url), "utf8")]) {
    assert.ok(!/is immutable and published before|market-state JSON is published before|published before validation/i.test(text), "no document may say the state is published before validation");
  }
});

// --- Corrective Monday Sunday rebuild --------------------------------------

test("X18 Monday execution remains a Sunday market-plan run", () => {
  const doc = sunday();
  doc.meta.evidence_cutoff_end = "2026-09-21T15:00:00Z";
  doc.procedural_audit.sunday.cutoff.evidence_cutoff_end = doc.meta.evidence_cutoff_end;
  passes(doc);
});

test("X19 corrective Monday Sunday separates Friday benchmark and Monday facts", () => {
  const doc = sunday();
  doc.meta.generated_at = "2026-09-21T15:10:00Z";
  doc.meta.evidence_cutoff_end = "2026-09-21T15:00:00Z";
  doc.procedural_audit.sunday.cutoff.evidence_cutoff_end = doc.meta.evidence_cutoff_end;
  doc.evidence[0].as_of = "2026-09-21T14:00:00Z";
  passes(doc);
  const schema = loadSchema("sunday_read.schema.json");
  const ajv = new Ajv2020({ strict: false, allErrors: true });
  addFormats(ajv);
  const validate = ajv.compile(schema);
  assert.equal(validate(doc), true, JSON.stringify(validate.errors));
});

test("X20 a Monday plan does not carry corrective-replacement metadata", () => {
  const doc = sunday();
  doc.meta.generated_at = "2026-09-21T15:10:00Z";
  doc.meta.evidence_cutoff_end = "2026-09-21T15:00:00Z";
  doc.procedural_audit.sunday.cutoff.evidence_cutoff_end = doc.meta.evidence_cutoff_end;
  passes(doc);
});

test("X21 a complete REAL V4 presentation passes the procedural audit and validator", () => {
  const doc = sunday();
  doc.presentation.version = 4;
  const removeGlossaryRefs = (value) => {
    if (Array.isArray(value)) value.forEach(removeGlossaryRefs);
    else if (value && typeof value === "object") for (const key of Object.keys(value)) key === "glossary_refs" ? delete value[key] : removeGlossaryRefs(value[key]);
  };
  for (const localeName of ["fr", "en"]) {
    const locale = doc.presentation[localeName];
    locale.market_story.chronology = [{
      date: "2026-09-18",
      observed: localeName === "fr" ? "Mouvement observé" : "Observed move",
      reported_attribution: localeName === "fr" ? "Attribution rapportée" : "Reported attribution",
      status: "OBSERVED",
    }];
    locale.market_story.causal_assessment = {
      observed: localeName === "fr" ? "Observation" : "Observed",
      reported: localeName === "fr" ? "Attribution" : "Reported",
      alternatives: [localeName === "fr" ? "Alternative" : "Alternative"],
      conclusion_limit: localeName === "fr" ? "Inconnu" : "Unknown",
    };
    for (const horizon of ["tactical", "medium", "structural"]) {
      Object.assign(locale.horizons[horizon], {
        state: "State", drivers: ["Driver"], transmission: "Transmission",
        supporting_evidence: ["Evidence"], contradictions: ["Contradiction"],
        counter_scenario: "Counter", confirmation: "Confirm", invalidation: "Invalidate",
        week_ahead_implication: "Implication",
      });
    }
    locale.verdict_explanations = Object.fromEntries([
      "macro_direction", "directional_asymmetry", "positioning_asymmetry", "edge", "opportunity_quality", "execution_readiness",
    ].map((key) => [key, Object.fromEntries([
      "verdict", "observations", "mechanism", "supporting_evidence", "contrary_evidence", "unknowns", "practical_meaning", "would_change", "insufficient_alone",
    ].map((field) => [field, field]))]));
    locale.conditional_verdicts = ["BULLISH", "BEARISH", "NO_EDGE"].map((expected_edge) => ({ conditions: "Condition", transmission: "Transmission", independent_confirmations: ["Confirmation"], positioning_confirmation: "Positioning", expected_direction: expected_edge, expected_directional_asymmetry: expected_edge, expected_positioning_asymmetry: "BALANCED", expected_quality: "MEDIUM", expected_readiness: "NOT_READY", expected_edge, invalidation_or_expiry: "Expiry", unknowns: ["Unknown"] }));
    locale.annotations = [];
    locale.priced_in.already_priced = [];
    locale.priced_in.already_priced_analysis = [];
    removeGlossaryRefs(locale);
  }
  assert.deepEqual(proceduralAuditProblems(doc), []);
  const result = runValidator(doc, sealRecord(doc));
  assert.equal(result.status, 0, result.output);
});

test("one-time 25 September partial Sunday is explicit and honest", () => {
  const doc = sunday();
  doc.meta.generated_at = "2026-09-25T06:12:00Z";
  doc.meta.evidence_cutoff_start = "2026-09-21T04:00:00Z";
  doc.meta.evidence_cutoff_end = "2026-09-25T06:10:00Z";
  doc.meta.week_of = "2026-09-21";
  doc.time_scope = { reviewed_week_start: "2026-09-21", reviewed_week_end: "2026-09-24", report_week_start: "2026-09-21", report_week_end: "2026-09-25", information_cutoff: doc.meta.evidence_cutoff_end };
  const proof = doc.procedural_audit.sunday;
  proof.completed_week = { reviewed_week_start: "2026-09-21", reviewed_week_end: "2026-09-24", analysis_of_completed_week_finished: false };
  proof.cutoff.evidence_cutoff_end = doc.meta.evidence_cutoff_end;
  proof.partial_week_exception = { reviewed_through: "2026-09-24", friday_date: "2026-09-25", friday_observation_cutoff: doc.meta.evidence_cutoff_end, reason: "User requested an initial read before Friday close", previous_validated_run_id: "gold-intermediate-2026-09-24-01" };
  doc.presentation.scope.reviewed_week_start = "2026-09-21";
  doc.presentation.scope.reviewed_week_end = "2026-09-24";
  doc.presentation.scope.upcoming_week_start = "2026-09-21";
  doc.presentation.scope.upcoming_week_end = "2026-09-25";
  assert.deepEqual(proceduralAuditProblems(doc), []);
  const schema = loadSchema("sunday_read.schema.json");
  const ajv = new Ajv2020({ strict: false, allErrors: true }); addFormats(ajv);
  const validates = ajv.compile(schema);
  assert.ok(validates(doc), JSON.stringify(validates.errors));
  const invalid = structuredClone(doc);
  invalid.procedural_audit.sunday.partial_week_exception.friday_observation_cutoff = "2026-09-26T00:01:00Z";
  assert.ok(proceduralAuditProblems(invalid).some((x) => x.includes("partial Friday cutoff")));
  const otherDay = structuredClone(doc);
  otherDay.procedural_audit.sunday.partial_week_exception.friday_date = "2026-10-02";
  assert.ok(proceduralAuditProblems(otherDay).some((x) => x.includes("authorized only")));
});

// --- Runner -----------------------------------------------------------------

let failed = 0;
for (const [name, fn] of tests) {
  try { fn(); console.log(`PASS  ${name}`); } catch (error) { failed += 1; console.log(`FAIL  ${name}\n      ${String(error.message).split("\n").join("\n      ")}`); }
}
console.log(`\nprocedural audit tests: ${tests.length - failed} passed, ${failed} failed.`);
process.exit(failed ? 1 : 0);
