import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";

const ajv = new Ajv2020({ allErrors: true }); addFormats(ajv);
const request = ajv.compile(JSON.parse(readFileSync(new URL("../schema/gold_edge_check_request.schema.json", import.meta.url))));
const result = ajv.compile(JSON.parse(readFileSync(new URL("../schema/gold_edge_check_result.schema.json", import.meta.url))));
const hash = "a".repeat(64);
assert.ok(request({ document_type: "GOLD_EDGE_CHECK_REQUEST", request_id: "r", requested_at: "2026-09-20T00:00:00Z", requested_by: "holder", base_run_id: "run", base_content_hash: hash, base_information_cutoff: "2026-09-19T00:00:00Z", inherited_direction: "BULLISH", inherited_directional_asymmetry: "BULLISH", inherited_positioning_asymmetry: "BALANCED", inherited_edge: "BULLISH", status: "QUEUED", idempotency_key: "a".repeat(16), frontend_eligible: false }), JSON.stringify(request.errors));
assert.ok(!request({ document_type: "GOLD_EDGE_CHECK_REQUEST", frontend_eligible: true }), "request must not be frontend eligible");
const unchanged = { document_type: "GOLD_EDGE_CHECK_RESULT", frontend_eligible: true, check_id: "c", request_id: "r", base_run_id: "run", base_content_hash: hash, checked_at: "2026-09-20T00:01:00Z", source_window_start: "2026-09-19T00:00:00Z", source_window_end: "2026-09-20T00:00:00Z", inherited_edge: "BULLISH", verdict: "NO_GAME_CHANGER", game_changer: null, core_premise_affected: null, causal_transmission: null, verified_sources: [], ordinary_market_context: "Ordinary market moves observed, without a verified fundamental break.", full_intermediate_recap_required: false, operational_decision: "EDGE_REMAINS_VALID", expires_when_base_state_changes: true };
assert.ok(result(unchanged), JSON.stringify(result.errors));
assert.ok(!result({ ...unchanged, verdict: "GAME_CHANGER_DETECTED", game_changer: null, full_intermediate_recap_required: true, operational_decision: "EDGE_SUSPENDED_PENDING_FULL_REVIEW" }), "game changer needs four-part materiality evidence");
console.log("edge-check schemas: PASS");
