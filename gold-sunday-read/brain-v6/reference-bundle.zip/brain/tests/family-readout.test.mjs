import assert from "node:assert/strict";
import test from "node:test";
import { FAMILY_QUESTIONS, familyReadoutProblems, continuityCheckpointProblems } from "../tools/family-readout.mjs";

const loc = (text = "Evidence is documented for this reading.") => ({ fr: text, en: text });
const story = (refs = ["E-1"]) => ({ ...loc(), evidence_refs: refs });
const actual = () => ({
  question: loc("Qu'attend le marché de la Fed cette semaine ?"),
  answer: loc("Les attentes sont publiées avec une date précise."),
  status: "ANSWERED", as_of: "2026-09-27", evidence_refs: ["E-1"],
});
const gap = (reason = "SOURCE_NOT_RETRIEVED") => ({
  question: loc("La série comparable est-elle publiée à cette date ?"),
  answer: loc("La valeur comparable n'a pas pu être établie."),
  status: "UNKNOWN", as_of: null, evidence_refs: [],
  unknown_reason: {
    reason_kind: reason, explanation: loc("La mesure comparable est introuvable après vérification."),
    checked: loc("Le site du producteur a été consulté à cette date."),
    next_action: loc("Rechercher la nouvelle publication auprès de ce producteur."),
  },
});
function sunday() {
  const family_readouts = Object.entries(FAMILY_QUESTIONS).map(([family_id, ids]) => ({
    family_id, title: loc("Analyse de cette famille de facteurs."),
    questions: ids.map(question_id => ({ question_id, ...actual() })),
    family_reasoning: Object.fromEntries(["established", "mechanism", "counterevidence", "limits", "forward_test"].map(k => [k, story()])),
  }));
  const fields = ["causal_chain", "alternatives", "contradictions", "priced_in", "forward_conditions", "invalidation", "unknowns", "edge_reasoning"];
  return {
    meta: { run_id: "sunday-next", run_type: "SUNDAY", data_mode: "REAL", generated_at: "2026-09-25T14:00:00Z" },
    evidence: [{ id: "E-1", as_of: "2026-09-27" }],
    family_readouts,
    global_synthesis: Object.fromEntries(fields.map(k => [k, story()])),
    weekly_bridge: {
      prior_run_id: "last-intermediate",
      comparison_limit: story([]), differences: story(),
      surviving_conclusions: story(), resolved_expectations: story(),
      failed_expectations: story([]),
    },
  };
}
test("new Sunday requires every collection question, explanation and reference", () => {
  const state = sunday();
  assert.deepEqual(familyReadoutProblems(state), []);
  state.family_readouts[0].questions.pop();
  assert.match(familyReadoutProblems(state).join(" "), /missing question F1_NEXT_FOMC/);
  state.family_readouts[0].questions.push({ question_id: "F1_NEXT_FOMC", ...actual(), evidence_refs: ["missing"] });
  assert.match(familyReadoutProblems(state).join(" "), /unresolved evidence missing/);
});
test("missing data must say what was checked and why; history stays valid", () => {
  const state = sunday();
  state.family_readouts[1].questions[0] = { question_id: "F2_REAL_10Y", ...gap() };
  assert.deepEqual(familyReadoutProblems(state), []);
  delete state.family_readouts[1].questions[0].unknown_reason.checked;
  assert.match(familyReadoutProblems(state).join(" "), /unknown_reason.checked.fr/);
  assert.deepEqual(familyReadoutProblems({ meta: { run_type: "SUNDAY", data_mode: "REAL", generated_at: "2026-09-24T15:00:00Z" } }), []);
});
test("intermediate must narrate the change from immediate parent", () => {
  const previous = sunday();
  const state = {
    meta: { run_id: "intermediate-two", run_type: "INTERMEDIATE", parent_run_id: "intermediate-one", data_mode: "REAL", generated_at: "2026-09-25T16:00:00Z" },
    evidence: [{ id: "E-1" }],
    evolution_review: {
      parent_run_id: "intermediate-one", thesis_status: "WEAKENED",
      ...Object.fromEntries(["narrative", "still_true", "new_observations", "strengthened", "weakened", "invalidated", "exogenous_factors", "unresolved", "next_checks"].map(k => [k, story()])),
    },
  };
  assert.deepEqual(familyReadoutProblems(state), []);
  state.evolution_review.parent_run_id = previous.meta.run_id;
  assert.match(familyReadoutProblems(state).join(" "), /must equal meta.parent_run_id/);
});
test("next handoff carries matching source, cutoff and six current verdicts", () => {
  const state = {
    direction_state: { macro_direction: "MIXED", directional_asymmetry: "BALANCED", positioning_asymmetry: "UNKNOWN", edge: "NO_EDGE" },
    opportunity_quality: { value: "WEAK" }, execution_readiness: { value: "WAITING_FOR_CATALYST" },
  };
  const handoff = {
    handoff_version: 7, created_by_run_id: "intermediate-two", parent_state_run_id: "intermediate-two",
    prior_cutoff: { as_of: "2026-09-28T16:00:00Z" },
    continuity_checkpoint: {
      source_run_id: "intermediate-two", evidence_cutoff_end: "2026-09-28T16:00:00Z",
      summary: "The current state is mixed and requires another check.",
      durable_foundations: [], live_questions: [], branch_checks: [],
      six_verdicts: { ...state.direction_state, opportunity_quality: "WEAK", execution_readiness: "WAITING_FOR_CATALYST" },
    },
  };
  assert.deepEqual(continuityCheckpointProblems(handoff, state), []);
  handoff.continuity_checkpoint.six_verdicts.edge = "BULLISH";
  assert.match(continuityCheckpointProblems(handoff, state).join(" "), /differs from produced market state/);
  assert.deepEqual(continuityCheckpointProblems({ handoff_version: 6 }), []);
  assert.match(continuityCheckpointProblems({ handoff_version: 6, created_at: "2026-09-27T14:00:00Z" }).join(" "), /increment handoff_version/);
});
