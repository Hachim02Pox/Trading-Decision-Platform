#!/usr/bin/env node
// Deterministic negative tests for the positioning-asymmetry contract.
//
// Each case starts from a *valid* contract-compliant document, applies one
// targeted mutation that produces a prohibited state, and asserts that
// `tools/validate.mjs` rejects it. This is a negative test matrix: a case the
// validator accepts is a failure of the validator, not of the fixture.
//
// Run: node tests/negative_validator_smoke.mjs
import { readFileSync, writeFileSync, unlinkSync, readdirSync } from "node:fs";
import { spawnSync } from "node:child_process";

// Valid bases: a Sunday contract document, an intermediate transition document
// and a handoff document. Each negative case mutates exactly one of them.
const BASES = {
  strong: JSON.parse(readFileSync("tests/fixtures/FIXTURE_a_strong_bullish.json", "utf8")),
  intermediate: JSON.parse(readFileSync("tests/fixtures/FIXTURE_f_intermediate_transition.json", "utf8")),
  unknown: JSON.parse(readFileSync("tests/fixtures/FIXTURE_d_options_gamma_unknown.json", "utf8")),
  handoff: JSON.parse(readFileSync("tests/fixtures/FIXTURE_g_handoff_asymmetry_checkpoints.json", "utf8")),
};

const clone = (value) => JSON.parse(JSON.stringify(value));
const pe = (doc) => doc.positioning_evidence;

// A previously interrupted negative run can leave transient JSONs behind.
// The validator scans all fixture JSONs, so remove only this runner's own
// generated inputs before checking the controls.
for (const file of readdirSync("tests/fixtures")) {
  if (/^\.(?:negative|control)-.*\.json$/.test(file)) unlinkSync(`tests/fixtures/${file}`);
}

// --- Negative matrix -------------------------------------------------------
// Each entry: [name, base, mutate]
const CASES = [
  ["missing-required-positioning-object", "strong", (doc) => {
    delete doc.positioning_evidence;
  }],

  // 1. STRONG without positioning evidence
  ["strong-without-positioning-evidence", "strong", (doc) => {
    pe(doc).cot.epistemic_status = "UNKNOWN";
    pe(doc).cot.percentiles = {
      gross_longs: { value: null, status: "UNKNOWN", evidence_refs: ["e1"] },
      gross_shorts: { value: null, status: "UNKNOWN", evidence_refs: ["e1"] },
      net_position: { value: null, status: "UNKNOWN", evidence_refs: ["e1"] },
    };
    pe(doc).etf_flows.observations = [{ value: null, status: "UNKNOWN", evidence_refs: ["e2"] }];
    pe(doc).etf_flows.price_confirmation = "UNKNOWN";
    pe(doc).price_open_interest.causal_status = "UNKNOWN";
    delete pe(doc).options_iv.gvz;
    delete pe(doc).options_iv.skew_change;
    delete pe(doc).options_iv.options_volume_oi;
  }],

  // 2. STRONG without catalyst/activation mechanism
  ["strong-without-catalyst-or-activation", "strong", (doc) => {
    doc.dated_catalyst_assessment.status = "ABSENT";
    doc.dated_catalyst_assessment.event_name = null;
    doc.dated_catalyst_assessment.activation_reason = "";
  }],

  // 3. STRONG without identified invalidation/fuse
  ["strong-without-invalidation-fuse", "strong", (doc) => {
    doc.invalidation_fuse.status = "NONE";
    doc.invalidation_fuse.bounds_thesis = false;
  }],

  // 4. TRAP without crowding/lateness/extreme evidence
  ["trap-without-crowding-or-extreme-evidence", "strong", (doc) => {
    doc.opportunity_quality = { ...doc.opportunity_quality, value: "TRAP", display_fr: "Qualité d'opportunité piège", display_en: "Opportunity quality trap" };
    doc.presentation.fr.opportunity_quality.display = "Qualité d'opportunité piège";
    doc.presentation.en.opportunity_quality.display = "Opportunity quality trap";
    doc.direction_state.positioning_asymmetry = "BULLISH";
    doc.presentation.fr.direction_state.positioning_asymmetry.value = "BULLISH";
    doc.presentation.en.direction_state.positioning_asymmetry.value = "BULLISH";
    pe(doc).cot.epistemic_status = "UNCALCULATED";
    pe(doc).cot.percentiles = {
      gross_longs: { value: 50, status: "CALCULATED", evidence_refs: ["e1"] },
      gross_shorts: { value: 50, status: "CALCULATED", evidence_refs: ["e1"] },
      net_position: { value: 50, status: "CALCULATED", evidence_refs: ["e1"] },
    };
    doc.late = { status: "BALANCED", reason: "FIXTURE: neither crowded nor late." };
  }],

  // 5. READY_IF_TRIGGERED without catalyst/activation mechanism
  ["ready-if-triggered-without-activation", "strong", (doc) => {
    doc.dated_catalyst_assessment.status = "ABSENT";
    doc.dated_catalyst_assessment.event_name = null;
    doc.dated_catalyst_assessment.activation_reason = "";
    doc.execution_readiness = { ...doc.execution_readiness, value: "READY_IF_TRIGGERED", display_fr: "Prête si déclenchée", display_en: "Ready if triggered" };
    doc.presentation.fr.execution_readiness.display = "Prête si déclenchée";
    doc.presentation.en.execution_readiness.display = "Ready if triggered";
  }],

  // 6. material scheduled catalyst without timezone
  ["catalyst-without-timezone", "strong", (doc) => {
    doc.dated_catalyst_assessment.timezone = null;
  }],

  // 7. expired catalyst still classified as WAITING_FOR_CATALYST
  ["expired-catalyst-still-waiting", "intermediate", (doc) => {
    doc.dated_catalyst_assessment.expiry_status = "EXPIRED";
    doc.dated_catalyst_assessment.scheduled_at = "2026-09-15T12:30:00Z";
    doc.execution_readiness.value = "WAITING_FOR_CATALYST";
    doc.execution_readiness.display_fr = "En attente du catalyseur";
    doc.execution_readiness.display_en = "Waiting for catalyst";
    doc.presentation.fr.execution_readiness.display = "En attente du catalyseur";
    doc.presentation.en.execution_readiness.display = "Waiting for catalyst";
  }],

  // 8. FOMO_CONFIRMED from price up + IV up alone
  ["fomo-confirmed-from-price-and-iv-only", "strong", (doc) => {
    pe(doc).options_iv.call_put_skew_direction = "FLAT";
    delete pe(doc).options_iv.options_volume_oi;
  }],

  // 9. FOMO_CONFIRMED without event-risk check
  ["fomo-confirmed-without-event-check", "strong", (doc) => {
    pe(doc).options_iv.event_risk_check = "INCONCLUSIVE";
  }],

  // 10. observed dealer-gamma claim without evidence
  ["observed-gamma-without-evidence", "strong", (doc) => {
    pe(doc).gamma.status = "OBSERVED";
    pe(doc).gamma.dealer_sign_claim = "SUPPORTED";
    pe(doc).gamma.evidence_refs = [];
  }],

  // 11. MODEL_ESTIMATED gamma without model method
  ["model-estimated-gamma-without-method", "strong", (doc) => {
    pe(doc).gamma.status = "MODEL_ESTIMATED";
    pe(doc).gamma.dealer_sign_claim = "SUPPORTED";
    pe(doc).gamma.model_method = null;
  }],

  // 12. large strike OI treated as proof of dealer sign
  ["strike-oi-as-dealer-sign-proof", "strong", (doc) => {
    pe(doc).gamma.status = "MODEL_ESTIMATED";
    pe(doc).gamma.dealer_sign_claim = "SUPPORTED";
    pe(doc).gamma.model_method = "";
  }],

  // 13. confirmed SGE divergence without comparable methodology/windows
  ["sge-divergence-without-comparability", "strong", (doc) => {
    pe(doc).physical_sge.divergence = "CONFIRMED";
    pe(doc).physical_sge.status = "OBSERVED";
    pe(doc).physical_sge.comparability.timestamp_alignment = "unknown";
    pe(doc).physical_sge.comparability.methodology = "unknown";
  }],

  // 14. COT percentile without population, metric, lookback or report date
  ["cot-percentile-without-provenance", "strong", (doc) => {
    pe(doc).cot.participant_population = "";
    pe(doc).cot.report_date = "";
    pe(doc).cot.lookback_weeks = null;
  }],

  // 15. broken positioning evidence refs
  ["broken-positioning-evidence-refs", "strong", (doc) => {
    pe(doc).cot.percentiles.gross_longs.evidence_refs = ["e-does-not-exist"];
  }],

  // 16. analytical/presentation opportunity-quality mismatch
  ["opportunity-quality-analytical-presentation-mismatch", "strong", (doc) => {
    doc.presentation.fr.opportunity_quality.display = "Qualité d'opportunité inconnue";
    doc.presentation.en.opportunity_quality.display = "Opportunity quality unknown";
  }],

  // 17. analytical/presentation execution-readiness mismatch
  ["execution-readiness-analytical-presentation-mismatch", "strong", (doc) => {
    doc.presentation.fr.execution_readiness.display = "Exécution non prête";
    doc.presentation.en.execution_readiness.display = "Execution not ready";
  }],

  // 18. FR/EN mismatch
  ["fr-en-mismatch", "strong", (doc) => {
    doc.presentation.en.opportunity_quality.display = "Opportunity quality trap";
  }],

  // 19. UNKNOWN silently interpreted as neutral. The `unknown` base genuinely
  // has no observable positioning (COT inside its publication lag, gamma and
  // skew UNKNOWN), so declaring it BALANCED converts ignorance into neutrality.
  ["unknown-positioning-relabeled-as-balanced", "unknown", (doc) => {
    doc.direction_state.positioning_asymmetry = "BALANCED";
    doc.presentation.fr.direction_state.positioning_asymmetry.value = "BALANCED";
    doc.presentation.en.direction_state.positioning_asymmetry.value = "BALANCED";
  }],

  // Guard: no silent fallback to the old V3 contract.
  ["analysis-contract-removed-silently", "strong", (doc) => {
    delete doc.analysis_contract;
    delete doc.positioning_evidence;
    delete doc.dated_catalyst_assessment;
    delete doc.invalidation_fuse;
    delete doc.opportunity_quality;
    delete doc.execution_readiness;
  }],

  // Contract identity must be exact.
  ["wrong-analysis-contract-name", "strong", (doc) => {
    doc.analysis_contract.name = "LEGACY_V3";
  }],

  ["scoring-enabled-in-contract", "strong", (doc) => {
    doc.analysis_contract.no_scoring = false;
  }],

  // Handoff must carry next-run asymmetry checkpoints.
  ["handoff-without-asymmetry-checkpoints", "handoff", (doc) => {
    delete doc.asymmetry_checkpoints;
  }],

  // Procedural audit (specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md). The bases carry a
  // full audit; each mutation skips or falsifies exactly one mandatory step. The
  // exhaustive procedural matrix lives in tests/procedural_audit.test.mjs.
  ["procedural-f3-missing-from-audit", "strong", (doc) => {
    delete doc.procedural_audit.phases.F3;
    delete doc.procedural_audit.collection.F3;
  }],
  ["procedural-source-recovery-not-recorded", "strong", (doc) => {
    delete doc.procedural_audit.collection.F3.questions.find((q) => q.question_id === "F3.GOLD_DXY_30D").source_recovery;
  }],
  ["procedural-reasoning-before-collection-audit", "strong", (doc) => {
    Object.assign(doc.procedural_audit.phases.reasoning, { started_at: "2026-09-20T12:50:00Z", completed_at: "2026-09-20T13:00:00Z" });
  }],
  ["procedural-dependent-complete-after-failed-prerequisite", "strong", (doc) => {
    doc.procedural_audit.phases.F4 = { status: "FAILED", started_at: "2026-09-20T12:10:00Z", completed_at: "2026-09-20T13:00:00Z", blocking_issue: "FIXTURE: provider outage" };
  }],
  ["procedural-partial-phase-without-declared-gap", "strong", (doc) => {
    doc.procedural_audit.phases.F4 = { ...doc.procedural_audit.phases.F4, status: "PARTIAL", limitations: ["FIXTURE: stopped early"] };
    doc.meta.status = "PARTIAL";
  }],
  ["procedural-sunday-with-parent", "strong", (doc) => {
    doc.meta.parent_run_id = "an-earlier-run";
  }],
  ["procedural-sunday-wrong-origin", "strong", (doc) => {
    doc.meta.origin_sunday_run_id = "another-sunday-run";
  }],
  ["procedural-intermediate-without-exogenous-scan", "intermediate", (doc) => {
    delete doc.procedural_audit.intermediate.exogenous_scan;
  }],
  ["procedural-intermediate-without-family-audit", "intermediate", (doc) => {
    delete doc.family_audit;
  }],
  ["procedural-intermediate-precutoff-observation-as-new", "intermediate", (doc) => {
    doc.evidence.find((e) => e.id === "e1").as_of = "2026-09-19";
  }],
  ["procedural-intermediate-wrong-parent", "intermediate", (doc) => {
    doc.meta.parent_run_id = "not-the-latest-validated-state";
  }],
];

// --- Runner ----------------------------------------------------------------

let failures = 0;
let passed = 0;

for (const [name, baseName, mutate] of CASES) {
  const path = `tests/fixtures/.negative-${name}.json`;
  const document = clone(BASES[baseName]);
  mutate(document);
  writeFileSync(path, JSON.stringify(document));
  const result = spawnSync(process.execPath, ["tools/validate.mjs", path], { encoding: "utf8" });
  unlinkSync(path);
  if (result.status === 0) {
    failures += 1;
    console.log(`FAIL  ${name}: validator unexpectedly accepted the prohibited state`);
  } else {
    passed += 1;
    console.log(`PASS  ${name}: validator rejected prohibited state`);
  }
}

// Control: the untouched bases must remain valid, otherwise the negative matrix
// would be meaningless (everything could "fail" for the wrong reason).
for (const file of readdirSync("tests/fixtures")) {
  if (/^\.(?:negative|control)-.*\.json$/.test(file)) unlinkSync(`tests/fixtures/${file}`);
}
for (const [baseName, doc] of Object.entries(BASES)) {
  const path = `tests/fixtures/.control-${baseName}.json`;
  writeFileSync(path, JSON.stringify(doc));
  const result = spawnSync(process.execPath, ["tools/validate.mjs", path], { encoding: "utf8" });
  unlinkSync(path);
  if (result.status !== 0) {
    failures += 1;
    console.log(`FAIL  control:${baseName}: the unmutated base is not valid`);
  } else {
    passed += 1;
    console.log(`PASS  control:${baseName}: unmutated base is valid`);
  }
}

console.log(`\n${passed} negative-matrix checks passed, ${failures} failed.`);
process.exit(failures > 0 ? 1 : 0);
