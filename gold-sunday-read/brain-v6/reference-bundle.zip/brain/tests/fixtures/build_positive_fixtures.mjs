#!/usr/bin/env node
// Deterministic generator for the positive positioning-asymmetry fixtures (A-G).
//
// The fixtures are derived from the two hand-built canonical fixtures so that
// they inherit a schema-valid skeleton (meta, contexts, priced_in, scenario
// tree, evidence, sources, glossary, V3 presentation) and then apply only the
// contract-specific deltas each scenario is meant to exercise.
//
// Every fixture is FIXTURE-only: meta.data_mode is FIXTURE and every prose
// value is prefixed "FIXTURE:". No real market data is encoded here.
//
// Run: node tests/fixtures/build_positive_fixtures.mjs

import { readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { canonicalSha256, COLLECTION_PHASES, EXOGENOUS_CATEGORIES, REASONING_COMPONENTS, REQUIRED_QUESTIONS } from "../../tools/procedural-audit.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const readFixture = (name) => JSON.parse(readFileSync(join(HERE, name), "utf8"));
const writeFixture = (name, doc) => writeFileSync(join(HERE, name), `${JSON.stringify(doc, null, 2)}\n`);

// ---------------------------------------------------------------------------
// Shared contract scaffolding
// ---------------------------------------------------------------------------

// A SUNDAY run is its own origin. Fixtures that reuse the Sunday skeleton and
// rename `run_id` must keep `origin_sunday_run_id` aligned with it.
function renameSundayRun(doc, runId) {
  doc.meta.run_id = runId;
  doc.meta.origin_sunday_run_id = runId;
}

function contract(explicitUnknowns) {
  return {
    version: 1,
    name: "POSITIONING_ASYMMETRY_EXECUTION_READINESS",
    no_scoring: true,
    explicit_unknowns: explicitUnknowns,
  };
}

// A COT block that is genuinely OBSERVED and evidenced — used by the strong and
// trap scenarios where positioning is the whole point.
function observedCot(evidenceRef) {
  const pct = (value) => ({ value, status: "CALCULATED", evidence_refs: [evidenceRef] });
  const level = (value) => ({ value, status: "OBSERVED", evidence_refs: [evidenceRef] });
  return {
    report_identity: "FIXTURE CFTC Gold Futures — Commitments of Traders",
    participant_population: "Managed Money",
    metric_identity: "MULTIPLE",
    gross_longs: level(268000),
    gross_shorts: level(41000),
    net_position: level(227000),
    changes: {
      gross_longs: level(12000),
      gross_shorts: level(-6000),
      net_position: level(18000),
    },
    report_date: "2026-09-15",
    publication_date: "2026-09-18",
    publication_lag: "Tuesday observation published Friday",
    lookback_weeks: 156,
    percentiles: {
      gross_longs: pct(93),
      gross_shorts: pct(12),
      net_position: pct(91),
    },
    epistemic_status: "CALCULATED",
    classification_rule: "Upper >=85; lower <=30; metric and population must be named",
    interpretation: "FIXTURE: Managed Money net length sits in the upper decile of its 156-week distribution.",
  };
}

// A COT block whose observation is structurally delayed (the publication lag
// case). Positioning is therefore explicitly unknown, never neutral.
function laggedCot(evidenceRef) {
  const delayed = () => ({ value: null, status: "PUBLICATION_LAG", evidence_refs: [evidenceRef] });
  return {
    report_identity: "FIXTURE CFTC Gold Futures — Commitments of Traders",
    participant_population: "Managed Money",
    metric_identity: "MULTIPLE",
    gross_longs: delayed(),
    gross_shorts: delayed(),
    net_position: delayed(),
    changes: { gross_longs: delayed(), gross_shorts: delayed(), net_position: delayed() },
    report_date: "2026-09-22",
    publication_date: "2026-09-25",
    publication_lag: "Tuesday observation published Friday",
    lookback_weeks: 156,
    percentiles: {
      gross_longs: { value: null, status: "UNKNOWN", evidence_refs: [evidenceRef] },
      gross_shorts: { value: null, status: "UNKNOWN", evidence_refs: [evidenceRef] },
      net_position: { value: null, status: "UNKNOWN", evidence_refs: [evidenceRef] },
    },
    epistemic_status: "UNKNOWN",
    classification_rule: "Upper >=85; lower <=30; metric and population must be named",
    interpretation: "FIXTURE: the observation is inside its publication lag and cannot be classified yet.",
  };
}

function unknownGamma(evidenceRef) {
  return { status: "UNKNOWN", dealer_sign_claim: "NONE", evidence_refs: [evidenceRef] };
}

function unknownSge(evidenceRef, direction) {
  return {
    international_price_direction: direction,
    sge_premium_discount: { value: null, status: "UNKNOWN", evidence_refs: [evidenceRef] },
    divergence: "UNKNOWN",
    comparability: {
      timestamp_alignment: "unknown",
      usd_cny: "unknown",
      benchmark: "unknown",
      frictions: "unknown",
      persistence: "unknown",
      methodology: "unknown",
    },
    status: "UNKNOWN",
    evidence_refs: [evidenceRef],
  };
}

function emptyEtf(evidenceRef) {
  return {
    observations: [{ value: null, status: "PUBLICATION_LAG", evidence_refs: [evidenceRef] }],
    price_confirmation: "UNKNOWN",
    persistence: "UNKNOWN",
    window_overlap: "UNKNOWN",
    evidence_refs: [evidenceRef],
  };
}

function noFomoOptions(evidenceRef, direction) {
  return {
    price_direction: direction,
    iv_direction: "UNKNOWN",
    observation_window: "FIXTURE: same weekly window as the price observation",
    event_risk_check: "UNKNOWN",
    call_put_skew_direction: "UNKNOWN",
    fomo_state: "UNKNOWN",
    interpretation: "FIXTURE: no FOMO conclusion is drawn without IV, skew and event-premium evidence.",
    evidence_refs: [evidenceRef],
  };
}

function unknownFuse(evidenceRef) {
  return {
    observable_condition: "FIXTURE: no reliably observable fuse has been identified for this configuration",
    currently_measurable: false,
    bounds_thesis: false,
    horizon: "FIXTURE: weekly",
    status: "UNKNOWN",
    evidence_refs: [evidenceRef],
  };
}

function identifiedFuse(evidenceRef, condition) {
  return {
    observable_condition: condition,
    currently_measurable: true,
    bounds_thesis: true,
    horizon: "FIXTURE: one week",
    status: "IDENTIFIED",
    evidence_refs: [evidenceRef],
  };
}

// The nested `funding_forced_flow_fuse.fuse` block uses its own sub-shape
// (`condition` / `measurable`), distinct from the top-level `invalidation_fuse`.
function fundingFuse(condition, { measurable, status }) {
  return { condition, measurable, bounds_thesis: measurable, horizon: "FIXTURE: one week", status };
}

function unknownFunding(evidenceRef, fuse) {
  return {
    funding: { value: null, status: "UNKNOWN", evidence_refs: [evidenceRef] },
    forced_actor: { value: null, status: "UNKNOWN", evidence_refs: [evidenceRef] },
    fuse,
    evidence_refs: [evidenceRef],
  };
}

function noCatalyst(evidenceRef) {
  return {
    status: "ABSENT",
    event_name: null,
    scheduled_at: null,
    timezone: null,
    expected_baseline: null,
    surprise_condition: null,
    first_transmission_channel: null,
    affected_scenarios: [],
    activation_reason: "",
    expiry_status: "NOT_SCHEDULED",
    evidence_refs: [evidenceRef],
  };
}

function presentCatalyst(evidenceRef, { name, when, tz, expiry, activation }) {
  return {
    status: "PRESENT",
    event_name: name,
    scheduled_at: when,
    timezone: tz,
    expected_baseline: `FIXTURE: consensus baseline for ${name}`,
    surprise_condition: `FIXTURE: the deviation that would reprice gold around ${name}`,
    first_transmission_channel: "FIXTURE: 2Y real yield and the dollar",
    affected_scenarios: ["S1"],
    activation_reason: activation,
    expiry_status: expiry,
    evidence_refs: [evidenceRef],
  };
}

function quality(value, rationale, refs) {
  const fr = {
    STRONG: "Qualité d'opportunité forte",
    MEDIUM: "Qualité d'opportunité moyenne",
    WEAK: "Qualité d'opportunité faible",
    TRAP: "Qualité d'opportunité piège",
    UNKNOWN: "Qualité d'opportunité inconnue",
  }[value];
  const en = {
    STRONG: "Opportunity quality strong",
    MEDIUM: "Opportunity quality medium",
    WEAK: "Opportunity quality weak",
    TRAP: "Opportunity quality trap",
    UNKNOWN: "Opportunity quality unknown",
  }[value];
  return { value, display_fr: fr, display_en: en, rationale, evidence_refs: refs };
}

function readiness(value, rationale, refs) {
  const fr = {
    READY_IF_TRIGGERED: "Prête si déclenchée",
    WAITING_FOR_CATALYST: "En attente du catalyseur",
    CATALYST_PRESENT_BUT_UNCONFIRMED: "Catalyseur présent mais non confirmé",
    NOT_READY: "Exécution non prête",
    UNKNOWN: "Préparation inconnue",
  }[value];
  const en = {
    READY_IF_TRIGGERED: "Ready if triggered",
    WAITING_FOR_CATALYST: "Waiting for catalyst",
    CATALYST_PRESENT_BUT_UNCONFIRMED: "Catalyst present but unconfirmed",
    NOT_READY: "Execution not ready",
    UNKNOWN: "Readiness unknown",
  }[value];
  return { value, display_fr: fr, display_en: en, rationale, evidence_refs: refs };
}

// Keep the localized presentation copy in lockstep with the analytical values.
function syncPresentation(doc, qualityDoc, readinessDoc, localizedCopy) {
  for (const localeName of ["fr", "en"]) {
    const locale = doc.presentation[localeName];
    locale.opportunity_quality = {
      display: qualityDoc[`display_${localeName}`],
      explanation: localizedCopy[localeName].quality,
    };
    locale.execution_readiness = {
      display: readinessDoc[`display_${localeName}`],
      explanation: localizedCopy[localeName].readiness,
    };
  }
}

function setDirectionState(doc, state, copy) {
  doc.direction_state = {
    macro_direction: state.macro_direction,
    directional_asymmetry: state.directional_asymmetry,
    positioning_asymmetry: state.positioning_asymmetry,
    edge: state.edge,
  };
  for (const localeName of ["fr", "en"]) {
    const locale = doc.presentation[localeName];
    locale.direction_state = {
      macro_direction: { value: state.macro_direction, display: copy[localeName].macro_direction, explanation: copy[localeName].macro_direction_explanation },
      directional_asymmetry: { value: state.directional_asymmetry, display: copy[localeName].directional_asymmetry, explanation: copy[localeName].directional_asymmetry_explanation },
      positioning_asymmetry: { value: state.positioning_asymmetry, display: copy[localeName].positioning_asymmetry, explanation: copy[localeName].positioning_asymmetry_explanation },
      edge: { value: state.edge, display: copy[localeName].edge, explanation: copy[localeName].edge_explanation },
    };
  }
  doc.asymmetry = { ...doc.asymmetry, edge: state.edge };
}

// ---------------------------------------------------------------------------
// Fixture A — strong bullish opportunity
// ---------------------------------------------------------------------------

function fixtureStrongBullish() {
  const doc = readFixture("FIXTURE_sunday_v3_state.json");
  renameSundayRun(doc, "fixture-a-strong-bullish");
  doc.meta.data_mode = "FIXTURE";
  doc.meta.status = "COMPLETE";
  doc.meta.generated_at = "2026-09-20T18:00:00Z";
  doc.meta.evidence_cutoff_start = "2026-09-14T00:00:00Z";
  doc.meta.evidence_cutoff_end = "2026-09-20T18:00:00Z";
  doc.analysis_contract = contract(["FIXTURE: no comparable SGE window", "FIXTURE: dealer gamma sign not observable"]);

  doc.positioning_evidence = {
    cot: observedCot("e1"),
    price_open_interest: {
      price_direction: "UP",
      oi_direction: "UP",
      measurement_window: "FIXTURE: same weekly window as the price observation",
      diagnostic: "FIXTURE: rising price with rising open interest is consistent with new participation rather than closure.",
      causal_status: "CONSISTENT_WITH",
      evidence_refs: ["e1"],
    },
    etf_flows: {
      observations: [
        { value: "+18t", status: "OBSERVED", evidence_refs: ["e2"], measurement_window: "FIXTURE: 5-day window" },
      ],
      price_confirmation: "CONFIRMS",
      persistence: "PERSISTENT",
      window_overlap: "YES",
      evidence_refs: ["e2"],
    },
    options_iv: {
      price_direction: "UP",
      iv_direction: "UP",
      gvz: { value: 22.4, status: "OBSERVED", evidence_refs: ["e1"] },
      observation_window: "FIXTURE: same weekly window as the price observation",
      event_risk_check: "CLEAR",
      call_put_skew_direction: "CALLS",
      skew_change: { value: "+1.8 vols", status: "OBSERVED", evidence_refs: ["e1"] },
      options_volume_oi: { value: "call volume 1.6x 20-day median", status: "OBSERVED", evidence_refs: ["e1"] },
      fomo_state: "FOMO_CONFIRMED",
      interpretation:
        "FIXTURE: price up with IV up, an elevated call skew against gold's own baseline, confirmed call demand and a clear event-premium check point to real chasing rather than an event premium.",
      evidence_refs: ["e1"],
    },
    gold_skew_baseline: {
      tenor: "FIXTURE: 1-month",
      moneyness: "FIXTURE: 25-delta",
      skew_direction: "CALLS",
      skew_change: { value: "+1.8 vols", status: "OBSERVED", evidence_refs: ["e1"] },
      relative_to_gold_history: "ELEVATED",
      historical_comparison: { value: "88th percentile of gold's own 2-year 25-delta skew", status: "CALCULATED", evidence_refs: ["e1"] },
      event_context: "FIXTURE: no material dated event inside the option tenor",
      status: "CALCULATED",
      evidence_refs: ["e1"],
    },
    gamma: {
      status: "MODEL_ESTIMATED",
      open_interest_by_strike: { value: "FIXTURE: concentration at the nearest round strike", status: "OBSERVED", evidence_refs: ["e1"] },
      dealer_sign_claim: "SUPPORTED",
      model_method: "FIXTURE: dealer sign inferred from a documented inventory model, not from strike OI alone",
      evidence_refs: ["e1"],
    },
    physical_sge: unknownSge("e2", "UP"),
    funding_forced_flow_fuse: unknownFunding("e1", fundingFuse("FIXTURE: a weekly close back below the pre-breakout range would bound the thesis", { measurable: true, status: "IDENTIFIED" })),
  };

  doc.dated_catalyst_assessment = presentCatalyst("e1", {
    name: "FIXTURE: weekly FOMC communication window",
    when: "2026-09-23T18:00:00Z",
    tz: "UTC",
    expiry: "CURRENT",
    activation: "FIXTURE: a dated policy communication can confirm or reject the dovish repricing already underway.",
  });
  doc.invalidation_fuse = {
    observable_condition: "FIXTURE: a weekly close back below the pre-breakout range",
    currently_measurable: true,
    bounds_thesis: true,
    horizon: "FIXTURE: one week",
    status: "IDENTIFIED",
    evidence_refs: ["e2"],
  };
  doc.opportunity_quality = quality(
    "STRONG",
    "FIXTURE: direction, positioned side, flow confirmation, options evidence and a dated activation mechanism all align, with a measurable fuse bounding the thesis.",
    ["e1", "e2"],
  );
  doc.execution_readiness = readiness(
    "READY_IF_TRIGGERED",
    "FIXTURE: the dated catalyst is identified, the activation mechanism is explicit and the invalidation is measurable.",
    ["e1", "e2"],
  );
  setDirectionState(doc, {
    macro_direction: "BULLISH",
    directional_asymmetry: "BULLISH",
    positioning_asymmetry: "BULLISH",
    edge: "BULLISH",
  }, {
    fr: {
      macro_direction: "Direction macro haussière",
      macro_direction_explanation: "FIXTURE: le repricing dovish domine la lecture macro.",
      directional_asymmetry: "Asymétrie directionnelle haussière",
      directional_asymmetry_explanation: "FIXTURE: la chaîne taux réels vers or est franche.",
      positioning_asymmetry: "Positionnement haussier démontré",
      positioning_asymmetry_explanation: "FIXTURE: le positionnement n'est pas encore surchargé du côté haussier.",
      edge: "Avantage haussier démontré",
      edge_explanation: "FIXTURE: direction, positionnement, flux et catalyseur daté vont dans le même sens.",
    },
    en: {
      macro_direction: "Bullish macro direction",
      macro_direction_explanation: "FIXTURE: the dovish repricing dominates the macro read.",
      directional_asymmetry: "Bullish directional asymmetry",
      directional_asymmetry_explanation: "FIXTURE: the real-yield to gold transmission is clean.",
      positioning_asymmetry: "Bullish positioning demonstrated",
      positioning_asymmetry_explanation: "FIXTURE: positioning is not yet overcrowded on the bullish side.",
      edge: "Bullish edge demonstrated",
      edge_explanation: "FIXTURE: direction, positioning, flows and a dated catalyst all align.",
    },
  });
  syncPresentation(doc, doc.opportunity_quality, doc.execution_readiness, {
    fr: {
      quality: "FIXTURE: la direction, le positionnement, les flux et les options sont alignés, avec un fusible mesurable.",
      readiness: "FIXTURE: le catalyseur est daté, le mécanisme d'activation est explicite et l'invalidation est mesurable.",
    },
    en: {
      quality: "FIXTURE: direction, positioning, flows and options are aligned, with a measurable fuse.",
      readiness: "FIXTURE: the catalyst is dated, the activation mechanism is explicit and the invalidation is measurable.",
    },
  });
  doc.executive_narrative = "FIXTURE: a bullish macro direction meets a positioned, flow-confirmed bullish asymmetry with a dated activation mechanism.";
  return doc;
}

// ---------------------------------------------------------------------------
// Fixture B — bullish macro story but positioning TRAP and NO_EDGE
// ---------------------------------------------------------------------------

function fixtureBullishMacroTrap() {
  const doc = readFixture("FIXTURE_sunday_v3_state.json");
  renameSundayRun(doc, "fixture-bullish-macro-trap");
  doc.meta.data_mode = "FIXTURE";
  doc.meta.status = "COMPLETE";
  doc.analysis_contract = contract(["FIXTURE: no comparable SGE window", "FIXTURE: dealer gamma sign not observable"]);

  doc.positioning_evidence = {
    cot: observedCot("e1"),
    price_open_interest: {
      price_direction: "UP",
      oi_direction: "DOWN",
      measurement_window: "FIXTURE: last two weeks, same window as the price observation",
      diagnostic: "FIXTURE: price up with falling open interest is consistent with short covering rather than new money.",
      causal_status: "CONSISTENT_WITH",
      evidence_refs: ["e2"],
    },
    etf_flows: {
      observations: [{ value: "-6t", status: "OBSERVED", evidence_refs: ["e2"], measurement_window: "FIXTURE: 5-day window" }],
      price_confirmation: "DIVERGES",
      persistence: "PERSISTENT",
      window_overlap: "YES",
      evidence_refs: ["e2"],
    },
    options_iv: {
      price_direction: "UP",
      iv_direction: "UP",
      gvz: { value: 26.1, status: "OBSERVED", evidence_refs: ["e1"] },
      observation_window: "FIXTURE: same weekly window as the price observation",
      event_risk_check: "CLEAR",
      call_put_skew_direction: "CALLS",
      skew_change: { value: "+3.1 vols", status: "OBSERVED", evidence_refs: ["e1"] },
      options_volume_oi: { value: "call volume 2.1x 20-day median", status: "OBSERVED", evidence_refs: ["e1"] },
      fomo_state: "FOMO_CONFIRMED",
      interpretation:
        "FIXTURE: price up with IV up, a call skew far above gold's own baseline, confirmed call demand and no event premium to explain it — the residual buyers are late chasers.",
      evidence_refs: ["e1"],
    },
    gold_skew_baseline: {
      tenor: "FIXTURE: 1-month",
      moneyness: "FIXTURE: 25-delta",
      skew_direction: "CALLS",
      skew_change: { value: "+3.1 vols", status: "OBSERVED", evidence_refs: ["e1"] },
      relative_to_gold_history: "EXTREME",
      historical_comparison: { value: "97th percentile of gold's own 2-year 25-delta skew", status: "CALCULATED", evidence_refs: ["e1"] },
      event_context: "FIXTURE: no material dated event inside the option tenor",
      status: "CALCULATED",
      evidence_refs: ["e1"],
    },
    gamma: unknownGamma("e1"),
    physical_sge: {
      international_price_direction: "UP",
      sge_premium_discount: { value: "-1.2 USD/oz discount", status: "OBSERVED", evidence_refs: ["e2"] },
      divergence: "CONFIRMED",
      comparability: {
        timestamp_alignment: "FIXTURE: same trading session, aligned to the same close",
        usd_cny: "FIXTURE: same USD/CNY fix used on both legs",
        benchmark: "FIXTURE: Shanghai Gold Exchange benchmark vs London PM fix",
        frictions: "FIXTURE: VAT and import frictions explicitly netted out",
        persistence: "FIXTURE: present on five consecutive sessions",
        methodology: "FIXTURE: identical conversion and windowing methodology on both legs",
      },
      status: "OBSERVED",
      evidence_refs: ["e2"],
    },
    funding_forced_flow_fuse: unknownFunding("e1", fundingFuse("FIXTURE: a weekly close back below the pre-breakout range would bound the thesis", { measurable: true, status: "IDENTIFIED" })),
  };

  doc.dated_catalyst_assessment = presentCatalyst("e1", {
    name: "FIXTURE: weekly CPI print",
    when: "2026-09-24T12:30:00Z",
    tz: "UTC",
    expiry: "CURRENT",
    activation: "FIXTURE: a hot CPI print would force the crowded long side to unwind.",
  });
  doc.invalidation_fuse = identifiedFuse("e2", "FIXTURE: a weekly close back below the pre-breakout range would bound the thesis");
  doc.opportunity_quality = quality(
    "TRAP",
    "FIXTURE: the same-direction long side is already crowded and extreme; the marginal flow is diverging, so the remaining upside is limited and the downside on a surprise is violent.",
    ["e1", "e2"],
  );
  doc.execution_readiness = readiness(
    "NOT_READY",
    "FIXTURE: the story is attractive, but the asymmetry now runs against a new long entry, so the configuration is not executable in the story's direction.",
    ["e1", "e2"],
  );
  setDirectionState(doc, {
    macro_direction: "BULLISH",
    directional_asymmetry: "BULLISH",
    positioning_asymmetry: "CROWDED",
    edge: "NO_EDGE",
  }, {
    fr: {
      macro_direction: "Direction macro haussière",
      macro_direction_explanation: "FIXTURE: le contexte macro reste haussier.",
      directional_asymmetry: "Asymétrie directionnelle haussière",
      directional_asymmetry_explanation: "FIXTURE: la chaîne de transmission macro reste orientée à la hausse.",
      positioning_asymmetry: "Positionnement haussier surchargé",
      positioning_asymmetry_explanation: "FIXTURE: le camp haussier est déjà à l'extrême ; les acheteurs restants sont tardifs.",
      edge: "Pas d'avantage directionnel démontré",
      edge_explanation: "FIXTURE: une bonne histoire macro avec un positionnement déjà à l'extrême du même côté n'est pas un avantage exploitable.",
    },
    en: {
      macro_direction: "Bullish macro direction",
      macro_direction_explanation: "FIXTURE: the macro backdrop remains bullish.",
      directional_asymmetry: "Bullish directional asymmetry",
      directional_asymmetry_explanation: "FIXTURE: the macro transmission chain still points higher.",
      positioning_asymmetry: "Crowded bullish positioning",
      positioning_asymmetry_explanation: "FIXTURE: the bullish side is already at an extreme; the remaining buyers are late.",
      edge: "No directional edge demonstrated",
      edge_explanation: "FIXTURE: a good macro story with positioning already extreme on the same side is not an exploitable edge.",
    },
  });
  doc.late = { status: "CROWDED", reason: "FIXTURE: the same-direction side is crowded and the marginal flow is diverging." };
  syncPresentation(doc, doc.opportunity_quality, doc.execution_readiness, {
    fr: {
      quality: "FIXTURE: le positionnement est déjà à l'extrême du même côté et le flux marginal diverge.",
      readiness: "FIXTURE: l'asymétrie joue contre une nouvelle entrée dans le sens de l'histoire.",
    },
    en: {
      quality: "FIXTURE: positioning is already extreme on the same side and the marginal flow is diverging.",
      readiness: "FIXTURE: the asymmetry now runs against a new entry in the story's direction.",
    },
  });
  doc.executive_narrative = "FIXTURE: a bullish macro story that is no longer an opportunity — the crowd is already positioned.";
  return doc;
}

// ---------------------------------------------------------------------------
// Fixture C — bearish vulnerability, WAITING_FOR_CATALYST, NO_EDGE
// ---------------------------------------------------------------------------

function fixtureBearishVulnerabilityWaiting() {
  const doc = readFixture("FIXTURE_sunday_v3_state.json");
  renameSundayRun(doc, "fixture-c-bearish-vulnerability-waiting");
  doc.meta.data_mode = "FIXTURE";
  doc.meta.status = "COMPLETE";
  doc.analysis_contract = contract([
    "FIXTURE: the crowded long side is identified but the dated trigger is not yet scheduled",
    "FIXTURE: dealer gamma sign not observable",
  ]);

  doc.positioning_evidence = {
    cot: observedCot("e1"),
    price_open_interest: {
      price_direction: "UP",
      oi_direction: "DOWN",
      measurement_window: "FIXTURE: last two weeks, same window as the price observation",
      diagnostic: "FIXTURE: price up with falling open interest is consistent with short covering, not new money.",
      causal_status: "CONSISTENT_WITH",
      evidence_refs: ["e2"],
    },
    etf_flows: emptyEtf("e2"),
    options_iv: noFomoOptions("e1", "UP"),
    gold_skew_baseline: { tenor: null, moneyness: null, skew_direction: "UNKNOWN", relative_to_gold_history: "UNKNOWN", event_context: "FIXTURE: no event context established", status: "UNKNOWN", evidence_refs: ["e1"] },
    gamma: unknownGamma("e1"),
    physical_sge: unknownSge("e2", "UP"),
    funding_forced_flow_fuse: unknownFunding("e1", fundingFuse("FIXTURE: no reliably observable fuse has been identified for this configuration", { measurable: false, status: "UNKNOWN" })),
  };
  doc.dated_catalyst_assessment = noCatalyst("e1");
  doc.invalidation_fuse = unknownFuse("e1");
  doc.opportunity_quality = quality(
    "MEDIUM",
    "FIXTURE: a vulnerability exists — the crowded long side would be forced to act on an adverse surprise — but no dated trigger and no measurable fuse are established yet.",
    ["e1", "e2"],
  );
  doc.execution_readiness = readiness(
    "WAITING_FOR_CATALYST",
    "FIXTURE: the vulnerability is real but not executable until a dated activation mechanism and a measurable invalidation exist.",
    ["e1", "e2"],
  );
  setDirectionState(doc, {
    macro_direction: "MIXED",
    directional_asymmetry: "BEARISH",
    positioning_asymmetry: "CROWDED",
    edge: "NO_EDGE",
  }, {
    fr: {
      macro_direction: "Direction macro mixte",
      macro_direction_explanation: "FIXTURE: aucun moteur macro dominant ne tranche cette semaine.",
      directional_asymmetry: "Asymétrie directionnelle baissière",
      directional_asymmetry_explanation: "FIXTURE: la vulnérabilité penche à la baisse si le positionnement se déboucle.",
      positioning_asymmetry: "Positionnement haussier surchargé",
      positioning_asymmetry_explanation: "FIXTURE: le camp long est coincé et devra agir sur une mauvaise surprise.",
      edge: "Pas d'avantage directionnel démontré",
      edge_explanation: "FIXTURE: sans catalyseur daté ni fusible mesurable, la vulnérabilité n'est pas exécutable.",
    },
    en: {
      macro_direction: "Mixed macro direction",
      macro_direction_explanation: "FIXTURE: no dominant macro driver settles the week.",
      directional_asymmetry: "Bearish directional asymmetry",
      directional_asymmetry_explanation: "FIXTURE: the vulnerability leans lower if positioning unwinds.",
      positioning_asymmetry: "Crowded bullish positioning",
      positioning_asymmetry_explanation: "FIXTURE: the long side is trapped and will have to act on an adverse surprise.",
      edge: "No directional edge demonstrated",
      edge_explanation: "FIXTURE: without a dated catalyst or measurable fuse, the vulnerability is not executable.",
    },
  });
  syncPresentation(doc, doc.opportunity_quality, doc.execution_readiness, {
    fr: {
      quality: "FIXTURE: la vulnérabilité est réelle et identifiée, mais rien ne dit encore QUAND elle se matérialise.",
      readiness: "FIXTURE: sans mécanisme d'activation daté ni invalidation mesurable, elle ne peut pas être exécutée.",
    },
    en: {
      quality: "FIXTURE: the vulnerability is real and identified, but nothing yet says WHEN it materialises.",
      readiness: "FIXTURE: without a dated activation mechanism or a measurable invalidation, it cannot be executed.",
    },
  });
  doc.executive_narrative = "FIXTURE: a bearish vulnerability exists, but it is not yet executable and the final edge remains NO_EDGE.";
  return doc;
}

// ---------------------------------------------------------------------------
// Fixture D — options/gamma UNKNOWN without fabrication (intermediate lineage)
// ---------------------------------------------------------------------------

function fixtureOptionsGammaUnknown() {
  const doc = readFixture("FIXTURE_intermediate_v3_state.json");
  doc.meta.run_id = "fixture-d-options-gamma-unknown";
  doc.meta.data_mode = "FIXTURE";
  doc.meta.status = "COMPLETE";
  doc.analysis_contract = contract([
    "FIXTURE: dealer gamma sign is not observable and no model estimate is authorised",
    "FIXTURE: no comparable SGE window",
    "FIXTURE: COT publication lag",
  ]);

  doc.positioning_evidence.cot = laggedCot("e2");
  doc.positioning_evidence.gamma = {
    status: "UNKNOWN",
    dealer_sign_claim: "NONE",
    evidence_refs: ["e1"],
  };
  doc.positioning_evidence.options_iv = noFomoOptions("e1", "UP");
  doc.positioning_evidence.gold_skew_baseline = {
    tenor: null,
    moneyness: null,
    skew_direction: "UNKNOWN",
    relative_to_gold_history: "UNKNOWN",
    event_context: "FIXTURE: no event context established",
    status: "UNKNOWN",
    evidence_refs: ["e1"],
  };
  doc.positioning_evidence.physical_sge = unknownSge("e2", "UP");
  doc.dated_catalyst_assessment = presentCatalyst("e2", {
    name: "FIXTURE: weekly COT publication",
    when: "2026-09-26T12:30:00Z",
    tz: "UTC",
    expiry: "CURRENT",
    activation: "FIXTURE: the publication can confirm or reject the post-FOMC positioning hypothesis.",
  });
  doc.invalidation_fuse = unknownFuse("e1");
  doc.opportunity_quality = quality(
    "UNKNOWN",
    "FIXTURE: option and gamma observability are insufficient, so no opportunity-quality claim is warranted.",
    ["e1", "e2"],
  );
  doc.execution_readiness = readiness(
    "WAITING_FOR_CATALYST",
    "FIXTURE: the scheduled publication is needed before readiness can be assessed.",
    ["e2"],
  );
  setDirectionState(doc, {
    macro_direction: "BULLISH",
    directional_asymmetry: "BULLISH",
    positioning_asymmetry: "UNKNOWN",
    edge: "UNKNOWN",
  }, {
    fr: {
      macro_direction: "Direction macro haussière",
      macro_direction_explanation: "FIXTURE: le repricing dovish soutient la direction macro.",
      directional_asymmetry: "Asymétrie directionnelle haussière",
      directional_asymmetry_explanation: "FIXTURE: la chaîne de transmission reste orientée à la hausse.",
      positioning_asymmetry: "Positionnement non déterminé",
      positioning_asymmetry_explanation: "FIXTURE: les données de positionnement et d'options sont indisponibles ; aucune valeur neutre n'est supposée.",
      edge: "Avantage encore indéterminé",
      edge_explanation: "FIXTURE: sans observabilité du positionnement, l'existence d'un avantage reste inconnue.",
    },
    en: {
      macro_direction: "Bullish macro direction",
      macro_direction_explanation: "FIXTURE: the dovish repricing supports the macro direction.",
      directional_asymmetry: "Bullish directional asymmetry",
      directional_asymmetry_explanation: "FIXTURE: the transmission chain still points higher.",
      positioning_asymmetry: "Positioning undetermined",
      positioning_asymmetry_explanation: "FIXTURE: positioning and options data are unavailable; no neutral value is assumed.",
      edge: "Edge still undetermined",
      edge_explanation: "FIXTURE: without positioning observability, whether an edge exists remains unknown.",
    },
  });
  syncPresentation(doc, doc.opportunity_quality, doc.execution_readiness, {
    fr: {
      quality: "FIXTURE: l'observabilité des options et du gamma est insuffisante ; aucune conclusion n'est fabriquée.",
      readiness: "FIXTURE: la publication attendue doit d'abord confirmer ou invalider l'hypothèse.",
    },
    en: {
      quality: "FIXTURE: option and gamma observability is insufficient; no conclusion is fabricated.",
      readiness: "FIXTURE: the pending publication must first confirm or reject the hypothesis.",
    },
  });
  doc.executive_narrative = "FIXTURE: options and gamma remain genuinely unknown and are recorded as such rather than invented.";
  return doc;
}

// ---------------------------------------------------------------------------
// Fixture E — price up + IV up classified EVENT_VOL_PREMIUM, not FOMO
// ---------------------------------------------------------------------------

function fixtureEventVolPremium() {
  const doc = readFixture("FIXTURE_sunday_v3_state.json");
  renameSundayRun(doc, "fixture-e-event-vol-premium");
  doc.meta.data_mode = "FIXTURE";
  doc.meta.status = "COMPLETE";
  doc.analysis_contract = contract(["FIXTURE: no comparable SGE window", "FIXTURE: dealer gamma sign not observable"]);

  doc.positioning_evidence = {
    cot: laggedCot("e2"),
    price_open_interest: {
      price_direction: "UP",
      oi_direction: "UP",
      measurement_window: "FIXTURE: same weekly window as the price observation",
      diagnostic: "FIXTURE: price up with rising open interest is consistent with new participation.",
      causal_status: "POSSIBLE",
      evidence_refs: ["e1"],
    },
    etf_flows: emptyEtf("e2"),
    options_iv: {
      price_direction: "UP",
      iv_direction: "UP",
      gvz: { value: 24.8, status: "OBSERVED", evidence_refs: ["e1"] },
      observation_window: "FIXTURE: the window immediately ahead of a dated event",
      event_risk_check: "PRESENT",
      call_put_skew_direction: "FLAT",
      skew_change: { value: "+0.2 vols", status: "OBSERVED", evidence_refs: ["e1"] },
      options_volume_oi: { value: "call volume 1.1x 20-day median", status: "OBSERVED", evidence_refs: ["e1"] },
      fomo_state: "EVENT_VOL_PREMIUM",
      interpretation:
        "FIXTURE: price up with IV up, but the IV rise is fully explained by an imminent dated event, the call skew is flat, and call demand is unremarkable — this is an event premium, not FOMO.",
      evidence_refs: ["e1"],
    },
    gold_skew_baseline: {
      tenor: "FIXTURE: 1-month",
      moneyness: "FIXTURE: 25-delta",
      skew_direction: "FLAT",
      skew_change: { value: "+0.2 vols", status: "OBSERVED", evidence_refs: ["e1"] },
      relative_to_gold_history: "NORMAL",
      historical_comparison: { value: "52nd percentile of gold's own 2-year 25-delta skew", status: "CALCULATED", evidence_refs: ["e1"] },
      event_context: "FIXTURE: a dated macro event falls inside the option tenor",
      status: "CALCULATED",
      evidence_refs: ["e1"],
    },
    gamma: unknownGamma("e1"),
    physical_sge: unknownSge("e2", "UP"),
    funding_forced_flow_fuse: unknownFunding("e1", fundingFuse("FIXTURE: no reliably observable fuse has been identified for this configuration", { measurable: false, status: "UNKNOWN" })),
  };
  doc.dated_catalyst_assessment = presentCatalyst("e1", {
    name: "FIXTURE: dated macro event inside the option tenor",
    when: "2026-09-23T18:00:00Z",
    tz: "UTC",
    expiry: "CURRENT",
    activation: "FIXTURE: the event is the reason the implied volatility is elevated; it is not evidence of chasing.",
  });
  doc.invalidation_fuse = unknownFuse("e1");
  doc.opportunity_quality = quality(
    "MEDIUM",
    "FIXTURE: the price/IV pattern is explained by a dated event premium rather than by crowding, so no FOMO claim is made.",
    ["e1"],
  );
  doc.execution_readiness = readiness(
    "CATALYST_PRESENT_BUT_UNCONFIRMED",
    "FIXTURE: the dated catalyst exists and is named, but its transmission into positioning is not yet confirmed.",
    ["e1"],
  );
  setDirectionState(doc, {
    macro_direction: "BULLISH",
    directional_asymmetry: "BULLISH",
    positioning_asymmetry: "UNKNOWN",
    edge: "UNKNOWN",
  }, {
    fr: {
      macro_direction: "Direction macro haussière",
      macro_direction_explanation: "FIXTURE: la direction macro reste haussière.",
      directional_asymmetry: "Asymétrie directionnelle haussière",
      directional_asymmetry_explanation: "FIXTURE: la transmission directionnelle est claire.",
      positioning_asymmetry: "Positionnement non déterminé",
      positioning_asymmetry_explanation: "FIXTURE: le positionnement n'est pas encore publié ; aucune lecture neutre n'est supposée.",
      edge: "Avantage encore indéterminé",
      edge_explanation: "FIXTURE: la hausse du prix et de l'IV est une prime d'événement, pas un avantage démontré.",
    },
    en: {
      macro_direction: "Bullish macro direction",
      macro_direction_explanation: "FIXTURE: the macro direction remains bullish.",
      directional_asymmetry: "Bullish directional asymmetry",
      directional_asymmetry_explanation: "FIXTURE: the directional transmission is clear.",
      positioning_asymmetry: "Positioning undetermined",
      positioning_asymmetry_explanation: "FIXTURE: positioning is not yet published; no neutral reading is assumed.",
      edge: "Edge still undetermined",
      edge_explanation: "FIXTURE: the price and IV rise is an event premium, not a demonstrated edge.",
    },
  });
  syncPresentation(doc, doc.opportunity_quality, doc.execution_readiness, {
    fr: {
      quality: "FIXTURE: la hausse de l'IV est expliquée par un événement daté, pas par un comportement de foule.",
      readiness: "FIXTURE: le catalyseur est nommé mais sa transmission au positionnement n'est pas encore confirmée.",
    },
    en: {
      quality: "FIXTURE: the IV rise is explained by a dated event, not by crowd behaviour.",
      readiness: "FIXTURE: the catalyst is named but its transmission into positioning is not yet confirmed.",
    },
  });
  doc.executive_narrative = "FIXTURE: price up with IV up is classified as an event premium, not as FOMO.";
  return doc;
}

// ---------------------------------------------------------------------------
// Fixture F — intermediate transition from parent state
// ---------------------------------------------------------------------------

function fixtureIntermediateTransition() {
  const doc = readFixture("FIXTURE_intermediate_v3_state.json");
  doc.meta.run_id = "fixture-f-intermediate-transition";
  doc.meta.data_mode = "FIXTURE";
  doc.meta.status = "COMPLETE";
  doc.meta.parent_run_id = "fixture-e-event-vol-premium";
  // The parent (fixture E) is a Sunday run and therefore its own origin; a child
  // must carry its parent's origin, never another run's.
  doc.meta.origin_sunday_run_id = "fixture-e-event-vol-premium";
  doc.analysis_contract = contract(["FIXTURE: comparable SGE window still unavailable", "FIXTURE: dealer gamma sign not observable"]);

  doc.positioning_evidence.cot = observedCot("e2");
  doc.positioning_evidence.gamma = unknownGamma("e1");
  doc.positioning_evidence.physical_sge = unknownSge("e2", "UP");
  doc.positioning_evidence.funding_forced_flow_fuse = unknownFunding("e1", fundingFuse("FIXTURE: a weekly close back below the pre-event range would bound the thesis", { measurable: true, status: "IDENTIFIED" }));
  doc.dated_catalyst_assessment = presentCatalyst("e2", {
    name: "FIXTURE: weekly COT publication",
    when: "2026-09-26T12:30:00Z",
    tz: "UTC",
    expiry: "CURRENT",
    activation: "FIXTURE: the publication is the first hard confirmation after the parent state's event premium.",
  });
  doc.invalidation_fuse = identifiedFuse("e2", "FIXTURE: a weekly close back below the pre-event range would bound the thesis");
  doc.opportunity_quality = quality(
    "MEDIUM",
    "FIXTURE: the parent state's event premium has resolved into an observable positioning picture, but flow confirmation is still partial.",
    ["e1", "e2"],
  );
  doc.execution_readiness = readiness(
    "WAITING_FOR_CATALYST",
    "FIXTURE: the transition is under way but awaits the scheduled publication before readiness changes.",
    ["e2"],
  );
  doc.scenario_transitions = [
    { scenario_ref: "S1", transition_state: "TRANSMISSION_PARTIAL", evidence_refs: ["e1", "e2"] },
  ];
  setDirectionState(doc, {
    macro_direction: "BULLISH",
    directional_asymmetry: "BULLISH",
    positioning_asymmetry: "BULLISH",
    edge: "UNKNOWN",
  }, {
    fr: {
      macro_direction: "Direction macro haussière",
      macro_direction_explanation: "FIXTURE: la direction macro héritée du run parent reste haussière.",
      directional_asymmetry: "Asymétrie directionnelle haussière",
      directional_asymmetry_explanation: "FIXTURE: la transmission directionnelle est confirmée depuis le run parent.",
      positioning_asymmetry: "Positionnement haussier démontré",
      positioning_asymmetry_explanation: "FIXTURE: le positionnement confirme désormais la direction.",
      edge: "Avantage encore indéterminé",
      edge_explanation: "FIXTURE: la confirmation des flux reste partielle, l'avantage final n'est pas encore établi.",
    },
    en: {
      macro_direction: "Bullish macro direction",
      macro_direction_explanation: "FIXTURE: the macro direction inherited from the parent run remains bullish.",
      directional_asymmetry: "Bullish directional asymmetry",
      directional_asymmetry_explanation: "FIXTURE: directional transmission is confirmed from the parent run.",
      positioning_asymmetry: "Bullish positioning demonstrated",
      positioning_asymmetry_explanation: "FIXTURE: positioning now confirms the direction.",
      edge: "Edge still undetermined",
      edge_explanation: "FIXTURE: flow confirmation remains partial, so the final edge is not yet established.",
    },
  });
  syncPresentation(doc, doc.opportunity_quality, doc.execution_readiness, {
    fr: {
      quality: "FIXTURE: la prime d'événement du run parent s'est résolue en une image de positionnement observable.",
      readiness: "FIXTURE: la transition est en cours et attend la publication planifiée.",
    },
    en: {
      quality: "FIXTURE: the parent run's event premium resolved into an observable positioning picture.",
      readiness: "FIXTURE: the transition is under way and awaits the scheduled publication.",
    },
  });
  doc.executive_narrative = "FIXTURE: an intermediate state transitioning from its parent, with the parent's event premium resolved.";
  return doc;
}

// ---------------------------------------------------------------------------
// Fixture G — handoff carrying updated asymmetry checkpoints
// ---------------------------------------------------------------------------

function fixtureHandoffCheckpoints() {
  const doc = readFixture("FIXTURE_next_gold_recap.json");
  doc.handoff_id = "fixture-g-handoff-asymmetry-checkpoints";
  doc.handoff_version = 3;
  doc.created_by_run_id = "fixture-f-intermediate-transition";
  doc.origin_sunday_run_id = "fixture-e-event-vol-premium";
  doc.parent_state_run_id = "fixture-f-intermediate-transition";
  doc.inherited_state = {
    macro_direction: "BULLISH",
    directional_asymmetry: "BULLISH",
    positioning_asymmetry: "BULLISH",
    edge: "UNKNOWN",
    opportunity_quality: "MEDIUM",
    execution_readiness: "WAITING_FOR_CATALYST",
    summary: "FIXTURE: positioning now confirms direction, but flow confirmation and the final edge remain open.",
  };
  doc.asymmetry_checkpoints = [
    {
      checkpoint_id: "ASYM-1",
      question: "FIXTURE: did the published positioning data convert the medium-quality opportunity into a strong one?",
      evidence_to_refresh: [
        "FIXTURE: COT publication and its Tuesday observation",
        "FIXTURE: ETF flows since the prior cutoff",
        "FIXTURE: price/open interest with a comparable window",
        "FIXTURE: price/implied volatility and gold's own skew baseline",
        "FIXTURE: event premium versus a FOMO reading",
        "FIXTURE: gamma only if legitimately observed or explicitly modelled",
        "FIXTURE: SGE and physical confirmation with comparable windows",
        "FIXTURE: funding and fuse conditions",
      ],
      transition_to_watch: ["opportunity quality", "execution readiness", "final edge"],
      evidence_refs: ["e1", "e2"],
    },
    {
      checkpoint_id: "ASYM-2",
      question: "FIXTURE: has the identified invalidation fuse become measurable, or has it been breached?",
      evidence_to_refresh: ["FIXTURE: weekly close versus the pre-event range", "FIXTURE: real yields"],
      transition_to_watch: ["final edge", "scenario transition state"],
      evidence_refs: ["e2"],
    },
  ];
  return doc;
}

// ---------------------------------------------------------------------------
// Procedural audit (specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md)
//
// Factual traces only: phase status, timestamps, question outcomes, references,
// consulted source categories, recovery attempts and limits. FIXTURE values.
// ---------------------------------------------------------------------------

const SUNDAY_BASE = readFixture("FIXTURE_sunday_v3_state.json");

function fixtureEvidence(id, family, owner, statement, asOf, window, sourceRefs) {
  return {
    id, family, owner, statement, value: "FIXTURE", unit: null, as_of: asOf, measurement_window: window,
    status: "ANSWERED", type: "STATE", epistemic_status: "PUBLISHED", change_status: "FIXTURE: refreshed",
    source_refs: sourceRefs, reported_link_type: "OTHER", notes: "FIXTURE evidence, not real market data.",
  };
}

// Give a fixture one evidence item per collection module, a second source, and
// the reasoning outputs the procedural audit points at. Intermediates keep the
// prior-week timeline of their Sunday origin instead of dropping it.
function enrichForProcedure(doc) {
  const intermediate = doc.meta.run_type === "INTERMEDIATE";
  const asOf = doc.meta.as_of;
  doc.sources.push({ ...doc.sources[0], source_id: "s2", title: "FIXTURE official data release", publisher: "FIXTURE official publisher", url: "https://example.com/fixture-official-data", provider: "fixture-official" });
  const wanted = intermediate
    ? [["e5", "family_3_usd", "F3", "FIXTURE: dollar state refreshed."], ["e7", "family_5_flows", "F5", "FIXTURE: flow and positioning state refreshed."]]
    : [["e4", "weekly_recap", "WEEKLY_RECAP", "FIXTURE: weekly price facts reconstructed."], ["e5", "family_3_usd", "F3", "FIXTURE: dollar state."], ["e6", "family_4_macro", "F4", "FIXTURE: macro release state."], ["e7", "family_5_flows", "F5", "FIXTURE: flow and positioning state."]];
  for (const [id, family, owner, statement] of wanted) doc.evidence.push(fixtureEvidence(id, family, owner, statement, asOf, intermediate ? "post-event" : "week", ["s2"]));
  doc.competing_hypotheses = [
    { id: "H1", thesis: "FIXTURE: the repricing of the Fed path is the dominant driver.", evidence_for: ["e1", "e2"], evidence_against: ["e5"], status: "LEADING" },
    { id: "H2", thesis: "FIXTURE: the move is mostly positioning rather than macro.", evidence_for: ["e7"], evidence_against: ["e1"], status: "TRAILING" },
  ];
  doc.dominant_driver = "FIXTURE: repricing of the Fed path";
  doc.transmission_chains = ["FIXTURE: Fed repricing, then real yields, then the dollar, then gold."];
  doc.cross_asset_reality_test = { summary: "FIXTURE: rates and the dollar moved as the leading hypothesis requires.", matching_hypothesis_ids: ["H1"], conflicting_observations: ["FIXTURE: flows lag the price move."] };
  if (intermediate) doc.weekly_timeline = structuredClone(SUNDAY_BASE.weekly_timeline);
}

const ans = (question_id, evidence_refs, source_categories, as_of, measurement_window, source_refs = ["s1"]) => ({
  question_id, outcome: "ANSWERED", as_of, measurement_window, evidence_refs, source_refs, source_categories,
});
const limited = (question_id, outcome, reason, explanation, extra = {}) => ({
  question_id, outcome, as_of: null, measurement_window: null, evidence_refs: [], source_refs: [], source_categories: [],
  limitation: { reason, explanation }, ...extra,
});
const recovery = (source, result) => ({ registry_consulted: true, attempts: [{ source, result }] });

function positioningQuestions(doc, asOf, window) {
  const p = doc.positioning_evidence;
  const cotLagged = p.cot.epistemic_status === "UNKNOWN";
  const etfLagged = p.etf_flows.observations.every((o) => o.status === "PUBLICATION_LAG");
  const optionsKnown = p.options_iv.fomo_state !== "UNKNOWN";
  const fuseKnown = doc.invalidation_fuse.status === "IDENTIFIED";
  return [
    cotLagged
      ? limited("F5.COT", "PUBLICATION_LAG", "PUBLICATION_LAG", "FIXTURE: the Tuesday COT observation is published on Friday, after this cutoff.", { publication_limit: "FIXTURE: published Friday after the cutoff", source_categories: ["OFFICIAL_DATA"], source_refs: ["s2"] })
      : ans("F5.COT", ["e7"], ["OFFICIAL_DATA"], asOf, "FIXTURE: Tuesday observation", ["s2"]),
    ans("F5.OPEN_INTEREST", ["e7"], ["EXCHANGE_OR_CLEARING"], asOf, window, ["s2"]),
    etfLagged
      ? limited("F5.ETF_FLOWS", "PUBLICATION_LAG", "PUBLICATION_LAG", "FIXTURE: issuer holdings for the window are not published yet.", { publication_limit: "FIXTURE: next issuer publication", source_categories: ["FUND_ISSUER"] })
      : ans("F5.ETF_FLOWS", ["e7"], ["FUND_ISSUER"], asOf, "FIXTURE: 5-day window", ["s2"]),
    optionsKnown
      ? ans("F5.OPTIONS", ["e7"], ["EXCHANGE_OR_CLEARING", "MARKET_DATA_PROVIDER"], asOf, window, ["s2"])
      : limited("F5.OPTIONS", "UNKNOWN", "SOURCE_NOT_FOUND", "FIXTURE: no Gold-specific IV, skew or volume observation could be established.", {
        source_categories: ["EXCHANGE_OR_CLEARING"], source_recovery: recovery("FIXTURE: CME QuikStrike option tools (registry: F5 Gold options)", "INACCESSIBLE"),
      }),
    ans("F5.Q1_FLOW", ["e7"], ["EXCHANGE_OR_CLEARING"], asOf, window, ["s2"]),
    limited("F5.Q2_FORCED_ACTOR", "UNKNOWN", "STRUCTURALLY_NON_OBSERVABLE", "FIXTURE: a mechanically forced actor cannot be identified from public COT, price or OI data alone."),
    limited("F5.Q3_FUNDING", "PARTIAL", "SOURCE_NOT_FOUND", "FIXTURE: only proxies exist for the funding of leveraged Gold positions; none proves funding stress.", {
      source_categories: ["EXCHANGE_OR_CLEARING", "MARKET_DATA_PROVIDER"], source_recovery: recovery("FIXTURE: CME margin notices and futures basis (registry: F5 leveraged funding)", "NOT_SEMANTICALLY_VALID"),
    }),
    fuseKnown
      ? ans("F5.Q4_FUSE", ["e2"], ["OFFICIAL_DATA"], asOf, "FIXTURE: one week", ["s2"])
      : limited("F5.Q4_FUSE", "UNKNOWN", "STRUCTURALLY_NON_OBSERVABLE", "FIXTURE: no observable trigger capable of forcing an unwind is identifiable for this configuration."),
    ans("F5.Q5_MARGINAL_FLOW", ["e7"], ["EXCHANGE_OR_CLEARING"], asOf, window, ["s2"]),
  ];
}

function sundayCollection(doc) {
  const asOf = doc.meta.as_of; const w = "week";
  const sgeKnown = doc.positioning_evidence.physical_sge.status === "OBSERVED";
  return {
    weekly_recap: { questions: [
      ans("WR.DAILY_PRICE_FACTS", ["e4"], ["EXCHANGE_OR_CLEARING"], asOf, "FIXTURE: Monday to Friday settlements", ["s2"]),
      ans("WR.BENCHMARK_CONTRACT", ["e4"], ["EXCHANGE_OR_CLEARING"], asOf, "FIXTURE: one contract across the window", ["s2"]),
      ans("WR.EVENTS", ["e4"], ["WIRE_OR_PRESS"], asOf, w),
      ans("WR.CROSS_ASSET_MOVES", ["e4"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"]),
      ans("WR.REPORTED_ATTRIBUTION", ["e4"], ["WIRE_OR_PRESS"], asOf, w),
    ] },
    F1: { questions: [
      ans("F1.FED_PRICING", ["e1"], ["EXCHANGE_OR_CLEARING"], asOf, w), ans("F1.US2Y", ["e1"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w),
      ans("F1.FED_COMMUNICATION", ["e1"], ["CENTRAL_BANK_OR_TREASURY", "WIRE_OR_PRESS"], asOf, w), ans("F1.NEXT_FOMC", ["e1"], ["CENTRAL_BANK_OR_TREASURY"], asOf, "FIXTURE: next meeting"),
    ] },
    F2: { questions: [
      ans("F2.DFII10", ["e2"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w), ans("F2.NOMINAL_REAL_BREAKEVEN", ["e2"], ["CENTRAL_BANK_OR_TREASURY"], asOf, "FIXTURE: 10-year breakeven tenor named"),
      ans("F2.LEADING_MATURITY", ["e2"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w), ans("F2.CURVE_2S10S", ["e2"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w),
      limited("F2.MOVE", "NOT_APPLICABLE", "NOT_MATERIAL_THIS_RUN", "FIXTURE: MOVE is contextual and carried no unusual rates stress this week."),
      ans("F2.F1_OVERLAP", ["e2"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w),
    ] },
    F3: { questions: [
      ans("F3.DXY", ["e5"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"]),
      limited("F3.GOLD_DXY_30D", "PARTIAL", "SOURCE_NOT_FOUND", "FIXTURE: no published 30-day Gold-DXY metric; only a qualitative co-movement description is supported.", {
        source_categories: ["MARKET_DATA_PROVIDER"], source_recovery: recovery("FIXTURE: deterministic calculation from daily closes (collection spec section 7)", "UNAVAILABLE"),
      }),
      ans("F3.USDJPY", ["e5"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"]), ans("F3.USDCNH", ["e5"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"]),
      ans("F3.USD_LIQUIDITY", ["e5"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w, ["s2"]),
    ] },
    F4: { questions: [
      ans("F4.MACRO_RELEASES", ["e6"], ["OFFICIAL_DATA"], asOf, w, ["s2"]), ans("F4.OIL", ["e6"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"]),
      limited("F4.TREASURY_AUCTIONS", "PUBLICATION_LAG", "PUBLICATION_LAG", "FIXTURE: the next relevant auction result is published after the cutoff.", { publication_limit: "FIXTURE: next auction is after the cutoff", source_categories: ["CENTRAL_BANK_OR_TREASURY"] }),
      ans("F4.CREDIT_HY_IG", ["e6"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"]),
    ] },
    F5: { questions: positioningQuestions(doc, asOf, w) },
    F6: { questions: [
      ans("F6.CENTRAL_BANK_DEMAND", ["e3"], ["INDUSTRY_DATASET"], asOf, "quarter"),
      sgeKnown
        ? ans("F6.CHINA_PHYSICAL", ["e2"], ["INDUSTRY_DATASET"], asOf, w)
        : limited("F6.CHINA_PHYSICAL", "UNKNOWN", "SOURCE_NOT_FOUND", "FIXTURE: no comparable Shanghai premium window could be aligned defensibly.", {
          source_categories: ["INDUSTRY_DATASET"], source_recovery: recovery("FIXTURE: World Gold Council premium dataset, then SGE reconstruction (registry: F6 Shanghai premium)", "UNAVAILABLE"),
        }),
      ans("F6.DEDOLLARIZATION", ["e3"], ["INDUSTRY_DATASET"], asOf, "quarter"), ans("F6.DEBASEMENT_THEME", ["e3"], ["INDUSTRY_DATASET"], asOf, "quarter"),
    ] },
  };
}

function intermediateCollection(doc) {
  const asOf = doc.meta.as_of; const w = "post-event";
  return {
    F1: { questions: [ans("F1.FED_PRICING", ["e1"], ["EXCHANGE_OR_CLEARING"], asOf, w), ans("F1.FED_COMMUNICATION", ["e1"], ["CENTRAL_BANK_OR_TREASURY", "WIRE_OR_PRESS"], asOf, w)] },
    F2: { questions: [ans("F2.DFII10", ["e2"], ["CENTRAL_BANK_OR_TREASURY"], asOf, w)] },
    F3: { questions: [ans("F3.DXY", ["e5"], ["MARKET_DATA_PROVIDER"], asOf, w, ["s2"])] },
    F4: { questions: [limited("F4.MACRO_RELEASES", "NOT_APPLICABLE", "NOT_DUE_THIS_CYCLE", "FIXTURE: no material inflation or fiscal release is scheduled inside this window.")] },
    F5: { questions: positioningQuestions(doc, asOf, w).filter((q) => ["F5.COT", "F5.ETF_FLOWS", "F5.Q4_FUSE"].includes(q.question_id)) },
    F6: { questions: [ans("F6.CENTRAL_BANK_DEMAND", ["e3"], ["INDUSTRY_DATASET"], asOf, "quarter")] },
  };
}

function reasoningComponents(doc) {
  return Object.entries(REASONING_COMPONENTS).map(([component, path]) => {
    const value = doc[path];
    const present = Array.isArray(value) ? value.length > 0 : Boolean(value);
    return present
      ? { component, disposition: "PRODUCED", output_path: path }
      : { component, disposition: "NONE_FOUND", reason: `FIXTURE: no ${path.replace(/_/g, " ")} was identified after the cross-asset test.` };
  });
}

// Weekly Recap and F1-F6 overlap on purpose: collection may run concurrently
// (run protocol section 4). Every later phase is strictly sequential.
function buildPhases(spec) {
  const at = (hhmm) => `${spec.day}T${hhmm}:00Z`;
  const done = (span, artifact) => ({ status: "COMPLETE", started_at: at(span[0]), completed_at: at(span[1]), artifact });
  const artifacts = { weekly_recap: "collection/weekly_recap.md", F1: "collection/F1_fed_rate_pricing.md", F2: "collection/F2_rates_real_yields.md", F3: "collection/F3_usd_liquidity.md", F4: "collection/F4_macro_fiscal_credit.md", F5: "collection/F5_flows_positioning.md", F6: "collection/F6_structural.md" };
  const phases = { initialization: done(spec.init, "runs/RUN_STATE.md") };
  for (const id of COLLECTION_PHASES) {
    phases[id] = spec.kind === "INTERMEDIATE" && id === "weekly_recap"
      ? { status: "NOT_APPLICABLE", not_applicable_reason: "FIXTURE: the Weekly Recap is not rerun during an intermediate recap." }
      : done(spec.collect[id], artifacts[id]);
  }
  phases.collection_coverage_audit = done(spec.audit, "reasoning/collection_audit.md");
  phases.reasoning = done(spec.reasoning, "reasoning/reasoning_state.md");
  phases.asymmetry_gate = done(spec.gate, "reasoning/asymmetry_gate.md");
  phases.scenario_tree = done(spec.tree, "reasoning/scenario_tree.json");
  phases.presentation = done(spec.presentation, "final/presentation.json");
  phases.json_and_reports = done(spec.json, "final/market_state.json");
  return phases;
}

const SUNDAY_TIMES = {
  kind: "SUNDAY", day: "2026-09-20", init: ["12:00", "12:05"],
  collect: { weekly_recap: ["12:05", "12:45"], F1: ["12:10", "12:40"], F2: ["12:10", "12:50"], F3: ["12:10", "12:45"], F4: ["12:10", "13:00"], F5: ["12:10", "13:20"], F6: ["12:10", "13:10"] },
  audit: ["13:30", "13:45"], reasoning: ["13:45", "14:45"], gate: ["14:45", "15:15"], tree: ["15:15", "15:45"], presentation: ["15:45", "17:15"], json: ["17:15", "17:55"],
};
const INTERMEDIATE_TIMES = {
  kind: "INTERMEDIATE", day: "2026-09-23", init: ["14:00", "14:10"],
  collect: { F1: ["14:15", "15:00"], F2: ["14:15", "15:10"], F3: ["14:15", "15:05"], F4: ["14:15", "14:30"], F5: ["14:15", "16:00"], F6: ["14:15", "14:45"] },
  audit: ["17:00", "17:10"], reasoning: ["17:10", "18:10"], gate: ["18:10", "18:40"], tree: ["18:40", "19:10"], presentation: ["19:10", "20:30"], json: ["20:30", "20:55"],
};

const coverageAudit = (kind) => ({
  families_reviewed: kind === "SUNDAY" ? [...COLLECTION_PHASES] : COLLECTION_PHASES.slice(1),
  unresolved_required_questions: [],
  outcome: "ALL_REQUIRED_QUESTIONS_ADDRESSED",
});

function withSundayAudit(doc) {
  enrichForProcedure(doc);
  doc.procedural_audit = {
    version: 1, run_kind: "SUNDAY", phases: buildPhases(SUNDAY_TIMES),
    collection: sundayCollection(doc), collection_coverage_audit: coverageAudit("SUNDAY"),
    reasoning_components: reasoningComponents(doc), procedural_gaps: [],
    sunday: {
      completed_week: { reviewed_week_start: doc.presentation.scope.reviewed_week_start, reviewed_week_end: doc.presentation.scope.reviewed_week_end, analysis_of_completed_week_finished: true },
      benchmark: { instrument: "FIXTURE: COMEX Gold futures settlement series", contract: "FIXTURE: one December contract across the window", roll_in_window: false },
      cutoff: { evidence_cutoff_end: doc.meta.evidence_cutoff_end, sunday_night_trading_excluded: true },
    },
  };
  return doc;
}

function withIntermediateAudit(doc) {
  enrichForProcedure(doc);
  const parent = doc.meta.parent_run_id;
  const day = INTERMEDIATE_TIMES.day;
  const scan = EXOGENOUS_CATEGORIES.map((category) => (category === "FUNDING_COLLATERAL_STRESS"
    ? { category, outcome: "UNKNOWN", limitation: "FIXTURE: no direct funding observation is published for this window." }
    : { category, outcome: "NOTHING_MATERIAL_FOUND" }));
  doc.procedural_audit = {
    version: 1, run_kind: "INTERMEDIATE", phases: buildPhases(INTERMEDIATE_TIMES),
    collection: intermediateCollection(doc), collection_coverage_audit: coverageAudit("INTERMEDIATE"),
    reasoning_components: reasoningComponents(doc), procedural_gaps: [],
    intermediate: {
      intake: {
        state_candidates: [{ run_id: parent, run_type: "SUNDAY", evidence_cutoff_end: doc.meta.evidence_cutoff_start, validated: true }],
        selected_parent_run_id: parent,
        lineage_chain: [parent],
        consumed_handoff: {
          handoff_id: doc.consumed_handoff_id, handoff_version: doc.handoff_version, content_sha256: doc.handoff_content_hash, created_by_run_id: parent,
          scenario_refs: ["S1"], read_at: `${day}T14:02:00Z`, validated_at: `${day}T14:06:00Z`,
        },
        idempotence: { prior_consumers: [], outcome: "FIRST_CONSUMPTION" },
      },
      evidence_roles: doc.evidence.map((e) => (e.id === "e3"
        ? { evidence_ref: e.id, role: "BASELINE", baseline_label: "FIXTURE: structural backdrop inherited from the parent state, not re-observed in this window" }
        : { evidence_ref: e.id, role: "NEW_POST_CUTOFF" })),
      weekly_history: { inherited_from_run_id: parent, treatment: "INHERITED_UNCHANGED", inherited_weekly_timeline_sha256: canonicalSha256(doc.weekly_timeline) },
      inherited_scenarios: [{ scenario_ref: "S1", tested: true }],
      exogenous_scan: { performed: true, completed_at: `${day}T16:30:00Z`, categories: scan, scenario_structure_decision: { decision: "KEPT" } },
    },
  };
  return doc;
}

// The completion record seals validation, Drive readback and handoff writing,
// which cannot live inside the immutable market-state JSON.
function completionRecord(state, handoff, day, times) {
  const meta = state.meta;
  const at = (hhmm) => `${day}T${hhmm}:00Z`;
  // Upload happens inside the Drive readback phase, one minute before each readback,
  // and only after the local validation completed.
  const oneMinuteBefore = (hhmm) => { const [h, m] = hhmm.split(":").map(Number); return `${String(h).padStart(2, "0")}:${String(m - 1).padStart(2, "0")}`; };
  const file = (role, name, hhmm) => ({ role, name, content_sha256: role === "MARKET_STATE_JSON" ? canonicalSha256(state) : canonicalSha256(`FIXTURE ${role} of ${meta.run_id}`), uploaded_at: at(oneMinuteBefore(hhmm)), readback_at: at(hhmm), readback_verified: true });
  const done = (span, artifact) => ({ status: "COMPLETE", started_at: at(span[0]), completed_at: at(span[1]), artifact });
  return {
    document_type: "GOLD_RUN_COMPLETION_RECORD", frontend_eligible: false, storage_plane: "CONTROL", version: 1,
    run_id: meta.run_id, run_type: meta.run_type, parent_run_id: meta.parent_run_id, origin_sunday_run_id: meta.origin_sunday_run_id,
    market_state: {
      run_id: meta.run_id, content_sha256: canonicalSha256(state),
      published_files: [
        file("MARKET_STATE_JSON", "final/market_state.json", times.readback[0]), file("HUMAN_REPORT", "final/human_report.md", times.readback[1]),
        file("VALIDATION_REPORT", "final/validation_report.md", times.readback[2]), file("RUN_REPORT", "runs/RUN_STATE.md", times.readback[3]),
      ],
    },
    phases: {
      market_state_validation: done(times.validation, "final/validation_report.md"),
      drive_readback: done(times.driveReadback, "final/readback_log.md"),
      handoff_generation: done(times.handoffWrite, "handoff/NEXT_GOLD_RECAP.json"),
      handoff_validation: done(times.handoffValidation, "handoff/handoff_validation.md"),
    },
    handoff: {
      handoff_id: handoff.handoff_id, handoff_version: handoff.handoff_version, created_by_run_id: handoff.created_by_run_id,
      origin_sunday_run_id: handoff.origin_sunday_run_id, parent_state_run_id: handoff.parent_state_run_id,
      write_mode: "UPDATED_IN_PLACE", previous_handoff_id: times.previousHandoffId, active_handoff_count_after: 1,
      pre_write_readback_at: at(times.preWrite), post_write_readback_at: at(times.postWrite), post_write_parse_valid: true,
    },
    run_state: "COMPLETE", procedural_gaps: [],
  };
}

// The Sunday handoff itself is a control-plane file that is replaced every run;
// only the identity the completion record seals is needed here.
const sundayHandoffIdentity = (state) => ({
  handoff_id: `fixture-handoff-${state.meta.run_id}`, handoff_version: 1, created_by_run_id: state.meta.run_id,
  origin_sunday_run_id: state.meta.run_id, parent_state_run_id: state.meta.run_id,
});
const SUNDAY_SEAL_TIMES = { validation: ["18:00", "18:05"], driveReadback: ["18:05", "18:15"], readback: ["18:07", "18:09", "18:11", "18:13"], handoffWrite: ["18:15", "18:30"], preWrite: "18:16", postWrite: "18:28", handoffValidation: ["18:30", "18:35"], previousHandoffId: "fixture-previous-week-handoff" };
const INTERMEDIATE_SEAL_TIMES = { validation: ["21:00", "21:05"], driveReadback: ["21:05", "21:15"], readback: ["21:07", "21:09", "21:11", "21:13"], handoffWrite: ["21:15", "21:30"], preWrite: "21:16", postWrite: "21:28", handoffValidation: ["21:30", "21:35"], previousHandoffId: "handoff-2026-09-20-01" };

// ---------------------------------------------------------------------------
// Emit
// ---------------------------------------------------------------------------

const stateA = withSundayAudit(fixtureStrongBullish());
const stateF = withIntermediateAudit(fixtureIntermediateTransition());
const handoffG = fixtureHandoffCheckpoints();

const outputs = [
  ["FIXTURE_a_strong_bullish.json", stateA],
  ["FIXTURE_bullish_macro_trap.json", withSundayAudit(fixtureBullishMacroTrap())],
  ["FIXTURE_c_bearish_vulnerability_waiting.json", withSundayAudit(fixtureBearishVulnerabilityWaiting())],
  ["FIXTURE_d_options_gamma_unknown.json", withIntermediateAudit(fixtureOptionsGammaUnknown())],
  ["FIXTURE_e_event_vol_premium.json", withSundayAudit(fixtureEventVolPremium())],
  ["FIXTURE_f_intermediate_transition.json", stateF],
  ["FIXTURE_g_handoff_asymmetry_checkpoints.json", handoffG],
  ["FIXTURE_a_run_completion_record.json", completionRecord(stateA, sundayHandoffIdentity(stateA), "2026-09-20", SUNDAY_SEAL_TIMES)],
  ["FIXTURE_f_run_completion_record.json", completionRecord(stateF, handoffG, "2026-09-23", INTERMEDIATE_SEAL_TIMES)],
];

for (const [name, doc] of outputs) {
  writeFixture(name, doc);
  console.log(`wrote tests/fixtures/${name}`);
}
