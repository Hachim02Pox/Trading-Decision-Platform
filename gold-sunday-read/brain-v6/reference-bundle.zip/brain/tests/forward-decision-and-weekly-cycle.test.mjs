import assert from "node:assert/strict";
import test from "node:test";
import { FAMILY_QUESTIONS, forwardDecisionProblems, familyReadoutProblems } from "../tools/family-readout.mjs";
import { weeklyCycleProblems, weeklyHandoffProblems } from "../tools/weekly-cycle.mjs";

const loc = (fr, en = "An independent sourced explanation of the next condition.") => ({ fr, en, evidence_refs: ["E-REAL"] });
function state(kind = "SUNDAY", generated_at = "2026-09-27T16:00:00Z") {
  const origin = "sunday-27";
  const x = {
    meta: { run_type: kind, data_mode: "REAL", run_id: kind === "SUNDAY" ? origin : "inter-1",
      parent_run_id: kind === "SUNDAY" ? null : origin, origin_sunday_run_id: origin,
      generated_at, evidence_cutoff_end: generated_at },
    evidence: [{ id: "E-REAL" }],
    weekly_cycle: { origin_run_id: origin, intermediate_index: kind === "SUNDAY" ? 0 : 1 },
    direction_state: { macro_direction: "MIXED", directional_asymmetry: "BALANCED", positioning_asymmetry: "UNKNOWN", edge: "NO_EDGE" },
    opportunity_quality: { value: "WEAK" }, execution_readiness: { value: "NOT_READY" },
    global_synthesis: { priced_in: loc("Une partie du choc est déjà intégrée; seule la prochaine surprise compte.") },
  };
  x.forward_verdict_cases = Object.fromEntries([
    ...Object.entries(x.direction_state), ["opportunity_quality", x.opportunity_quality.value], ["execution_readiness", x.execution_readiness.value],
  ].map(([key, value]) => [key, { value, ...Object.fromEntries([
    "current_case", "mechanism", "opposing_case", "why_preferred", "already_priced", "next_test", "invalidation", "practical_consequence",
  ].map(field => [field, loc("La conclusion reste conditionnelle devant des preuves opposées et datées.")])) }]));
  return x;
}

test("new verdict cases require six sourced FR/EN cases addressing the opposite hypothesis", () => {
  const x = state();
  assert.deepEqual(forwardDecisionProblems(x), []);
  x.forward_verdict_cases.macro_direction.opposing_case.fr = "";
  assert.match(forwardDecisionProblems(x).join(" "), /opposing_case.fr/);
  x.forward_verdict_cases.macro_direction.opposing_case = loc("Les taux plus faibles constituent un argument contraire sérieux.");
  x.forward_verdict_cases.positioning_asymmetry.value = "BEARISH";
  assert.match(forwardDecisionProblems(x).join(" "), /must match the analytical verdict/);
  assert.deepEqual(forwardDecisionProblems(state("SUNDAY", "2026-09-25T18:00:00Z")), []);
});

test("a new Sunday rejects generic missing-data templates without rejecting archived outputs", () => {
  const x = state();
  const generic = "La mesure demandée est absente, incomplète ou non comparable à la coupure; cette réponse reste conditionnelle.";
  x.family_readouts = Object.entries(FAMILY_QUESTIONS).map(([family_id, ids]) => ({
    family_id, title: { fr: "Famille de mesures et de recherches.", en: "Family of sourced measurements." },
    questions: ids.map(question_id => ({ question_id,
      question: { fr: "Quelle mesure est actuellement publiée ?", en: "Which observation is published today?" },
      answer: { fr: "Cette observation précise reste indisponible à cette coupure.", en: "This particular observation is not available at cutoff." },
      status: "UNKNOWN", evidence_refs: [], unknown_reason: {
        reason_kind: "SOURCE_NOT_RETRIEVED",
        explanation: { fr: generic, en: "The requested measurement is absent, incomplete or non-comparable at cutoff." },
        checked: { fr: "Le producteur précis a été contrôlé à cette date.", en: "The named publisher was checked at cutoff." },
        next_action: { fr: "Récupérer la série du même contrat avec sa date.", en: "Recover the exact contract series with its date." },
      },
    })),
    family_reasoning: Object.fromEntries(["established", "mechanism", "counterevidence", "limits", "forward_test"].map(key => [key, loc("Cette famille contient une observation datée et une limite explicite.")])),
  }));
  for (const key of ["causal_chain", "alternatives", "contradictions", "forward_conditions", "invalidation", "unknowns", "edge_reasoning"])
    x.global_synthesis[key] = loc("Le risque dépend de la prochaine surprise et de la réaction du marché.");
  x.weekly_bridge = { prior_run_id: null, ...Object.fromEntries(["comparison_limit", "differences", "surviving_conclusions", "resolved_expectations", "failed_expectations"].map(key => [key, loc("Aucune comparaison vérifiée ne change cette lecture pour le moment.")])) };
  assert.match(familyReadoutProblems(x).join(" "), /generic recovery boilerplate/);
});

test("a missing measurement requires its own dated source attempt and obstacle", () => {
  const x = state("INTERMEDIATE", "2026-09-29T18:00:00Z");
  x.family_readouts = [{ family_id: "F3", questions: [{ question_id: "F3_USDJPY", status: "UNKNOWN", unknown_reason: {
    reason_kind: "SOURCE_NOT_RETRIEVED",
    explanation: { fr: "Le prix USDJPY du jour n'a pas été vérifié.", en: "Today's USDJPY quote has not been verified." },
    checked: { fr: "La page du fournisseur a été consultée.", en: "The publisher page was consulted." },
    next_action: { fr: "Chercher le taux de clôture horodaté.", en: "Find the timestamped closing price." },
  } }] }];
  x.procedural_audit = { collection: { F3: { questions: [{ question_id: "F3_USDJPY", source_recovery: { attempts: [{ source: "provider", result: "UNAVAILABLE" }] } }] } } };
  assert.match(familyReadoutProblems(x).join(" "), /specific obstacle required/);
  x.procedural_audit.collection.F3.questions[0].source_recovery.attempts[0] = {
    source: "provider", result: "UNAVAILABLE", url_or_provider: "https://example.invalid/usdjpy",
    attempted_at: "2026-09-29T17:00:00Z", requested_observation: "USDJPY 2026-09-29 close",
    result_detail: "The provider had no dated close at the actual observation cutoff.",
  };
  assert.doesNotMatch(familyReadoutProblems(x).join(" "), /specific obstacle required/);
});

test("cutoff rejects Friday intermediates and third intermediates, but allows two before Friday", () => {
  const parent = state();
  const first = state("INTERMEDIATE", "2026-09-29T18:00:00Z");
  assert.deepEqual(weeklyCycleProblems(first, parent), []);
  const second = structuredClone(first);
  second.meta.run_id = "inter-2";
  second.meta.parent_run_id = first.meta.run_id;
  second.meta.generated_at = second.meta.evidence_cutoff_end = "2026-10-01T18:00:00Z";
  second.weekly_cycle.intermediate_index = 2;
  assert.deepEqual(weeklyCycleProblems(second, first), []);
  second.weekly_cycle.intermediate_index = 3;
  assert.match(weeklyCycleProblems(second, first).join(" "), /index must be 1 or 2/);
  second.weekly_cycle.intermediate_index = 2;
  second.meta.evidence_cutoff_end = "2026-10-02T04:00:00Z"; // Friday midnight ET
  assert.match(weeklyCycleProblems(second, first).join(" "), /before Friday/);
});

test("handoff closes after second intermediate and may never schedule a Friday recap", () => {
  const x = state("INTERMEDIATE", "2026-10-01T18:00:00Z");
  x.weekly_cycle.intermediate_index = 2;
  const handoff = { weekly_cycle: structuredClone(x.weekly_cycle), handoff_status: "CLOSED", next_execution: null };
  assert.deepEqual(weeklyHandoffProblems(handoff, x), []);
  handoff.handoff_status = "ACTIVE";
  handoff.next_execution = { requested_at: "2026-10-02T14:00:00Z" };
  assert.match(weeklyHandoffProblems(handoff, x).join(" "), /Friday/);
});
