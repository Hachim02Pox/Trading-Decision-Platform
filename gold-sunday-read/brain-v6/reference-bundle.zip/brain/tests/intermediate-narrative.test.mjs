import assert from "node:assert/strict";
import test from "node:test";
import { intermediateNarrativeProblems } from "../tools/intermediate-narrative.mjs";

const copy = (fr = "Le dollar s'est renforcé depuis le parent.", en = "The dollar strengthened since the parent.") =>
  ({ fr, en, evidence_refs: ["E-NEW"] });
const parent = {
  meta: { run_id: "sunday" },
  direction_state: { macro_direction: "MIXED", directional_asymmetry: "BALANCED", positioning_asymmetry: "UNKNOWN", edge: "NO_EDGE" },
  opportunity_quality: { value: "WEAK" }, execution_readiness: { value: "WAITING_FOR_CATALYST" },
  evidence: [{ id: "E-OLD" }],
};
function intermediate() {
  const summary = Object.fromEntries(["observed_since_parent", "what_changed", "what_remains_true", "unknowns", "next_watch", "decisive_limit"].map((key) => [key, copy()]));
  summary.parent_run_id = "sunday";
  summary.macro_reading = Object.fromEntries(["observed", "causal_assessment", "forward_conditions", "invalidation"].map((key) => [key, copy()]));
  summary.unknown_reasons = [{
    topic: "COT_POST_FED",
    label: { fr: "Positions publiées après la Fed", en: "Positions published after the Fed" },
    reason_kind: "AWAITING_PUBLICATION",
    explanation: { fr: "Le rapport officiel couvrant l'après-Fed n'est pas encore publié.", en: "The official report covering the post-Fed period has not yet been published." },
    checked: { fr: "Le dernier COT date d'avant la décision de la Fed.", en: "The latest COT predates the Fed decision." },
    next_action: { fr: "Lire la publication officielle et comparer la même population.", en: "Read the official release and compare the same population." },
    expected_at: "2026-09-25T19:30:00Z",
    evidence_refs: ["E-NEW"],
  }];
  summary.judgment_changes = ["macro_direction", "execution_readiness"].map((judgment) => ({
    judgment, previous: copy(), current: copy(), reason: copy(), practical_consequence: copy(),
  }));
  return {
    meta: { run_id: "next", parent_run_id: "sunday", run_type: "INTERMEDIATE", data_mode: "REAL", generated_at: "2026-09-25T18:00:00Z", evidence_cutoff_end: "2026-09-25T18:00:00Z" },
    direction_state: { ...parent.direction_state, macro_direction: "BEARISH" },
    opportunity_quality: { value: "WEAK" }, execution_readiness: { value: "CATALYST_PRESENT_BUT_UNCONFIRMED" },
    evidence: [{ id: "E-NEW" }], intermediate_summary: summary,
  };
}

test("new REAL intermediate has two localized, referenced narratives and explained verdict changes", () => {
  assert.deepEqual(intermediateNarrativeProblems(intermediate(), parent), []);
});
test("historical REAL September 24 state remains valid without a narrative summary", () => {
  const doc = intermediate();
  doc.meta.generated_at = "2026-09-24T15:26:25Z";
  delete doc.intermediate_summary;
  assert.deepEqual(intermediateNarrativeProblems(doc, parent), []);
});
test("new REAL intermediate cannot omit its summary or mismatch its parent", () => {
  const doc = intermediate();
  delete doc.intermediate_summary;
  assert.match(intermediateNarrativeProblems(doc, parent).join(" "), /requires intermediate_summary/);
  doc.intermediate_summary = intermediate().intermediate_summary;
  doc.intermediate_summary.parent_run_id = "other";
  assert.match(intermediateNarrativeProblems(doc, parent).join(" "), /parent_run_id/);
});
test("missing language, raw codes and dangling evidence references fail", () => {
  const doc = intermediate();
  doc.intermediate_summary.what_changed.fr = "Explication localisée non publiée.";
  doc.intermediate_summary.unknowns.en = "";
  doc.intermediate_summary.next_watch.evidence_refs = ["E-NOT-FOUND"];
  const errors = intermediateNarrativeProblems(doc, parent).join(" ");
  assert.match(errors, /placeholder/);
  assert.match(errors, /unknowns.en/);
  assert.match(errors, /E-NOT-FOUND/);
});
test("changed judgments must have a matching localized explanation", () => {
  const doc = intermediate();
  doc.intermediate_summary.judgment_changes = [];
  assert.match(intermediateNarrativeProblems(doc, parent).join(" "), /changed judgment macro_direction/);
});

test("new intermediate cannot reuse a parent's stale judgment mechanism", () => {
  const doc = intermediate();
  const oldCopy = "Two branches remain balanced despite the new information.";
  parent.presentation = { en: { verdict_explanations: { macro_direction: { mechanism: oldCopy } } } };
  doc.presentation = { en: { verdict_explanations: { macro_direction: { mechanism: oldCopy } },
    direction_state: { macro_direction: { value: "BEARISH" } } } };
  assert.match(intermediateNarrativeProblems(doc, parent).join(" "), /reused its parent's en mechanism/);
  doc.presentation.en.direction_state.macro_direction.value = "MIXED";
  assert.match(intermediateNarrativeProblems(doc, parent).join(" "), /disagrees with current value/);
});

test("new output identifies each material missing input and why it is missing", () => {
  const doc = intermediate();
  doc.positioning_evidence = {
    price_open_interest: { oi_direction: "UNKNOWN" },
    options_iv: { iv_direction: "UNKNOWN", call_put_skew_direction: "UNKNOWN" },
    gamma: { status: "UNKNOWN" },
  };
  const failures = intermediateNarrativeProblems(doc, parent).join(" ");
  assert.match(failures, /OPEN_INTEREST_CURRENT/);
  assert.match(failures, /OPTIONS_IV/);
  assert.match(failures, /OPTIONS_SKEW/);
  assert.match(failures, /DEALER_GAMMA/);
  for (const topic of ["OPEN_INTEREST_CURRENT", "OPTIONS_IV", "OPTIONS_SKEW", "DEALER_GAMMA"]) {
    doc.intermediate_summary.unknown_reasons.push({
      topic, label: { fr: "Donnée actuelle indisponible", en: "Current data unavailable" },
      reason_kind: "CAUSE_UNDETERMINED",
      explanation: { fr: "La cause précise de l'absence n'est pas établie.", en: "The exact cause of the absence is not established." },
      checked: { fr: "La série comparable n'a pas été vérifiée lors de cette recherche.", en: "A comparable series was not verified during this research." },
      next_action: { fr: "Rechercher la source et vérifier la comparabilité.", en: "Search the source and verify comparability." },
      evidence_refs: [],
    });
  }
  assert.deepEqual(intermediateNarrativeProblems(doc, parent), []);
});
test("a missing publication date, unsupported date, or missing causal assessment fails", () => {
  const doc = intermediate();
  delete doc.intermediate_summary.unknown_reasons[0].expected_at;
  assert.match(intermediateNarrativeProblems(doc, parent).join(" "), /expected_at is required/);
  doc.intermediate_summary.unknown_reasons[0].expected_at = "2026-09-25T19:30:00Z";
  doc.intermediate_summary.unknown_reasons[0].evidence_refs = ["MISSING"];
  delete doc.intermediate_summary.macro_reading.causal_assessment;
  const errors = intermediateNarrativeProblems(doc, parent).join(" ");
  assert.match(errors, /unknown evidence reference MISSING/);
  assert.match(errors, /macro_reading.causal_assessment/);
});
