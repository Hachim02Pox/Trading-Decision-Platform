import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { V4_CONDITIONAL_FIELDS, V4_PRICED_IN_FIELDS, V4_VERDICT_FIELDS, V4_VERDICTS } from "../tools/presentation-coverage.mjs";

const read = (file) => readFileSync(file, "utf8");
const presentation = read("specs/legacy/GOLD_PRESENTATION_V3_SPEC.md");
const output = read("specs/legacy/GOLD_SUNDAY_READ_OUTPUT_SPEC.md");
const schema = read("schema/sunday_read.schema.json");

for (const field of [...V4_VERDICTS, ...V4_VERDICT_FIELDS, ...V4_CONDITIONAL_FIELDS, ...V4_PRICED_IN_FIELDS]) {
  assert.ok(presentation.includes(`\`${field}\``), `presentation spec must document ${field}`);
  assert.ok(schema.includes(`"${field}"`), `schema must type ${field}`);
}
for (const marker of ["presentation.version", "already_priced_analysis", "annotations"] ) {
  assert.ok(output.includes(marker), `output spec must document ${marker}`);
}
console.log("V4 documentation consistency: passed");
