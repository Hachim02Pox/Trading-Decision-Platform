import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { presentationCoverageProblems } from "../tools/presentation-coverage.mjs";

const base = JSON.parse(readFileSync(new URL("./fixtures/FIXTURE_sunday_v3_state.json", import.meta.url)));
const removeGlossaryRefs = (value) => {
  if (Array.isArray(value)) value.forEach(removeGlossaryRefs);
  else if (value && typeof value === "object") for (const key of Object.keys(value)) key === "glossary_refs" ? delete value[key] : removeGlossaryRefs(value[key]);
};
const production = () => {
  const doc = structuredClone({ ...base, meta: { ...base.meta, data_mode: "REAL" } });
  doc.presentation.version = 4;
  for (const locale of ["fr", "en"]) {
    const p = doc.presentation[locale];
    p.market_story.chronology = [{ date: "2026-09-18", observed: "Observed move", reported_attribution: "Reported attribution", status: "OBSERVED" }];
    p.market_story.causal_assessment = { observed: "Observed", reported: "Reported", alternatives: ["Alternative"], conclusion_limit: "Unknown" };
    for (const horizon of ["tactical", "medium", "structural"]) Object.assign(p.horizons[horizon], { state: "State", drivers: ["Driver"], transmission: "Transmission", supporting_evidence: ["Evidence"], contradictions: ["Contradiction"], counter_scenario: "Counter", confirmation: "Confirm", invalidation: "Invalidate", week_ahead_implication: "Implication" });
    p.verdict_explanations = Object.fromEntries(["macro_direction", "directional_asymmetry", "positioning_asymmetry", "edge", "opportunity_quality", "execution_readiness"].map((key) => [key, Object.fromEntries(["verdict", "observations", "mechanism", "supporting_evidence", "contrary_evidence", "unknowns", "practical_meaning", "would_change", "insufficient_alone"].map((field) => [field, field]))]));
    p.conditional_verdicts = ["BULLISH", "BEARISH", "NO_EDGE"].map((expected_edge) => ({
      conditions: "Condition", transmission: "Transmission", independent_confirmations: ["Confirmation"], positioning_confirmation: "Positioning", expected_direction: expected_edge, expected_directional_asymmetry: expected_edge, expected_positioning_asymmetry: "BALANCED", expected_quality: "MEDIUM", expected_readiness: "NOT_READY", expected_edge, invalidation_or_expiry: "Expiry", unknowns: ["Unknown"],
    }));
    p.priced_in.already_priced = [];
    p.annotations = [];
    removeGlossaryRefs(p);
  }
  return doc;
};
const mustFail = (doc, text) => assert.ok(presentationCoverageProblems(doc).some((problem) => problem.includes(text)), `expected ${text}`);

// A three-node, two-edge story passes when every analytical element is localized.
{ const doc = production(); const node = { ...doc.scenario_tree.nodes[0], id: "N-THREE" }; doc.scenario_tree.nodes.push(node); doc.scenario_tree.edges.push({ id: "L2", from: "N-FED", to: "N-THREE", label: "transmits", status: "WATCH" }); for (const locale of ["fr", "en"]) { doc.presentation[locale].scenario_tree_v3.nodes.push({ ...doc.presentation[locale].scenario_tree_v3.nodes[0], node_id: "N-THREE" }); doc.presentation[locale].scenario_tree_v3.edges.push({ ...doc.presentation[locale].scenario_tree_v3.edges[0], edge_id: "L2", from_node_id: "N-FED", to_node_id: "N-THREE", display_explanation: locale === "fr" ? "La hausse des taux modifie la demande d'or." : "Higher rates alter gold demand." }); } assert.deepEqual(presentationCoverageProblems(doc), []); }
{ const doc = production(); doc.presentation.fr.scenario_tree_v3.nodes.pop(); mustFail(doc, "material analytical node"); }
{ const doc = production(); delete doc.presentation.fr.horizons; mustFail(doc, "missing material horizon"); }
{ const doc = production(); doc.presentation.fr.market_story.current_setup = "The market remains caught between rates and the dollar."; mustFail(doc, "English final-copy fallback"); }
{ const doc = production(); for (const locale of ["fr", "en"]) { const duplicate = { ...doc.presentation[locale].scenario_tree_v3.edges[0], edge_id: "L2", from_node_id: "N-FED", to_node_id: "N-ROOT" }; doc.presentation[locale].scenario_tree_v3.edges.push(duplicate); doc.scenario_tree.edges.push({ id: "L2", from: "N-FED", to: "N-ROOT", label: "feeds", status: "WATCH" }); } mustFail(doc, "generic causal explanation"); }
{ const doc = production(); doc.direction_state.directional_asymmetry = "UNKNOWN"; assert.deepEqual(presentationCoverageProblems(doc), []); }
{ const doc = production(); delete doc.presentation.fr.verdict_explanations.edge.mechanism; mustFail(doc, "verdict edge lacks mechanism"); }
{ const doc = production(); doc.presentation.en.market_story.glossary_refs = ["REAL_YIELD"]; mustFail(doc, "referenced glossary REAL_YIELD is never materialized"); }
{ const doc = production(); doc.glossary.push({ id: "SKEW", fr: { term: "skew" }, en: { term: "skew" } }); doc.presentation.en.market_story.current_setup = "skew and OI"; doc.presentation.en.annotations = [{ id: "a1", locale: "en", path: "market_story.current_setup", anchor: "OI", occurrence: 1, glossary_id: "SKEW" }]; doc.presentation.en.market_story.glossary_refs = ["SKEW"]; mustFail(doc, "annotation anchor does not match its localized glossary entry"); }
{ const doc = production(); doc.presentation.en.market_story.current_setup = "real yield"; doc.presentation.en.annotations = [{ id: "a1", locale: "en", path: "market_story.current_setup", anchor: "real yield", occurrence: 2, glossary_id: "REAL_YIELD" }]; mustFail(doc, "annotation occurrence is invalid"); }
{ const doc = production(); doc.presentation.en.priced_in.already_priced = ["A material item"]; mustFail(doc, "priced-in items lack structured explanation"); }
{ const doc = production(); doc.presentation.en.conditional_verdicts.pop(); mustFail(doc, "requires bullish, bearish and no-edge conditional cases"); }
{ const doc = production(); doc.presentation.en.priced_in.already_priced = ["A", "B"]; doc.presentation.en.priced_in.already_priced_analysis = [{ prior_expectation: "A", observed_outcome: "A", verified_reaction: "A", now_priced: "A", still_repriceable: "A", evidence_used: ["A"], unknowns_or_limits: "A", as_of: "A" }]; mustFail(doc, "align one-to-one by array order"); }
{ const doc = production(); doc.presentation.en.annotations = [{ locale: "en", path: "market_story.current_setup", anchor: "", occurrence: 1, glossary_id: "REAL_YIELD" }]; mustFail(doc, "annotation id is required"); }
{ const doc = production(); for (const locale of ["fr", "en"]) for (const horizon of ["tactical", "medium", "structural"]) for (const field of ["state", "drivers", "transmission", "supporting_evidence", "contradictions", "counter_scenario", "confirmation", "invalidation", "week_ahead_implication"]) assert.notEqual(doc.presentation[locale].horizons[horizon][field], undefined, `${locale}.${horizon}.${field} must remain present`); }
console.log("presentation coverage tests: 14 passed");
