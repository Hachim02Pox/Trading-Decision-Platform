# Gold Market Story Brain

Le rendu éditorial validé le 27 septembre 2026 devient le **format officiel v6**
pour les nouveaux Sunday Reads et récaps intermédiaires. Il n’est plus nécessaire
de demander un mode expérimental. La version du contrat JSON est `format_version: "6.0"`.
Les archives restent immuables. À la demande explicite d’Hachim, le brouillon
réel du 27 a été promu dans Output le 28, avec copies originales préservées,
cutoff inchangé et procédure PARTIAL explicitement documentée ; voir
`specs/GOLD_DRIVE_MIGRATION_2026-09-28.md`.

Ce dépôt contient les instructions, schémas, références et contrôles. Le backend,
l’API et le frontend du terminal vivent dans une autre application : ce commit
ne prétend pas les déployer. Leur intégration doit accepter explicitement v6,
préserver les archives et vérifier le rendu avant d’activer leur ingestion v6.
Aucun état de marché réel ni handoff Drive n’est publié par une modification du dépôt.

Identifiants opérationnels : Output `1otzXd6sEBAaMn_dh-DmMxoiszs4_7aVm`, Control
`1cfLw7eK4pnw33P_K4PIq6IgWgXgua8Ot`, handoff stable **actuel**
`1vjvIgPV7umsbaCiuUdyxu6R980zg_dsU`, reçus
`1T881GeH72cVhoz3R0xi50KpfaBVYzt_Y`. L’ancien ID
`1kz-OvJ-8lYlV1Z6zOo5Q8wsIWq0Qm1uM` est retiré/annulé, pas un fallback.
Le prompt d’intégration du terminal est `docs/CODEX_PLATFORM_V6_INTEGRATION.md`.

## Entrée unique d’un Work

Lire intégralement, dans cet ordre, les versions courantes :

1. Ce README.
2. `specs/GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md`.
3. `specs/GOLD_MACRO_REASONING_MANUAL_SUNDAY.md`.
4. `specs/GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md`.
5. `specs/GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md`.
6. `specs/GOLD_SUNDAY_READ_OUTPUT_SPEC.md` et `schema/gold_editorial.schema.json`.
7. `specs/GOLD_PRESENTATION_V3_SPEC.md` (le chemin historique porte désormais le contrat v6).
8. `specs/GOLD_SUNDAY_READ_RUN_PROTOCOL.md`.
9. `specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md`.
10. `specs/GOLD_CONTINUOUS_RECAP_PROTOCOL.md` et `specs/GOLD_NEXT_RECAP_HANDOFF_SPEC.md`.
11. Pour un intermédiaire, `specs/GOLD_INTERMEDIATE_NARRATIVE_CONTRACT.md`.

Consulter `GOLD_SUNDAY_READ_SOURCE_RECOVERY.md` lorsqu’une mesure requise résiste
aux recherches normales. Le prompt d’automatisation reste minimal : les règles
persistantes résident ici. Ne pas utiliser de fixture comme source de marché.

La collecte, ses 32 questions F1–F6 et le manuel d’interprétation restent inchangés.
Leur contenu scientifique gouverne la recherche et les mécanismes. Pour la forme
publiée et le périmètre demandé par Hachim, les présents contrats v6 remplacent les
anciens champs d’exécution/opportunité et leurs obligations d’affichage. La collection
ne devient pas un vote d’indicateurs. Un conflit de données ou de mécanismes doit
être résolu ou expliqué avant publication ; une lacune ne doit jamais être inventée.

## La recette officielle

Recueillir des preuves primaires datées jusqu’à un cutoff explicite de New York.
Répondre à toutes les questions, interpréter chaque famille puis l’ensemble selon
le manuel, et rechercher aussi articles, déclarations et moteurs exogènes qui
pourraient contredire ou compléter la lecture. Les observations de marché, leur
interprétation et les conditions futures restent distinctes.

Commencer le rapport par une **thèse future conditionnelle** : direction soutenue
ou indécision, horizon, mécanisme dominant, comportement des investisseurs,
meilleur scénario contraire, raison de la préférence, ce qui est déjà dans les
prix et les observations qui renforceraient, renverseraient ou suspendraient le biais.
Une baisse passée de l’or ne prévoit pas une autre baisse. Distinguer la direction,
l’asymétrie des réactions possibles et l’asymétrie de positionnement.

Expliquer les liens causaux en français ordinaire. Quand COT, ETF ou prix/OI
interviennent, préciser qui reste exposé, pourquoi cet acteur pourrait agir et
l’interprétation alternative. Une liquidation passée ne prouve pas de futures
ventes forcées. Ne pas exiger une contrainte effectivement observée pour discuter
une vulnérabilité plausible : distinguer clairement les degrés de preuve.
Ne pas compter Fed, taux et dollar comme trois confirmations indépendantes d’un
même moteur. Conserver les horizons tactique, moyen et structurel.

## Que puis-je envisager ?

| Instrument | Seul filtre fondamental applicable |
|---|---|
| GC/MGC futures | Biais macro clair, actuel et étayé dans le sens considéré. Aucune asymétrie de positionnement exigée. |
| CFD | Même biais macro, plus asymétrie de positionnement actuelle dans le même sens. |

Afficher long éligible, short éligible ou aucun sens, puis pourquoi, horizon,
contradiction principale et condition de bascule/réexamen. Une lecture périmée,
mixte ou matériellement contredite n’accorde pas une éligibilité actuelle.
L’asymétrie directionnelle reste expliquée mais ne devient pas un troisième filtre.

Ne pas juger l’entrée, les niveaux techniques, le stop, la taille, le payoff,
la présence d’un setup ni la préparation à l’exécution. Leur absence n’affaiblit
pas artificiellement un biais macro étayé. Les options par échéance, IV, skew et
GEX manuel sont une étape distincte à concevoir plus tard ; un signal options
fiable et matériel déjà obtenu reste une preuve à expliquer. Le bouton manuel
de vérification de thèse n’est pas implémenté par ce contrat.

Les six jugements officiels sont : direction macro, asymétrie directionnelle,
asymétrie de positionnement, solidité des preuves, portée fondamentale, conclusion
par instrument. Chaque jugement reçoit une explication distincte ; aucun simple
changement d’étiquette ne remplace le pourquoi et les conditions.

## Lecture et profondeur

La première vue donne la thèse et le panneau de décision. Les six jugements,
ce qui peut surprendre, les chemins haussier/baissier/indécis, puis les scénarios,
F1–F6, la chronologie et les termes expliqués sont accessibles progressivement.
Chaque nœud sélectionné explique preuves, chaîne causale, confirmation, horizon,
contradiction, invalidation et conséquence. Aucun nombre minimal de mots ou de
nœuds : couvrir les sujets pertinents sans remplissage ni répétitions.

Le rapport Markdown est l’aperçu fidèle de cette lecture. Le JSON contient les
mêmes explications ; `content_preview.markdown` est produit par
`tools/editorial.mjs`, avec une empreinte vérifiable. **Aucune URL, bibliographie,
référence brute ni identifiant technique ne s’affiche dans le récit du terminal.**
Les sources, dates, liens et essais de récupération restent dans le JSON d’audit
et la revue des preuves. Ne pas les supprimer des données pour nettoyer l’écran.
Le français est complet ; les aides anglaises sont facultatives et ne constituent
pas une traduction intégrale. Toute copie anglaise publiée doit rester fidèle.

Pour chaque observation manquante : mesure/instrument/date exacts, essais,
URLs et horaires dans l’audit, obstacle précis, conséquence et prochain moyen
de récupération. Distinguer non-publication, accès, comparabilité, méthode et
non-observabilité. Ne pas réciter une réserve générique après chaque conclusion.

## Continuité et livraison

Un intermédiaire a **la même structure, les mêmes 32 réponses, les mêmes jugements
et la même profondeur explicative**. Il actualise les familles au nouveau cutoff,
explique les changements depuis son parent immédiat et hérite de la chronologie
ancienne sans la refaire. « Pas de nouvelle publication » ne signifie pas
« thèse confirmée ». Le Sunday raisonne indépendamment avant de comparer la semaine
précédente. Dater séparément semaine observée, semaine préparée et contexte postérieur.

Au maximum deux intermédiaires, avant vendredi 00:00 America/New_York. La prochaine
heure est choisie pour un événement ou une condition économique et un délai de
confirmation expliqué, pas arbitrairement. Après le dernier point utile, handoff
CLOSED avec `next_execution: null`. La programmation des intermédiaires est conservée.

Chaque run validé crée quatre fichiers immuables dans **Gold Sunday Read Output** :
JSON complet, rapport Markdown, preuves/validation, note de run. Puis il actualise
le fichier stable **NEXT_GOLD_RECAP.json** dans **Gold Sunday Read Control**, et
écrit le reçu de fin de run dans Control. Ce handoff est donc bien un fichier
supplémentaire aux quatre livrables. Le run expérimental du 27 n’en avait pas créé
ni modifié : il était isolé de la production.

## Schémas et contrôles

- `schema/gold_editorial.schema.json` : contrat courant Sunday et intermédiaire.
- `schema/sunday_read.schema.json` : lecture/validation des archives antérieures.
- `schema/next_gold_recap.schema.json` : handoff ; `market_state_format_version: "6.0"` sélectionne la continuité v6.
- `schema/run_completion_record.schema.json` : reçu Control inchangé, jamais rendu.
- `tests/fixtures/FIXTURE_editorial_sunday.json` : référence éditoriale historique adaptée, explicitement FIXTURE.
- `tests/fixtures/FIXTURE_editorial_intermediate.json` : démonstration synthétique de l’évolution, pas un nouveau récap réel.

```sh
npm ci
npm test
npm run validate
# Avant livraison, aucune attestation future :
node tools/validate.mjs --preflight <state.json> <parent.json>
# Après livraison/readback/handoff, vérifier le bundle et les reçus :
node tools/validate.mjs <state.json> <handoff.json> <completion.json> <parent.json> <parent-completion.json>
```

Omettre les arguments parent pour un Sunday. Un parent fourni pour un intermédiaire
REAL doit lui-même avoir son reçu. `--preflight` ne certifie jamais la livraison.
Le validateur refuse le retour silencieux à l’ancien contrat pour les nouveaux
REAL depuis le 28 septembre 2026 à 13:08:35 New York. Les archives restent valides.
Les documents `specs/legacy/` conservent les contrats antérieurs, uniquement pour
comprendre les archives et leurs tests. Voir `specs/GOLD_V6_MIGRATION.md` pour la
correspondance des champs et la frontière d’intégration avec le terminal.
