# Audit de procédure — v6

L’audit établit ce qui a été tenté, obtenu, écrit et relu. Il ne prouve pas
l’exactitude économique, la capacité prédictive ni une réflexion privée.
Documenter preuves et conclusions motivées, jamais une chaîne de pensée interne.
Les anciennes structures et tests sont conservés dans `legacy/` pour les archives.

## État avant publication

`procedural_audit.phases` contient initialization, weekly_recap, F1–F6,
collection_coverage_audit, reasoning, asymmetry_gate, scenario_tree, presentation,
json_and_reports. Chaque entrée donne statut, début, fin, artefact et limitations.
Collectes après initialization ; coverage après toutes collectes ; reasoning
après coverage ; asymmetry après reasoning ; arbre après asymmetry ; présentation
après raisonnement/jugements/arbre ; JSON et rapports après présentation.

COMPLETE signifie procédure réalisée ; une mesure peut rester UNKNOWN après
une recherche honnête. PARTIAL/FAILED exigent limitation et entrée dans gaps.
NOT_APPLICABLE est réservé à weekly_recap hérité dans un intermédiaire, avec
explication. Un état COMPLETE n’a aucune phase incomplète ni gap procédural.
Tous les horaires précèdent generated_at, avec début <= fin et ordre possible.
Ne jamais créer de dates d’audit rétrospectives comme si elles avaient été observées.

`question_coverage` contient une entrée par chacune des 32 questions canoniques :
question_id, checked_at, outcome identique à la réponse et request_refs résolubles.
`weekly_recap_coverage` couvre WR.DAILY_PRICE_FACTS, WR.BENCHMARK_CONTRACT, WR.EVENTS,
WR.CROSS_ASSET_MOVES et WR.REPORTED_ATTRIBUTION ; l’intermédiaire peut les noter
INHERITED_UNCHANGED. Le contenu détaillé reste dans les réponses et la chronologie.
Le catalogue de la collecte, y compris comparaison F1/F2 et dynamique des événements,
continue à gouverner les questions : les identifiants éditoriaux ne réduisent pas
leur portée.

`research_audit.request_log` garde requête, accès daté et URLs ; sources donne
identité, URL, mesure/as-of, type et récupérations. Les références des réponses,
scénarios et jugements doivent résoudre vers ces sources. Un essai de récupération
non concluant reste dans le journal. Les sources difficiles utilisent le registre
Source Recovery quand pertinent, avec résultat précis et distinction découverte,
accès, publication, comparabilité, méthode, non-observabilité ou cause indéterminée.

`reasoning_components` explique où sont traités : competing_hypotheses,
dominant_driver, transmission_chains, cross_asset_reality_test, contradictions,
anomalies, priced_in, contexts_by_horizon, invalidations, unknowns. La lecture
locale/globale doit réellement les traiter ; un champ rempli n’est pas la preuve
que l’interprétation est correcte. L’exogenous_review consigne les développements
recherchés et leurs limites. Aucune source, quantité de mots ou nombre de nœuds
minimum arbitraire n’est ajouté.

## Chronologie, indépendance, héritage

Le Sunday sépare vendredi de marché et cutoff documentaire New York/UTC, semaine
observée et préparée. Le gel indépendant précède la lecture comparative du prior.
Une récupération tardive conduit à reconsidérer les jugements et à dater le cutoff
final ; le bridge indique cette limite sans prétendre n’avoir jamais lu le prior.
Le rebuild correctif du lundi est explicite, complet et conserve les archives.

L’intermédiaire enregistre parent immédiat, cutoff, origine/index et handoff
consommé. Chaque question est vérifiée dans sa fenêtre et reçoit un refresh_status.
La comparaison explique les six jugements modifiés et les transitions causales.
Le hash de la chronologie parent protège l’héritage ; une correction est expliquée.
Un article ancien n’est pas nouveau parce qu’il a été récupéré aujourd’hui.

## Validation et reçu final

`--preflight` valide l’état avant upload. Le rapport de validation décrit les
checks de schéma, preuves/références, 32 questions, six jugements, filtres,
graphe, dates, phases, parent et parité du Markdown. Ajouter la revue des calculs,
unités, répétitions et du sens des affirmations. Expliquer les limites des contrôles.

Le reçu `GOLD_RUN_COMPLETION_RECORD` conserve son schéma et ses contrôles :
market_state_validation COMPLETE, puis drive_readback, handoff_generation,
handoff_validation. Enregistrer exactement quatre rôles publiés, hashes,
heures d’upload/readback et leur résultat. Le state hash est canonique JSON.
Le reçu contrôle identité, parent/origine et hash de l’état. Une phase en échec
est un gap ; aucune attestation auto-déclarée du fichier d’état ne remplace ce reçu.

Le reçu est immuable dans Control/run_records, frontend_eligible false. Il n’est
pas un cinquième Output. Le bundle final doit inclure l’état source, son handoff
et son reçu ; un intermédiaire doit aussi fournir son parent vérifié. Le reçu
contient la preuve disponible après publication, jamais une déclaration anticipée.
La relecture Drive compare le contenu réel et vérifie le dossier de destination.

Les fixtures indiquent explicitement leurs traces synthétiques. Elles testent le
contrat et le rendu, ne prouvent pas qu’une recherche ou livraison réelle a eu lieu.

`exogenous_review[].category_codes` couvre explicitement les neuf catégories du
catalogue de `tools/procedural-audit.mjs` ; plusieurs peuvent partager une même
explication. Une catégorie sans résultat matériel reste documentée, pas omise.
Le contrôle de question doit tomber dans la phase de sa famille. La continuité
finale vérifie aussi l’identité/version du handoff scellé et le hash du handoff
consommé fourni avec le bundle. Inclure les pièces du parent si nécessaire ;
les déclarations d’identité seules ne remplacent pas leur relecture.
