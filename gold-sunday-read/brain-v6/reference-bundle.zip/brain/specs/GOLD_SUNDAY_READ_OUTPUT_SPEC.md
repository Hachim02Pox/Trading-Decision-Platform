# Sortie officielle Gold — contrat éditorial v6

Ce contrat s’applique au Sunday et à chaque intermédiaire. Il officialise la
recette expérimentale validée, sans changer les questions de collecte ni les
mécanismes du manuel. Le schéma normatif est `schema/gold_editorial.schema.json`.
Les anciens `analysis_contract`, `presentation.version`, `already_priced_analysis`
et `annotations` appartiennent au contrat archivé dans `legacy/`.

## Structure et correspondance du contenu

| Champ | Contenu obligatoire |
|---|---|
| `document_type`, `format_version`, `frontend_eligible` | GOLD_MARKET_STATE, 6.0, true ; ingestion réelle exclut FIXTURE |
| `meta` | run, type, mode, état de procédure, parent/origine, semaine, génération et fenêtre de preuves |
| `time_scope` | semaine observée et préparée lundi–vendredi, clôture vendredi séparée du cutoff total NY/UTC |
| `weekly_cycle` | origine et index 0, 1 ou 2 |
| `opening_thesis` | thèse, mécanisme, cas contraire, préférence, déjà intégré, conditions futures, limites |
| `decision_panel` | les deux filtres exacts, réponse par sens, mécanisme, contradiction, bascule, horizon, réexamen |
| `six_judgments` | six raisons distinctes et leurs preuves, pas six badges sans contenu |
| `horizons`, `calendar` | tactique/moyen/structurel ; événements à venir au cutoff avec attente et ce qu’ils testent |
| `scenario_tree` | nœuds et relations lisibles indépendamment ; aucun cycle, référence orpheline ou probabilité inventée |
| `family_readouts` | six familles et toutes les 32 questions canoniques avec réponse, statut, as-of, preuve, limites et lecture locale |
| `weekly_bridge` | Sunday : comparaison après gel indépendant, écarts, survivants, attentes résolues/échouées et limites |
| `evolution_review` | intermédiaire : parent immédiat, faits nouveaux, persistants, renforcés/affaiblis/invalidés, nouveaux facteurs et prochains tests |
| `chronology`, `exogenous_review` | faits de semaine et recherche hors scénario hérité, avec dates et portée |
| `datasets`, `sources`, `research_audit` | mesures, unités, contrats, calculs, sources datées et journal de collecte complet |
| `procedural_audit` | phases ordonnées, chaque question tentée, couverture du récap et des composants de raisonnement, lacunes |
| `glossary_fr` | termes expliqués dans le contexte |
| `content_preview` | Markdown français calculé depuis les champs éditoriaux, avec SHA-256 |

## Les six jugements

| `id` | Question |
|---|---|
| `macro_direction` | Quel sens domine conditionnellement et pourquoi ? |
| `directional_asymmetry` | Les surprises/réactions favorisent-elles davantage un côté ? |
| `positioning_asymmetry` | Qui reste vulnérable, quel déclencheur et quelle alternative ? |
| `evidence_quality` | Quelles preuves soutiennent les conclusions et quelles limites changent leur solidité ? |
| `analysis_scope` | Pourquoi cette analyse s’arrête-t-elle aux fondamentaux ? |
| `fundamental_conclusion` | Quel résultat exact pour chacun des deux filtres ? |

Le macro utilise BULLISH/BEARISH/MIXED/UNCLEAR. Le positionnement utilise
BULLISH/BEARISH/BALANCED/UNESTABLISHED/UNKNOWN. Les libellés visibles sont français.
`analysis_scope.state` vaut FUNDAMENTALS_ONLY. La conclusion technique encode
`FUTURES_<LONG|SHORT|NEITHER>_CFD_<LONG|SHORT|NEITHER>` et n’est jamais un label visible.
Les autres jugements conservent une qualification argumentée, pas un score.
Les booléens de clarté/actualité du panneau sont des conclusions à justifier par
le récit et le cutoff, jamais des interrupteurs pour forcer une permission.

## Exigences éditoriales

Chaque conclusion explique sa preuve datée, son mécanisme et ses acteurs, le
meilleur contraire, pourquoi elle domine ou demeure indécise, ce qui est intégré,
le prochain test et l’invalidation. Ces éléments peuvent partager un paragraphe
cohérent ; ne pas répéter mécaniquement la même formule. L’ouverture donne des
chemins haussier, baissier et indécis. Aucun payoff ou grade d’exécution n’est requis.

Chaque nœud contient condition, preuves actuelles, chemin causal, confirmation
observable, fenêtre, contradiction, invalidation et interprétation pratique.
Chaque arête explique pourquoi sa condition transmet un effet à l’or. Le graphe
est un ensemble d’hypothèses causales, pas une prédiction certaine.

Chaque famille contient les mêmes questions qu’au catalogue `FAMILY_QUESTIONS`
de `tools/family-readout.mjs`. `ANSWERED` exige des preuves résolubles ; les autres
statuts exigent `missing_observation` : quantité exacte, obstacle, essais datés,
conséquence et récupération. Les preuves non trouvées restent absentes.

L’intermédiaire remplit la même structure. Il peut être bref en première vue, mais
ne remplace pas F1–F6 par une liste de statuts. Chaque réponse a `refresh_status`
et `checked_at`. La chronologie de la semaine passée reste héritée ; la nouveauté
va dans `evolution_review`. Une correction de l’historique est motivée explicitement.

## Quatre livrables et plans distincts

Noms compatibles avec la découverte de Trading-Decision-Platform :

- Sunday : `sunday_read_YYYY-MM-DD.json` et `sunday_read_YYYY-MM-DD.md`,
  `VALIDATION_REPORT_YYYY-MM-DD.md`, `RUN_REPORT_YYYY-MM-DD.md`.
- Intermédiaire : `gold_intermediate_YYYY-MM-DD_01.json` et le même basename
  `.md`, `VALIDATION_REPORT_INTERMEDIATE_YYYY-MM-DD_01.md`,
  `RUN_REPORT_INTERMEDIATE_YYYY-MM-DD_01.md` ; index suivant `02`.
- En cas de collision, conserver l'archive et ajouter un suffixe immuable
  `[a-z0-9_-]+` avant l'extension Sunday ou avant le numéro intermédiaire.
  JSON et rapport gardent exactement le même basename. L'identité reste
  `meta.run_id`, jamais le nom seul.

Ces noms remplacent la proposition `GOLD_*_COMPLET` de la première rédaction v6,
qui n'était pas reconnue par le backend existant. Renommer ne suffit pas :
le backend doit également accepter explicitement le contrat éditorial v6.
La revue de preuves contient les sources et URLs, essais, calculs, conflits,
checks réellement exécutés et limites. La note de run contient les versions
consultées, décisions de procédure, statut, reprise éventuelle et reçus disponibles.
Le rapport de lecture ne contient aucun lien de source ni identifiant brut.

Les quatre rôles de publication restent MARKET_STATE_JSON, HUMAN_REPORT,
VALIDATION_REPORT, RUN_REPORT. Le handoff et le reçu final vivent séparément dans
Control. Ne pas transformer l’exemple historique en état réel en changeant un flag.
La publication suit le protocole de run ; la parité textuelle ne prouve ni la
vérité des observations, ni la qualité prédictive, ni le rendu du terminal externe.
