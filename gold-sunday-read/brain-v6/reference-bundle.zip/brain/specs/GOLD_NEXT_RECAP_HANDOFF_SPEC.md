# NEXT_GOLD_RECAP — continuité officielle v6

Chaque run publié écrit un handoff distinct des quatre livrables dans Control.
Le run expérimental isolé du 27 septembre n’en avait pas écrit. Officialiser son
rendu n’enlève pas cette obligation de production ni le planning des intermédiaires.
Le schéma reste `schema/next_gold_recap.schema.json` ; les anciennes versions restent
lisibles. Pour un état v6, ajouter `market_state_format_version: "6.0"`.

## Identité et écriture

Conserver un unique Drive file ID stable ; incrémenter handoff_version et donner
un nouveau handoff_id logique. Le prochain run conserve identité, version et
hash du contenu consommé. Il charge le dernier état validé/son reçu et vérifie
parent/origine/cutoff. Réexécuter une version consommée doit reprendre le même run,
jamais dupliquer une publication. Lire avant et après écriture ; une concurrence,
une version inattendue ou un échec bloque le remplacement. Ne pas écraser un
handoff actuel avec un run plus ancien ou incomplet.

## Contenu

Conserver identités, prior_cutoff, next_execution, family_audit F1–F6,
new_information_policy, exogenous_scan, required_process, output_contract,
scenario_checks, asymmetry_checkpoints, expiry et weekly_cycle.
`inherited_state` v6 contient macro_direction, directional_asymmetry,
positioning_asymmetry, `fundamental_eligibility` (futures puis CFD : LONG/SHORT/NEITHER)
et un résumé. Aucun grade d’exécution n’est inventé pour remplir un ancien enum.

`continuity_checkpoint` contient source_run_id, evidence_cutoff_end, résumé,
durable_foundations, live_questions, branch_checks et six_verdicts :
macro_direction, directional_asymmetry, positioning_asymmetry, evidence_quality,
analysis_scope, fundamental_conclusion. Les valeurs sont exactement celles de
l’état scellé, pas une nouvelle interprétation du prochain run.

Chaque scénario à vérifier précise question économique, condition observable,
variables directes, transmission attendue, confirmations inter-marchés/flux,
contradictions, invalidations, lacunes et fenêtre. Les checkpoints de positionnement
couvrent COT/retard, ETF, OI comparable, funding/acteurs, demande physique,
catalyseurs et alternatives ; les options par échéance ne sont pas un veto caché.
Les URLs d’audit peuvent rester dans Control mais ne s’affichent pas au lecteur.

L’instruction du prochain run doit exiger le même format v6, les mêmes 32 questions
et la même granularité. Tester les fondations d’abord ; scanner les nouveaux
moteurs même absents de la fiche ; puis juger les branches. Les anciennes conclusions
sont des hypothèses à réexaminer, pas des objectifs à préserver.

## Moment du prochain récap

ACTIVE : heure future America/New_York, raison économique, événement/condition
et minimum_confirmation_delay. Ne pas programmer automatiquement à la seconde
d’une publication si la transmission n’est pas encore interprétable. Fournir
reason_fr et minimum_confirmation_delay_fr pour le résumé public ; les champs
historiques reason/minimum_confirmation_delay restent renseignés.

Autoriser seulement le premier/deuxième intermédiaire dans la semaine d’origine,
lundi–jeudi, avant vendredi 00:00 NY et avant expiry. Après deuxième intermédiaire,
après un premier jeudi ou sans prochain checkpoint utile, écrire CLOSED et
next_execution null. CLOSED conserve le Drive ID et les fondations pour le Sunday
suivant. Cela ne programme pas lui-même l’automatisation du Sunday.

Ce fichier n’est jamais une publication de marché : document_type
NEXT_GOLD_RECAP_HANDOFF, frontend_eligible false. Son existence ne prouve pas
qu’un scheduler externe a exécuté le run. Le dépôt ne crée pas le bouton manuel
pré-trade et ne prétend pas déclencher Work depuis le terminal.
