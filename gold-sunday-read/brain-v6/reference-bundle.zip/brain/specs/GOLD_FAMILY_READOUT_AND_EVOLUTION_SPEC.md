# Familles, évolution et comparaison — v6

Les 32 identifiants canoniques de `FAMILY_QUESTIONS` dans `tools/family-readout.mjs`
et toutes les questions de Collection & Evidence sont conservés. Les modalités
d’interprétation restent celles du manuel. Les anciennes formes JSON sont dans
`legacy/GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md`.

Sunday et intermédiaire publient six `family_readouts` : `id`, titre français,
questions et `local_interpretation_fr`. Chaque question porte son id canonique,
sa famille, son libellé, réponse complète, statut, date/fenêtre observée, références
et `missing_observation` si nécessaire. Une réponse doit donner le résultat et
son implication, pas seulement un nombre ou un label. Distinguer fait, interprétation,
contradiction, limite et test futur dans la lecture locale. Les réponses héritées
sont vérifiées, jamais déclarées fraîches par simple copie.

`missing_observation` nomme mesure exacte, raison et obstacle observé,
`attempt_refs` résolubles vers le journal, essais fournisseurs datés avec URLs,
conséquence pour la conclusion et récupération suivante. Un report optionnel hors
périmètre reste expliqué. Une date de publication future n’est annoncée que vérifiée.

Le récit global relie causalement les familles : hypothèses rivales, driver,
transmission, test inter-marchés, contradictions, anomalies, prix intégrés,
horizons, invalidations et inconnues. Chaque composant a une trace dans
`procedural_audit.reasoning_components` et un traitement éditorial pertinent.
Les preuves restent accessibles à l’audit, sans devenir une bibliographie visible.

## Sunday

`weekly_bridge` est rempli après gel indépendant de l’interprétation courante.
Enregistrer `independent_freeze_at`, `prior_read_at`, état et cutoff antérieurs,
limite de comparaison, différences, conclusions survivantes, attentes résolues
et échouées. Si l’état précédent ne peut être obtenu ou vérifié, conserver
l’analyse indépendante et décrire exactement cette limite ; ne pas inventer le
bridge ni lire un handoff plus récent comme s’il appartenait à la semaine passée.

## Intermédiaire

Même granularité des 32 réponses et des scénarios. Chaque question porte un
`refresh_status` (UPDATED/UNCHANGED/PARTIAL/NOT_DUE/UNKNOWN/INVALIDATED) et
`checked_at`. UNCHANGED exige une vérification dans la nouvelle fenêtre ; NOT_DUE
explique le calendrier. L’absence de publication ne vaut pas confirmation.
`evolution_review` se rattache au parent immédiat : récit, toujours vrai, nouvelles
observations, renforcé, affaibli, invalidé, facteurs exogènes, non résolu, prochains
tests. Chaque changement de jugement précise avant/après, raison datée et conséquence.
Les champs vides signifient qu’aucun élément correspondant n’a été constaté après
vérification, pas qu’une phase a été omise.

Le handoff garde les fondations durables, questions vivantes, branches à vérifier
et les six jugements exacts. Il instruit le prochain run à tester, pas à défendre,
la conclusion héritée. Il recherche aussi les nouveaux moteurs absents de la fiche.
