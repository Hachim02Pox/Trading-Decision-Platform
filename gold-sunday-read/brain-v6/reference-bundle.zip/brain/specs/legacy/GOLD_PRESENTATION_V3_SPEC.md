# GOLD PRESENTATION V3 HISTORICAL CONTRACT AND V4 PRODUCTION EXTENSION

## 0. V4 production extension

New `REAL` states require `presentation.version: 4`; V3 remains historical.
V4 adds structured final copy, never private reasoning: weekly chronology and
causal assessment; each horizon's state, drivers, transmission, evidence,
contradictions, counter-case, confirmation, invalidation and implication; and
full explanations for the six visible verdicts. Material conditional cases
state observable conditions, transmission, independent and positioning/flow
confirmation, six expected outcomes, expiry and unknowns. Localized glossary
annotations carry `id`, `locale`, exact block `path`, exact `anchor`,
`glossary_id` and optional occurrence so the frontend can place an icon without
approximate text searching.

### V4 deterministic contract

For every new REAL Sunday or intermediate state, `presentation.version` is 4.
Each locale includes the completed-week story, chronology, causal assessment,
canonical-cutoff current setup, next-week preparation, tactical/medium/
structural horizons, a complete canonical scenario tree and guided walkthrough.
The six separate verdict explanations are `macro_direction`,
`directional_asymmetry`, `positioning_asymmetry`, `edge`,
`opportunity_quality`, and `execution_readiness`. Each has exactly these
required fields: `verdict`, `observations`, `mechanism`,
`supporting_evidence`, `contrary_evidence`, `unknowns`, `practical_meaning`,
`would_change`, and `insufficient_alone`. Macro direction is never itself an
edge or authorization to execute.

Each locale must contain understandable bullish, bearish, and no-edge
conditional cases. Every case has `conditions`, `transmission`,
`independent_confirmations`, `positioning_confirmation`,
`expected_direction`, `expected_directional_asymmetry`,
`expected_positioning_asymmetry`, `expected_quality`, `expected_readiness`,
`expected_edge`, `invalidation_or_expiry`, and `unknowns`; its expected edge
must agree with a branch in the localized and canonical trees.

`priced_in.already_priced_analysis` is required whenever `already_priced` has
an item. It maps one-to-one by array order: analysis item N explains
`already_priced[N]`. It has `prior_expectation`, `observed_outcome`,
`verified_reaction`, `now_priced`, `still_repriceable`, `evidence_used`,
`unknowns_or_limits`, and `as_of`. A future catalyst is not an observed
outcome; partial information remains explicit in `unknowns_or_limits`.

V4 annotations are top-level locale entries with `id`, `locale`, `path`,
`anchor`, `occurrence`, and `glossary_id`. `path` resolves to an exact displayed
string in the same locale; `anchor` must be exact (case, plural and abbreviation
included), occurrence is a positive existing occurrence, and `glossary_id`
exists. The anchor must be in that localized glossary entry's
`annotation_anchors` (or its canonical term). Every localized `glossary_refs`
ID must have at least one annotation in that same locale. Thus `Taux réel` is
not `taux réels`, `Flux ETF` is not `flux ETF`, and `Open interest` is not `OI`
unless both variants are declared. Never attach `SKEW` to an `OI` anchor.

## 10. Opportunity quality and execution readiness

New contract presentations add localized `opportunity_quality` and
`execution_readiness` blocks alongside `direction_state`. The user-facing
labels are `Qualité de l’opportunité` / `Opportunity quality` and natural
French/English explanations of whether the imbalance is strong, medium, weak,
trapped or unknown, and whether activation is ready, waiting or not ready.
Do not expose `FOMO_CONFIRMED`, `READY_IF_TRIGGERED` or other raw tokens; the
frontend receives display copy and structured evidence references.
# GOLD PRESENTATION V3 SPEC

## 1. Fundamental rule

Every string inside the localized presentation object is final copy ready to render directly.

The frontend must not be required to:

- remove internal IDs;
- translate enums;
- interpret shorthand;
- reconstruct causal links;
- parse custom glossary markup;
- infer which analytical field is safe to display.

## 2. No inline glossary markup

The syntax below is forbidden in V3 human-facing copy:

```text
[[NO_EDGE|Pas d’avantage directionnel démontré]]
```

Use plain display text plus structured references:

```json
{
  "headline": "Pas d’avantage directionnel démontré avant la décision de la Fed",
  "glossary_refs": ["NO_EDGE"]
}
```

If exact term placement is required, use annotations separate from the copy:

```json
{
  "text": "Les taux réels restent élevés.",
  "annotations": [
    {
      "visible_text": "taux réels",
      "glossary_id": "REAL_YIELD"
    }
  ]
}
```

Raw annotation syntax must never appear in the rendered text.

## 3. Internal identifiers

Internal IDs remain mandatory for structured relationships but are never user-facing.

Allowed structured fields:

- `node_id`;
- `edge_id`;
- `node_refs`;
- `edge_refs`;
- `branch_refs`.

Forbidden in visible copy:

- `N-ROOT`;
- `N-RATES-UP`;
- `N-FLOW`;
- `N-FUSE`;
- `L1`;
- any actual node or edge ID from the run.

## 4. Standalone diagram contract

The scenario diagram must be understandable without opening node details and without reading the guided walkthrough.

Every displayed node must provide:

```json
{
  "node_id": "structured internal reference",
  "display_title": "natural localized title",
  "display_body": "one or two complete explanatory sentences",
  "why_it_matters": "economic significance",
  "confirmation_needed": "observable confirmation",
  "display_status": "localized human status",
  "display_category": "localized human category",
  "glossary_refs": []
}
```

Every displayed relation must provide:

```json
{
  "edge_id": "structured internal reference",
  "from_node_id": "structured reference",
  "to_node_id": "structured reference",
  "display_label": "short causal statement",
  "display_explanation": "why the first state can lead to the second",
  "confirmation_needed": "what must be observed before accepting the transition"
}
```

Arrows without a human causal label are not valid V3 presentation.

## 5. Human statuses

Do not display raw analytical enums directly.

The French presentation may use:

- `Établi`;
- `À surveiller`;
- `En attente de l’événement`;
- `Impossible à mesurer actuellement`;
- `Contredit par les observations`;
- `Conclusion actuelle`;
- `Condition non encore confirmée`.

The English presentation must carry the same meaning.

An asymmetry assessment with analytical status `CONFIRMED` must not be displayed as if a bullish or bearish gate had passed. Display the result itself, such as:

- `Test effectué — asymétrie équilibrée`;
- `Test effectué — avantage haussier démontré`;
- `Test effectué — avantage baissier démontré`.

## 6. Direction and edge display

The presentation must separately expose:

- macro direction;
- directional asymmetry;
- positioning asymmetry;
- final edge.

Example:

```json
{
  "macro_direction": {
    "value": "BULLISH",
    "display": "Direction macro haussière",
    "explanation": "..."
  },
  "positioning_asymmetry": {
    "value": "BALANCED",
    "display": "Positionnement encore équilibré",
    "explanation": "..."
  },
  "edge": {
    "value": "NO_EDGE",
    "display": "Pas d’avantage directionnel démontré",
    "explanation": "..."
  }
}
```

## 7. Diagram reading order

The rendered diagram should visually group the story into these phases when present:

1. current observed state;
2. incoming information and exogenous modifiers;
3. central decision or catalyst;
4. alternative economic outcomes;
5. first market transmission;
6. flow and positioning confirmation;
7. directional and positioning asymmetry test;
8. current and conditional conclusions.

The JSON defines economic topology. The frontend may improve layout but must not invent or delete analytical relationships.

## 8. Guided walkthrough

The walkthrough remains mandatory. It must tell the same story as the diagram and retain structured node and edge references.

It must not compensate for missing visible causal labels in the diagram.

## 9. Validation

Before publication verify:

- zero `[[...|...]]` tokens in human-facing copy;
- zero actual scenario IDs in human-facing copy;
- all localized nodes and relations resolve to canonical IDs;
- every displayed relation has a causal label and explanation;
- every displayed node has explanatory body copy;
- direction and edge are not conflated;
- FR and EN preserve the same conclusion;
- diagram and walkthrough describe identical topology.

## 10. Coverage, not volume

For a new `REAL` Sunday or intermediate V3 run, every material analytical
item must have final French and English representation. Material means a node
or relation deliberately retained in the analytical scenario topology, a node
referenced by a retained scenario, or content in a required analytical
section. It does not mean a minimum count, length, or score. A three-node
tree is valid when it covers the reasoning; a longer presentation is invalid
when it loses a material branch or transmission.

The required localized blocks are the market story (past week, current setup,
and week ahead), all three horizons, priced-in analysis, asymmetry, the four
direction-state fields, V3 tree, and walkthrough. French and English are
independent final-copy contracts: no locale may rely on silent fallback from
the other locale or from analytical text. English sentences copied into French
final copy are invalid; shared technical market vocabulary remains allowed.
