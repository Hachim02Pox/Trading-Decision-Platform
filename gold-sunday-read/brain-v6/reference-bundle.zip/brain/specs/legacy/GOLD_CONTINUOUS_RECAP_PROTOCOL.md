# GOLD CONTINUOUS RECAP PROTOCOL

New REAL production from 26 September 2026 also follows
`GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md`: a Sunday may have at most two
intermediates, both with cutoffs before Friday 00:00 America/New_York. After
the second, or when the remaining week cannot justify another check, the
stable handoff becomes CLOSED with no requested intermediate time. Preserve
its continuity checkpoint for independent comparison by the next Sunday.
Weekly options observations are context when obtained, while expiry-specific
IV/skew/model GEX is primarily a separate user-triggered pre-trade check.
Existing F5 source timestamps and all non-options positioning diagnostics
remain mandatory. Explicitly mark a weekly option question NOT_APPLICABLE
only when the reason is that the metric is intentionally deferred and
immaterial to that *weekly* judgment. Do not hide an observed contrary option
signal.

For new REAL outputs generated from 2026-09-25 00:00 America/New_York onward,
follow `GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md`. The Sunday output
contains per-family sourced questions and local reasoning plus the global
synthesis. Intermediate outputs compare to their **immediate** parent in a
detailed `evolution_review`; the full analytical JSON remains canonical but
does not become six duplicate Sunday pages. Each run replaces the active
handoff with a version 7+ `continuity_checkpoint`. The next Sunday performs
independent collection and reasoning before comparing its result to the last
validated prior-week state via `weekly_bridge`. Keep prior state rows and
Drive outputs immutable for audit; the page starts its visible reading at the
new Sunday origin.

### 10A. Opportunity quality and execution readiness

New states opt into the additive positioning contract. `opportunity_quality`
uses `STRONG`, `MEDIUM`, `WEAK`, `TRAP` or `UNKNOWN`; it is a qualitative
explanation, not a count. `execution_readiness` uses
`READY_IF_TRIGGERED`, `WAITING_FOR_CATALYST`,
`CATALYST_PRESENT_BUT_UNCONFIRMED`, `NOT_READY` or `UNKNOWN`.

Readiness is separate from positioning asymmetry: an extreme can persist without
a dated activation mechanism. A new intermediate recap must refresh COT lag,
ETF flows, price/OI, price/IV and skew, event premium versus FOMO, legitimate
gamma, SGE/physical confirmation, funding/fuses, catalyst expiry and the
quality/readiness/edge transitions. Past-week narrative remains immutable.
# GOLD CONTINUOUS RECAP PROTOCOL

## 1. Purpose

The Gold system is a rolling analytical state, not a sequence of independent reports.

The Sunday Read initializes the week. Intermediate recaps update that state when a planned checkpoint, a material scenario condition, or a new exogenous factor requires reassessment.

Every run must preserve the separation between:

- evidence collection;
- analytical reasoning;
- directional interpretation;
- positioning asymmetry;
- final edge;
- human-facing presentation.

No run may begin from a desired bullish or bearish conclusion.

## 2. Canonical outputs

Every Sunday run produces:

1. an immutable Sunday market-state JSON;
2. the human-readable Sunday report;
3. validation and run reports;
4. one standalone `NEXT_GOLD_RECAP.json` handoff for the next intermediate recap.

Every intermediate run produces:

1. an immutable intermediate market-state JSON;
2. a human-readable intermediate recap;
3. validation and run reports;
4. a replacement `NEXT_GOLD_RECAP.json` for the following recap.

The handoff is an operational instruction file. It is never a frontend publication.

## 3. Drive separation

Frontend state files and operational files must not be selected from the same unfiltered “latest JSON” list.

Preferred layout:

- `Gold Sunday Read Output`: immutable Sunday and intermediate market-state publications (per run: state JSON, human report, validation report, run report), uploaded only after the local validation passed;
- `Gold Sunday Read Control`: exactly one mutable `NEXT_GOLD_RECAP.json`, plus the immutable per-run `run_records/RUN_COMPLETION_RECORD_<run_id>.json` (see `GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md` section 13). The completion record is never written to the Output folder.

If separate folders are not possible, the frontend must select only files whose metadata contains:

```json
{
  "document_type": "GOLD_MARKET_STATE",
  "frontend_eligible": true
}
```

It must explicitly ignore:

```json
{
  "document_type": "NEXT_GOLD_RECAP_HANDOFF",
  "frontend_eligible": false
}
```

and:

```json
{
  "document_type": "GOLD_RUN_COMPLETION_RECORD",
  "frontend_eligible": false
}
```

Filename filtering alone is a secondary safeguard, not the sole safeguard.

## 4. Rolling lineage

Every market-state JSON must identify:

- `run_id`;
- `run_type`: `SUNDAY` or `INTERMEDIATE`;
- `parent_run_id`;
- `origin_sunday_run_id`;
- `generated_at`;
- `as_of`;
- `evidence_cutoff_start`;
- `evidence_cutoff_end`;
- `document_type = GOLD_MARKET_STATE`;
- `frontend_eligible = true`.

An intermediate run always begins from the latest validated market state. It never silently restarts from the prior Sunday if a newer intermediate state exists.

## 5. Evidence window

For articles, speeches, interviews, statements and reported attribution:

- only material published after the previous validated cutoff may be treated as new evidence;
- prior articles remain historical evidence and must not be counted again as new confirmation;
- syndicated copies from the same ultimate origin count as one source chain.

For official datasets, market series and direct provider pages:

- the same source may be revisited to obtain a newer observation;
- every observation keeps its own `AS-OF`, publication time and measurement window;
- current levels must not be inferred only from articles when a suitable direct source is available.

## 6. Intermediate recap scope

An intermediate recap does not repeat the completed prior-week chronology. That history is inherited and immutable unless a verified correction is required.

The intermediate narrative must answer:

1. Where were we at the previous cutoff?
2. What new facts appeared after that cutoff?
3. Which previously established facts remain valid?
4. Which facts became stale, superseded or contradicted?
5. Did any planned scenario condition trigger?
6. Did the expected transmission occur?
7. Did flows and positioning confirm or reject it?
8. Did a new exogenous factor change the problem?
9. What is the current directional interpretation?
10. Is there an exploitable positioning asymmetry?
11. Is the final edge bullish, bearish, no edge or unknown?
12. What must be checked next, and when?

When a required value cannot be observed, Work must inspect its actual publication schedule, direct source, measurement window and comparable definition, plus any practical access or model limitation. State the verified cause of the gap; if that cause itself is unknown, say so and preserve the attempted checks. Never turn “not recovered” into “does not exist.”

For each new REAL intermediate run from 2026-09-25T00:00:00Z, read `GOLD_INTERMEDIATE_NARRATIVE_CONTRACT.md` and publish `intermediate_summary` in both French and English. Compare each sentence with the immediate parent state identified by `meta.parent_run_id`. Name only the parent conclusions that still survive the new evidence; identify evidence references, changed judgments, practical consequences, and every material unknown's specific reason in `unknown_reasons`. Publish `macro_reading` to separate as-of observation from causal interpretation, conditional future tests and invalidation. A price drop by itself is never proof of the cause or a guaranteed continuation. Reconcile `presentation.fr/en.direction_state`, `opportunity_quality`, `execution_readiness`, `verdict_explanations`, and the scenario walkthrough with the current state. An inherited Sunday explanation must not justify a changed current verdict. Older immutable JSON may omit this object.

## 7. Mandatory family audit

Weekly Recap is not rerun during an intermediate recap.

F1 through F6 must all be audited. Each family receives one status:

- `UPDATED`;
- `UNCHANGED`;
- `PARTIAL`;
- `NOT_DUE`;
- `UNKNOWN`;
- `INVALIDATED`.

`UNCHANGED` is allowed only after the family has been checked against the new evidence window and relevant current observations.

Publication lag is not a research failure. Structurally unavailable information remains `UNKNOWN`.

## 8. Exogenous-factor scan

Every intermediate run must conduct a targeted scan for material factors not represented in the inherited scenario set, including where relevant:

- geopolitical escalation;
- energy or supply disruption;
- funding or collateral stress;
- credit-event propagation;
- unexpected fiscal or political action;
- central-bank intervention;
- exchange, clearing or market-function disruption;
- forced liquidation evidence;
- material regulatory or sanctions action.

The scan must not convert journalistic attribution into certain causality.

If a new exogenous factor is material, the system may modify or replace the scenario structure. It must record why the inherited structure became insufficient.

## 9. Scenario transition states

A scenario is not validated merely because one condition moved in the expected direction.

Allowed transition states:

- `NOT_TESTED`;
- `CONDITION_TRIGGERED`;
- `TRANSMISSION_PARTIAL`;
- `TRANSMISSION_CONFIRMED`;
- `FLOW_CONFIRMATION_PENDING`;
- `FLOW_CONFIRMED`;
- `CONTRADICTED`;
- `INVALIDATED`;
- `EXPIRED`;
- `SCENARIO_VALIDATED`.

The report must state which exact transition occurred and cite the evidence responsible.

## 10. Direction, positioning and edge

These are separate analytical outputs:

```json
{
  "macro_direction": "BULLISH | BEARISH | MIXED | UNCLEAR",
  "directional_asymmetry": "BULLISH | BEARISH | BALANCED | UNKNOWN",
  "positioning_asymmetry": "BULLISH | BEARISH | BALANCED | CROWDED | LATE | UNKNOWN",
  "edge": "BULLISH | BEARISH | NO_EDGE | UNKNOWN"
}
```

No scoring, voting, arbitrary weight or fabricated numerical confidence is permitted.

The system must not avoid `BULLISH` or `BEARISH` when the evidence, transmission and asymmetry gate genuinely support that terminal.

Conversely, a bullish or bearish macro direction does not automatically imply a bullish or bearish edge. If positioning, flows, options or payoff remain unfavorable or unobservable, `NO_EDGE` or `UNKNOWN` remains valid.

## 11. Full reasoning requirement

After the F1–F6 audit, every intermediate recap must reapply the canonical reasoning manual to the updated evidence state, including:

- competing hypotheses;
- dominant marginal driver;
- transmission chains;
- cross-asset reality test;
- independent confirmations versus echoes;
- contradictions and anomalies;
- priced-in versus surprise analysis;
- tactical, medium-term and structural contexts;
- invalidations;
- event expiry;
- directional asymmetry;
- positioning asymmetry;
- final edge.

The inherited conclusion has no privileged status.

## 12. Next-recap planning

After reasoning, the run must create the next handoff.

The next checkpoint is chosen from actual analytical need, not a fixed daily cadence. The plan must account for:

- data publication time;
- expected availability delay;
- time needed for market transmission;
- later flow or positioning publication;
- event expiry;
- unresolved contradictions;
- need for end-of-session confirmation.

The handoff may schedule one next full recap. It may also list observation windows that should be checked during that recap.

## 13. Validation

Before publication validate:

- schema;
- source references;
- evidence references;
- scenario node and relation references;
- duplicate IDs;
- lineage;
- evidence cutoff chronology;
- unchanged analytical evidence inherited correctly;
- new evidence published or observed after the prior cutoff;
- direction, positioning asymmetry and edge consistency;
- French and English semantic equivalence;
- for new REAL intermediates, `intermediate_summary` in FR/EN with immediate parent ID, supported remaining conclusions, changed judgment explanations and resolvable evidence references (`node tools/validate.mjs` validates these);
- zero internal IDs in human-facing copy;
- zero raw glossary markup in human-facing copy;
- the diagram is understandable without the guided walkthrough;
- the handoff is not frontend eligible;
- the procedural audit of the run (see `GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md`,
  section 12 for the intermediate proof: latest validated state, lineage,
  handoff consumption and idempotence, new evidence versus identified
  baselines, preserved prior-week history, F1-F6 audit, exogenous scan,
  scenario transitions) and its run completion record.
