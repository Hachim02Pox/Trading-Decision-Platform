# Gold Market Story Brain

**New REAL output gate (from 26 September 2026):** read
`specs/GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md` before collecting or
publishing a Sunday or intermediate. It requires a forward-facing case for
each of the six verdicts, source-specific reasons for material missing data,
weekly positioning with dated COT/ETF/OI evidence, an optional user-triggered
options execution check, a maximum of two intermediates before Friday 00:00
America/New_York, and a closed control handoff when the week is done. These
requirements supplement, and do not replace, the collection and reasoning
manual or the existing six verdicts. Earlier immutable Drive runs are exempt.

This repository contains the canonical instructions for the automated
Gold Sunday Market Story.

## One-off GPT-6 Astra editorial experiment (user-requested, 27 September 2026)

This section applies **only** when the user explicitly requests the separate Astra
Sunday Read experiment. It does not change the automated REAL Sunday/intermediate
pipeline, its schema, validators, four immutable production Output files, active
Drive handoff, or existing backend/frontend contract. Do not route an experimental
artifact through production ingestion or make it the current market state. The
user will decide whether to adapt the application after reviewing the experiment.

For this experiment, the requested analytical endpoint is limited to
**(1) a clear conditional macro directional bias when evidence supports one**
and **(2) whether positioning asymmetry confirms that same direction when
assessing the user's CFD filter**. Do not assess entry timing, entry/exit
levels, stops, technical reward/risk, trade sizing, execution readiness or
whether a setup has appeared. Do not downgrade or withhold a supported macro
bias because any such execution detail is absent. Older canonical fields
about execution or opportunity may be read for their underlying evidence,
but they do not govern this free-form experimental conclusion. Do not copy
execution-readiness or technical payoff labels into the experimental top
thesis, decision panel or final judgment.

GPT-6 Astra: read this README and the current collection, macro reasoning,
forward-decision, family-readout and output specifications in full. Use their
research questions, evidence standards, causal interpretation and honest
uncertainty rules. Take the time needed for primary-source research with an
explicit New York evidence cutoff. Answer all F1-F6 questions, with dated
sources, then reason locally by family and globally. Search obtainable COT,
issuer ETF holdings/flows, comparable futures price/volume/open interest,
funding, physical and structural evidence, relevant exogenous geopolitical
developments and observable marginal/forced actors. For a material missing
observation, identify the exact instrument/measure/date, providers and URLs
tried, retrieval times, the precise publication/access/comparability/method
obstacle, the consequence for the thesis and the next recovery action. Never
invent a measurement or disguise missing evidence as a generic disclaimer.

For this **experiment alone**, there is no predefined JSON output structure:
design a new, rich, readable JSON representation for a future terminal, with
a human report and explanatory audit/run notes. Preserve dated evidence,
resolvable links, F1-F6 questions and answers, reasoning, contradictions,
as-of times, a coherent scenario tree, and all explanations needed for a
reader to inspect every claim. Choose fields based on the user's information
needs; do not force the experimental JSON into the current production schema
or remove evidence to pass current production tests. Describe the proposed
JSON structure and its intended terminal reading order. The later application
migration is a separate task for Codex after user review.

The opening human text must state the **conditional forward thesis** clearly:
bullish, bearish or genuinely unresolved for the upcoming week; its horizon;
the strongest dated economic mechanism and transmission through investor
behavior into Gold; why that case currently outranks the best live contrary
case (or why neither wins); what is already priced; and the next observable
conditions that would strengthen, reverse or invalidate it. Say concretely
under which conditions a bullish idea becomes plausible, under which a
bearish idea becomes plausible, and when to remain undecided. Explain what a
reader should monitor and why. A past Gold move alone cannot forecast another
move. Do not repeat a hollow caution after each conclusion. State the
supported bias directly, give its limits once with reasons, and do not
manufacture conviction when evidence does not support one.

Provide the full reasoning, without compressing it into labels or recycling
the same paragraph across verdicts. Trace the causal chain and the likely
behavior of relevant market participants; distinguish correlated echoes of
one driver from independent confirmation. When a rebound, GLD change, COT
change or price/open-interest combination affects an asymmetry claim, explain
*how* it changes future exposure, who is still positioned, what could make
them act, and the best alternative interpretation. Shrinking historical longs
does not itself establish further forced sales or a larger future decline.
Define technical terms in context, rather than using unexplained shorthand.
Keep macro direction, directional asymmetry and positioning asymmetry
conceptually separate. The absence of a trader-defined entry, stop or technical
reward/risk ratio must not downgrade or alter the macro idea.

Make the scenario tree independently readable. For every branch or selected
node, provide its current evidence, causal path, observable confirmation,
relevant time window, opposing evidence, invalidation and practical
interpretation in ordinary French (and English where useful). Provide enough
content for a terminal to reveal these explanations on selection. Begin with
one coherent narrative; detailed cards, weekly chronology, F1-F6 question
answers, scenario nodes and evidence may follow as progressive detail.

Expiry-specific options IV, skew and gamma/GEX that require a current
contract and trade context belong to the separate user-supplied manual
pre-trade check. Record an available material option signal honestly, but
do not make missing intraday IV/skew/dealer gamma a weekly macro veto or call
unobservable dealer inventory an obtainable source. Continue to seek all
other relevant positioning measurements and document true limitations.

Derive the upcoming week's heading from the week date (Monday through Friday,
America/New_York); distinguish that period from the completed observation
week. Check all headings, dates, units and repeated figures for consistency.
In the Sunday report, compare with the previous week only after independent
current-week reasoning; never copy the old direction.

Add a prominent, compact **"Que puis-je envisager ?" / "What can I consider?"**
decision panel to the experimental Markdown preview, and equivalent structured
JSON content. Apply exactly the user's two fundamental eligibility gates:

- **GC/MGC futures:** a trade direction is fundamentally eligible **if and
  only if** there is a clear, evidence-supported macro directional bias in
  that direction at the relevant horizon. Positioning asymmetry is **not**
  required. If the macro direction is mixed, unclear, stale or contradicted
  by material new evidence, neither long nor short receives a fundamental
  green light until an updated reading resolves it.
- **CFD:** a trade direction is fundamentally eligible **if and only if**
  there is both a clear, evidence-supported macro directional bias **and**
  a positioning asymmetry favoring that **same direction**. If positioning
  is opposite, mixed, unestablished or too stale to assess, do not describe
  that CFD direction as eligible; say which evidence or event could establish
  or reverse the asymmetry. Do not infer remaining future selling solely
  from a past drop in COT longs or GLD shares.

For each instrument show the current answer plainly: long eligible, short
eligible, or neither eligible under these fundamental filters; identify the
dated evidence, mechanism, horizon, strongest contradiction, and the specific
observable change that would flip the answer. Avoid new fundamental vetoes
based on options data, trader-defined entry, stop or technical reward/risk.
Same-day manually supplied options information belongs to a separate
pre-trade check; it is not part of this experimental analysis and is not a
hidden requirement for the futures macro gate or CFD macro-plus-positioning
gate.

The panel reports **only the two requested fundamental filters**, not a
completed order or a guarantee. The trader separately chooses the technical
setup, entry, stop, sizing and risk; the experiment neither grades nor
requests those choices. State the evidence cutoff and a concrete expiry/recheck
condition. A Sunday snapshot cannot certify that its eligibility assessment
still holds "today" after material news or market changes: then require an
updated reading instead of reusing stale permission. Never write "you cannot
trade" when the precise finding is that these fundamental conditions are
unmet or currently unverified. Keep the panel consistent with the six
judgments, scenario tree and human report.

The experimental **Markdown report is the content preview for the future
terminal**, not merely a data dump or a technical README. Write it in the
reading order and with the exact human-facing depth the terminal should
ultimately show: the full opening market thesis, the six judgments with
distinct explanations, what is priced and what may surprise, conditional
bullish/bearish/no-bias paths, then progressively expandable scenario
explanations, dated F1-F6 questions and answers, chronology and evidence.
Make the intended visible headings, paragraphs and optional detail clear in
the Markdown itself. A reader should be able to judge the proposed terminal
experience by reading this file alone. The free-form JSON must contain the
same claims and enough structured, source-linked content to render this
preview faithfully; check Markdown–JSON factual and verdict parity before
delivery. Do not assume the present terminal can render the experimental
format until its backend and frontend have been adapted and verified.

Save the experimental deliverables as **new draft files in a separate Drive
location**, with their own names clearly marked experimental: the complete
JSON, a readable Markdown report, an evidence/validation review, and a run
note. These four artifacts are for human inspection, not the four production
Output files. Do not overwrite historical Drive files, update
`NEXT_GOLD_RECAP.json`, publish a production state or trigger ingestion.
Report which research and factual consistency checks were actually performed
and which claims remain unverified. Do not claim that the current production
schema or application renderer validates the freely designed JSON.

## Two layers: analytical and presentation

The system has two distinct but connected layers.

### ANALYTICAL LAYER
The analytical layer is the canonical reasoning and evidence layer.
It contains the evidence, hypotheses, contexts, priced-in logic,
scenario tree, asymmetry gate, catalysts, invalidations, contradictions,
unknowns, and source audit trail.

This is the authoritative macro reasoning layer.

### PRESENTATION LAYER
The presentation layer is the pedagogical and localized expression of the
same analytical conclusion.

It explains the reasoning in user-friendly French and English without
changing the analytical verdict.

The presentation layer adds:
- localized copy for the upcoming week and market story
- contextual glossary entries for technical terms
- human-readable explanations of market mechanisms
- guided scenario-tree walkthroughs
- user-facing explanation of asymmetry and edge

The analytical conclusion remains canonical. The presentation layer only
translates and teaches it.

## Canonical files

## Canonical execution entrypoint

This README is the only entrypoint a Work needs. Before collecting, reasoning,
writing, validating, or publishing anything, it MUST read the following files
in this order and in full: (1) this README, (2) Collection & Evidence, (3)
Macro Reasoning Manual, (4) Output Spec, (5) Run Protocol, (6) Presentation
V3 historical contract and V4 production extension, (7) Procedural Audit,
(8) Continuous Recap Protocol, (9) Next Recap Handoff Spec, (10) Family Readout
and Evolution Spec, and (11) Intermediate Narrative Contract for intermediates.
The automation
prompt must remain minimal; durable business logic belongs in these files, the
schema, and validators—not in a copied prompt.

Ownership is: collection = Collection & Evidence; reasoning = Macro Reasoning
Manual; output = Output Spec; presentation = Presentation Spec; execution =
Run Protocol; audit = Procedural Audit; rolling lineage = Continuous Recap;
handoff = Next Recap Handoff Spec. On a contradiction, use this precedence:
explicit safety/semantic validation rule, schema, the owning specification,
then this README; stop before publication if those layers cannot be aligned.
The current validator is a publication gate, but no mandatory rule may exist
only in its code. Run `npm test` and `npm run validate` before publication.
Never run real production merely to test this repository.

For new REAL outputs generated from 2026-09-25 00:00 America/New_York onward,
`specs/GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md` defines the additive
Sunday question/answer and cross-week bridge, intermediate evolution, and
version 7+ continuity handoff contract. It does not amend the collection
questions or replace the macro interpretation method. Historical Drive
snapshots are not rewritten or deleted.

### Collection
`specs/GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md`

Defines:
- Weekly Gold Recap
- F1 Fed & rate pricing
- F2 Rates & real yields
- F3 USD & liquidity
- F4 Inflation/growth/fiscal/credit
- F5 Flows & positioning
- F6 Structural
- sourcing rules
- evidence rules
- ownership rules
- UNKNOWN/PARTIAL handling

### Source Recovery

`specs/GOLD_SUNDAY_READ_SOURCE_RECOVERY.md`

Advisory fallback source map for difficult-to-source evidence.

It is consulted only when normal web research leaves a required field UNKNOWN or PARTIAL.

It is NOT a mandatory provider list and does not override the Collection & Evidence Spec.

### Reasoning
`specs/GOLD_MACRO_REASONING_MANUAL_SUNDAY.md`

Defines how collected evidence must be connected:
- competing hypotheses
- causal chains
- cross-asset reality test
- dominant driver
- regimes and horizons
- priced-in analysis
- asymmetry
- scenario reasoning
- invalidations
- presentation handoff

### Output
`specs/GOLD_SUNDAY_READ_OUTPUT_SPEC.md`

Defines the required final Sunday Read:
- upcoming-week preparation
- market story of the completed week
- current setup
- contexts by horizon
- what is already priced and what can still surprise
- scenario tree and guided textual reading
- asymmetry / edge explanation
- catalysts
- invalidations, contradictions, anomalies, unknowns
- evidence and source drilldown
- machine-readable JSON
- French + English localized presentation (V3 contract, see below)
- contextual glossary and scenario walkthrough

### Run protocol
`specs/GOLD_SUNDAY_READ_RUN_PROTOCOL.md`

Defines how a Sunday Read run itself must be executed: phases, checkpoints,
resumability, source deduplication, and the presentation and handoff steps
that must run only after the analytical Sunday state has validated.

### Continuous recap protocol
`specs/GOLD_CONTINUOUS_RECAP_PROTOCOL.md`

Defines the Gold system as a rolling analytical state rather than a sequence
of independent reports: the Sunday/intermediate lineage, the mandatory F1–F6
audit on every intermediate recap, exogenous-factor scanning, scenario
transition states, and the separation between macro direction, directional
asymmetry, positioning asymmetry and final edge.

### Intermediate narrative contract
`specs/GOLD_INTERMEDIATE_NARRATIVE_CONTRACT.md`

Requires every new REAL intermediate run to explain its changes since the parent in French and English, with resolvable evidence references. The run protocol loads it and `tools/validate.mjs` enforces it for runs generated from 25 September 2026 onward; historical snapshots remain valid.

### Procedural audit
`specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md`

Makes it verifiable that a Sunday or intermediate run actually executed its
mandatory phases, in a possible order, with an outcome or an explicit
limitation for every mandatory question. It records procedure, never private
reasoning, and imposes no volume threshold (no minimum sources, facts, nodes,
length, score or vote). It defines what a trace proves and cannot prove, the
difference between an unknown result and an omitted step, and the Sunday versus
intermediate proofs. Required for new `REAL` runs; historical documents are
unaffected.

### Next-recap handoff spec
`specs/GOLD_NEXT_RECAP_HANDOFF_SPEC.md`

Defines `NEXT_GOLD_RECAP.json`, the operational handoff written at the end of
every validated run to instruct the next intermediate recap. It is never a
report, a frontend payload or an analytical conclusion.

### Presentation V3 spec
`specs/GOLD_PRESENTATION_V3_SPEC.md`

Defines the human-facing presentation contract that succeeds V2: plain
display copy plus structured `glossary_refs`/`annotations` instead of inline
`[[GLOSSARY_ID|text]]` markup, and a standalone-readable diagram contract
where every node and edge carries its own natural-language display copy.

### Schemas
- `schema/sunday_read.schema.json` — the Sunday and intermediate market-state
  document schema (extended, not replaced, for V3 and rolling-lineage
  fields; historical V1/V2 documents remain valid).
- `schema/next_gold_recap.schema.json` — the `NEXT_GOLD_RECAP.json` handoff
  schema.
- `schema/run_completion_record.schema.json` — the control-plane record written
  last by a run, sealing validation, Drive readback and the handoff write. It
  lives in the Control folder, is not one of the four immutable Output files, has
  `frontend_eligible: false` and must be ignored by market-state ingestion (see
  the procedural audit spec, section 13).

### Positioning asymmetry contract

Chapter 21 already contained the conceptual method: COT percentiles, price/OI,
ETF flows, Gold call-skew, FOMO versus event premium, dated catalysts,
`FORTE / MOYENNE / FAIBLE / PIÈGE`, SGE divergence and funding/fuse reasoning.
This update makes those ideas auditable rather than repeating them as prose.

New documents MUST opt into `analysis_contract.version: 1` — this is a hard
requirement for every new REAL Sunday and intermediate run, not a model choice,
and a new production file may not silently fall back to the pre-contract shape.
The contract records structured COT identity/lag/percentiles, price/OI, ETF
confirmation, price/IV, Gold's own skew baseline, gamma epistemic status, SGE
comparability, funding/forced-flow and fuse evidence, dated catalyst,
invalidation, opportunity quality and execution readiness.
`direction_state.edge` remains the final edge; quality is not a score and
readiness is not positioning asymmetry.

The requirement is enforced structurally: any document carrying `meta.run_type`
(a rolling-state production run) must carry `analysis_contract` plus the full
contract field set, in the schema and in `tools/validate.mjs`. Historical
documents carry no `meta.run_type`, so they remain valid without the contract.
The run-protocol gates for this are in
`specs/GOLD_SUNDAY_READ_RUN_PROTOCOL.md` §6B, and the reasoning integration is
in `specs/GOLD_MACRO_REASONING_MANUAL_SUNDAY.md` §21.7.

Sunday Reads and intermediate recaps use the same contract. Intermediate states
keep prior-week narrative immutable and refresh the checkpoint evidence. Handoff
version 2 and later carries those scenario-specific asymmetry checkpoints and
remains control-plane JSON, never frontend content. Historical V1/V2/V3
documents remain valid because the contract requirement is keyed on the presence
of `meta.run_type`, which no pre-lineage document sets.

## Validation and CI
`npm run validate` runs the JSON-Schema layer plus the protocol-level checks
(identifiers, glossary and graph references, analytical/presentation parity,
FR/EN parity, chronology, lineage, contract opt-in and contract semantics, and
the procedural audit). `npm run test:negative` runs the deterministic negative
matrix in `tests/negative_validator_smoke.mjs`. `npm run test:procedural` runs
`tests/procedural_audit.test.mjs`. `npm test` runs everything.

To check a real run, pass its files: `node tools/validate.mjs <state.json>
<completion_record.json>`. A `REAL` state without its completion record fails.

A minimal GitHub Actions workflow (`.github/workflows/validate.yml`) runs
`npm ci`, `npm run validate` and `node tests/negative_validator_smoke.mjs` on
every push and pull request, using the Node LTS line. It uses no secrets and
adds no production dependencies.

Positive fixtures A–G under `tests/fixtures/` exercise a strong bullish
opportunity, a bullish macro story with a positioning trap and no edge, a
bearish vulnerability waiting for a catalyst with no edge, options/gamma
UNKNOWN without fabrication, price up with IV up classified as an event premium,
an intermediate transition from its parent state, and a handoff carrying
updated asymmetry checkpoints. They are generated deterministically by
`node tests/fixtures/build_positive_fixtures.mjs`.

Source recovery remains primary-source-first. ETF.com is an optional secondary
ETF-flow recovery source and Finviz is an optional news-discovery surface; they
must not replace official issuer or original event sources, and neither is
forced into every run.

The external trading application is not part of this repository. It must update
ingestion/API/frontend types to carry `opportunity_quality` and
`execution_readiness`, render localized labels and explanations, preserve the
four direction/asymmetry fields plus final edge, and never expose raw enum or
scenario IDs. No application repository was modified here.

## Sunday initialization, intermediate updates and rolling-state lineage

A full corrective Sunday rebuild performed on Monday is allowed only under
`specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md` §11. It keeps the prior Friday
weekly market cutoff separate from the later evidence cutoff and dates
post-week context explicitly. The exceptional run replaces the displayed
current state only after complete validation and publication; it does not
rewrite the previous run.

The Gold system is a rolling analytical state, not a sequence of unrelated
reports.

- **Sunday initialization**: every Sunday run produces an immutable Sunday
  market-state JSON (`meta.run_type = SUNDAY`, `meta.parent_run_id = null`,
  `meta.origin_sunday_run_id` equal to its own `run_id`), the human-readable
  Sunday report, and one `NEXT_GOLD_RECAP.json` handoff for the first
  intermediate recap of the week.
- **Intermediate updates**: an intermediate run always begins from the latest
  validated market state, never from the prior Sunday if a newer intermediate
  state exists. It audits F1–F6, treats only post-cutoff material as new
  evidence, reapplies the full reasoning and asymmetry process, and produces
  a new immutable intermediate market-state JSON plus a replacement
  `NEXT_GOLD_RECAP.json`.
- **Rolling lineage**: every market-state document carries `run_id`,
  `run_type`, `parent_run_id`, `origin_sunday_run_id`,
  `evidence_cutoff_start` and `evidence_cutoff_end`, so the full chain from
  any given state back to its origin Sunday run is always reconstructible.

Operational handoff JSON (`NEXT_GOLD_RECAP.json`) is never frontend content.
It carries `document_type: "NEXT_GOLD_RECAP_HANDOFF"` and
`frontend_eligible: false`, and the frontend must never render it as the
current Sunday or intermediate read. Only documents carrying
`document_type: "GOLD_MARKET_STATE"` and `frontend_eligible: true` are
eligible for display.

`next_execution` may provide localized public schedule copy with `reason_fr`,
`reason_en`, `minimum_confirmation_delay_fr`, and
`minimum_confirmation_delay_en`. These fields are optional so historical
handoffs remain valid; consumers fall back to `reason` and
`minimum_confirmation_delay`. Only the safe, localized schedule summary may
be exposed through the public next-recap route, never the handoff itself.

## Fundamental rule

Collection and reasoning are separate phases.

Never begin with a bullish or bearish conclusion and search for evidence
to support it.

Phase A establishes evidence.

Phase B reasons from that evidence.

Missing information remains UNKNOWN.

A clear macro story does not automatically imply a tradable edge.

BULLISH or BEARISH requires the asymmetry gate.

NO EDGE is a valid final result.

## Presentation contract

New production runs must include a V3 presentation layer in both French and
English, per `specs/GOLD_PRESENTATION_V3_SPEC.md`. The output must preserve
the same analytical conclusion across both locales. Historical V1/V2
documents remain schema-valid; V3 is required only for new runs.

The user-facing presentation must:
- be final French and English copy ready to render directly;
- never expose the run's scenario node or edge IDs in prose; keep those IDs only in structured reference fields;
- never contain raw `[[GLOSSARY_ID|visible text]]` markup; use plain display text plus structured `glossary_refs` or `annotations` instead;
- give every displayed scenario node and edge full standalone display copy (title/body/why-it-matters/confirmation-needed for nodes; a causal label and explanation for edges) so the diagram reads without opening node details or the walkthrough;
- separately expose macro direction, directional asymmetry, positioning asymmetry and final edge — never conflate direction with edge;
- explain technical terms with contextual glossary references
- teach the transmission mechanism in plain language
- include a market story spanning the reviewed week and the upcoming week
- preserve the analytical scenario tree while adding a standalone-readable guided textual reading
- explain asymmetry without converting it into a buy/sell signal

## V3 analytical-to-presentation coverage

For new `REAL` Sunday or intermediate V3 market states, validation measures
coverage, not length. No minimum number of nodes, branches, paragraphs, or
words exists: a short tree is valid when it faithfully localizes every
material analytical item. An item is material when it is deliberately part of
the analytical scenario topology, a retained scenario branch, or a populated
required analytical section. A long presentation fails if it omits one.

Both locales must provide final, independently renderable copy for the market
story, three horizons, priced-in analysis, asymmetry, direction state, tree,
and walkthrough. Every analytical node, displayed relation, and retained
scenario branch must resolve to French and English V3 copy. French may use
accepted market terms such as `FOMC`, `COT`, `DXY`, `Gold`, `skew`, or
`gamma`, but may not silently fall back to English sentences. The frontend
must never infer missing French copy from English or analytical fields.

## Important

## Manual edge check

Demo / fixture values from the application are NOT market evidence.

Always use current web research for a real Sunday run.
