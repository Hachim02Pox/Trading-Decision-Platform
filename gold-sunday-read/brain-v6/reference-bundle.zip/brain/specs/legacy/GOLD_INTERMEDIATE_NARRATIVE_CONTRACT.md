# Intermediate narrative contract

For new REAL intermediates generated from 2026-09-25 00:00
America/New_York, also publish the parent-specific `evolution_review` and
version 7+ next-run continuity checkpoint defined in
`GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md`. This supplements rather than
replaces the required `intermediate_summary`.

For each REAL intermediate state generated on or after 2026-09-25T00:00:00Z,
Work MUST emit the `intermediate_summary` object in addition to the analytical fields. It is
deliberately optional in the schema so immutable historical snapshots remain
valid, but it is the canonical presentation input for future readers.

The object is anchored to `parent_run_id`, never to a similarly named file.
Each FR/EN narrative has at least one resolvable evidence reference and answers a separate question:
what was observed after the parent cutoff; what changed; what remains true;
what is unknown and why; what to watch next; and the decisive limit. A change
in a judgment includes its prior and current reading, the dated reason, and
the practical consequence for Gold.

Unknowns must state whether the data is awaiting publication, was not
reliably recovered, or is not comparable. Do not call an unavailable datum a
contradiction. Localized presentation, walkthrough, and scenario-tree copy
must be rewritten whenever the current verdict differs materially from the
parent: inherited Sunday prose cannot be reused as an explanation of a new
state. Every branch claim must remain consistent with the current verdict,
its dated evidence, and its stated invalidation.

No field may contain implementation codes, status-only prose, or a placeholder
such as “localized explanation not published”. The reader can fall back to
historical analytical facts when this object is absent, but a new production
run must publish both languages.

Run `node tools/validate.mjs` before publication. The validator requires the
summary for future REAL intermediate states, checks the parent run ID against
`meta.parent_run_id`, checks both languages and resolves every evidence ID.
When the parent snapshot is available, it also requires an explanation for
each of the six judgments whose raw value changed. The snapshot dated
2026-09-24 and older runs remain valid without this field.

## Missing-data explanations for each new REAL intermediate

Work must publish `intermediate_summary.unknown_reasons[]` in FR and EN. For each material missing observation (at least every unknown current real yield, post-event COT, comparable current futures open interest, options IV, comparable skew, and dealer gamma that affects a judgment), record:

- `topic` and a readable FR/EN `label`;
- `reason_kind`: `AWAITING_PUBLICATION`, `SOURCE_NOT_RETRIEVED`, `SOURCE_INACCESSIBLE`, `COMPARABILITY_FAILED`, `METHODOLOGY_NOT_VERIFIED`, `STRUCTURALLY_UNOBSERVABLE`, or `CAUSE_UNDETERMINED`;
- FR/EN `explanation` naming the exact unavailable measurement and the reason that is actually supported;
- FR/EN `checked` naming the source, date, comparable instrument and recovery attempt actually checked, or explicitly stating which check was not possible;
- FR/EN `next_action` telling the reader what can resolve the gap;
- `expected_at` only for a verified future publication, with a supporting evidence reference; other gaps must not acquire invented dates;
- any resolvable `evidence_refs`. An empty array is allowed when no evidence was found; never fabricate a citation.

An unknown must not be collapsed into a generic “missing” label. If research cannot establish whether the problem is absence of a source, restricted access or comparability, use `CAUSE_UNDETERMINED`, say precisely what was tried, and state that the specific cause cannot be confirmed. A publisher’s reporting lag is distinct from a data-recovery failure. Dealer gamma sign cannot be deduced without an explicit, tested dealer-positioning methodology; the absence of a verified model is a methodology gap, not a bearish or bullish observation. If a scheduled COT is not yet published, identify the measurement date of the last available report and the supported time of the next publication.

## Direction is an as-of judgment, not a price extrapolation

Publish `intermediate_summary.macro_reading` in FR and EN with four sourced parts: `observed`, `causal_assessment`, `forward_conditions`, and `invalidation`. In `observed`, separate the price move, dollar, flows and time windows. In `causal_assessment`, explain which economic transmission has evidence, which alternative mechanisms remain live, and which link cannot be confirmed. A falling Gold price alone cannot establish that real yields caused it, cannot guarantee another decline, and cannot prove an actionable short edge. `forward_conditions` must describe conditions under which bearish or bullish pressure would persist after the cutoff, and `invalidation` must state what observation would reverse the reading. Present these conditional statements as tests rather than as facts about the future.

The `direction_state` remains the interpretation supported at the evidence cutoff. Re-run collection, competing hypotheses, causal transmission, cross-asset reality test, positioning and edge gates exactly as in `GOLD_MACRO_REASONING_MANUAL_SUNDAY.md`. Do not promote a mechanically falling price or a single coincident indicator into a forecast. The schema leaves these fields optional for immutable archives; `tools/validate.mjs` requires and checks them on every new REAL intermediate.
