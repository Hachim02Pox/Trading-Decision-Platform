# GOLD SUNDAY READ — OUTPUT SPEC

For new REAL runs from 2026-09-25 00:00 America/New_York, follow
`GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md` for additive V5 front-end fields:
`family_readouts`, `global_synthesis` and `weekly_bridge` on Sunday,
`evolution_review` on an intermediate, and a version 7+
`continuity_checkpoint` in the active handoff. The existing canonical
evidence, six verdicts, positioning contract, scenario tree, V4 presentation
and archive validation remain in force. A falling Gold price is a dated fact,
not the independent economic mechanism justifying a conditional future bias.

## 9.2 Opportunity quality and execution readiness

New contract documents display five separate ideas: macro direction, directional
asymmetry, positioning asymmetry, `Qualité de l’opportunité` and execution
readiness, followed by the final edge. Quality is qualitative, never a score:
`FORTE / MOYENNE / FAIBLE / PIÈGE / INCONNUE` (English: `STRONG / MEDIUM /
WEAK / TRAP / UNKNOWN`). Readiness answers whether a dated catalyst or
observable activation mechanism and a measurable invalidation exist. A crowded
long market can therefore be macro bullish, `PIÈGE`, `NOT_READY` and `NO_EDGE`.

French and English copy must explain who appears positioned, whether capital is
entering or closing, ETF/physical confirmation, options and event premium,
forced-actor evidence, activation, invalidation and why the final edge is
bullish, bearish or no edge. Raw enum tokens and internal scenario IDs never
appear in localized prose.
# GOLD SUNDAY READ — OUTPUT SPEC

> **Role of this file**
>
> This document defines **what the final automated Sunday Read must look like for the human user**.
>
> It comes after:
>
> 1. `GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md`
> 2. `GOLD_MACRO_REASONING_MANUAL_SUNDAY.md`
>
> The first file tells the research system **what to collect**. The second tells the reasoning model **how to think about the evidence**. This file tells the system **how to communicate the final result**.
>
> The output must be rigorous enough for professional reasoning but understandable by a user who is still learning finance and macro.
>
> **Truth comes before beauty.** Visuals and diagrams exist to make the reasoning inspectable, not decorative.

---

# 0. Presentation architecture (V3 contract)

> **Migration note.** This section defines the V3 human-facing presentation
> contract, which supersedes the V2 contract for all new production runs.
> The full V3 rules live in `GOLD_PRESENTATION_V3_SPEC.md`; this section
> summarizes and integrates them into the output spec. Historical V1 and V2
> documents remain schema-valid and are not retroactively invalidated —
> `sunday_read.schema.json` extends rather than replaces its prior shape, and
> `presentation.version` may still be `2` on older documents. Nothing in this
> migration changes any analytical conclusion; it changes only how the
> conclusion is expressed to a human reader.

## V4 production presentation contract

For a new REAL state the final output uses `presentation.version: 4`; V1-V3
remain historical compatibility formats. The authoritative field lists are in
`GOLD_PRESENTATION_V3_SPEC.md` section 0 and are enforced by
`tools/presentation-coverage.mjs`: six separate verdicts with their nine
fields; three conditional cases (bullish, bearish, no edge); all three
horizons; chronology and causal assessment; localized exact annotations; and
one `already_priced_analysis` per `already_priced` item, in the same order.
Do not suppress difficult data, `glossary_refs`, annotations, or priced-in
items to obtain a passing output. Use explicit UNKNOWN, PARTIAL,
PUBLICATION_LAG or NOT_APPLICABLE where the contract permits.

For new REAL intermediates, `intermediate_summary.unknown_reasons` explains why each material datum is missing, what was checked and what resolves it; `macro_reading` distinguishes the current observation from causal interpretation and conditional future tests. These fields follow `GOLD_INTERMEDIATE_NARRATIVE_CONTRACT.md`. An unknown reason must be explicitly undetermined if source access, timeliness or comparability cannot be distinguished after the research. The current bearish or bullish interpretation is an as-of judgment, not a trade signal or a promise of the next price move.

The final output is layered.

1. The analytical JSON remains canonical.
2. The presentation layer is a second layer that explains the same conclusion in French and English.
3. Presentation never changes the analytical conclusion or creates a new interpretation.

This means:
- `executive_narrative`, `contexts`, `priced_in`, `scenario_tree`, `scenario_explanations`, `asymmetry`, `catalysts`, `evidence`, and `sources` remain the audit and reasoning layer.
- `presentation` and `glossary` provide the human-facing explanation layer.
- If the analytical conclusion is `NO_EDGE` in French, it must also be `NO_EDGE` in English.
- Localization must not create semantic drift.

## 0.1 Required user-facing framing

The final human UX is not a weekly recap headline. The main framing is the upcoming-week macro preparation.

Preferred naming:
- French: `Préparation macro de l'or`
- English: `Gold Macro Setup`

The top-level framing should center on:
- `UPCOMING WEEK PREPARATION`
- `PAST-WEEK MARKET STORY`
- `CURRENT SETUP`
- `FUTURE SCENARIOS`

The reviewed week remains contextual metadata for the market story, not the dominant headline.

## 0.2 Reading order for V2

The default reading order is:

1. Preparation for the upcoming week
2. Market story of the completed week
3. Current setup
4. Contexts by horizon
5. What is already priced / what could still surprise
6. Consolidated scenario tree
7. Guided textual reading of the same tree
8. Opportunity / asymmetry explanation
9. Material catalysts
10. Invalidations / contradictions / anomalies / unknowns
11. Human-readable source drill-down when requested

The main page should not show raw audit metadata, raw enum labels, or machine-only internal strings in the UI copy.

## 0.3 Presentation copy rules

For every human-facing paragraph and card:
- explain the mechanism in plain language;
- explain why the fact matters here;
- use inline glossary references for technical concepts when they could confuse a macro beginner;
- avoid exposing internal field names like `REAL`, `PARTIAL`, `STATE`, or `DRIVER` as user copy;
- keep analytic certainty and teaching separate.
- use complete sentences, natural causal transitions, and explicit why-it-matters context;
- do not use compressed analyst shorthand when it harms comprehension. Preserve the real concepts and numbers, but explain the mechanism.

### 0.3.1 No internal graph identifiers in human copy

Canonical graph identifiers remain available for machine referencing only.
They may appear in structured fields such as `node_id`, `edge_id`,
`node_refs`, `edge_refs`, and `branch_node_ids`, but they must never appear
in human-facing presentation prose. This includes titles, subtitles, market
story fields, horizon fields, priced-in and surprise explanations, scenario
labels and descriptions, walkthrough text, asymmetry presentation, and any
other localized copy.

For every material scenario node displayed to the user, provide a natural,
localized human label. For every displayed edge, provide a localized label
or explanation that states the economic meaning and why the transition
matters. Do not merely translate an enum or code identifier.

Legitimate market terminology such as `FOMC`, `SEP`, `DXY`, `COT`, `OI`,
`GVZ`, `2Y`, `10Y real`, `gamma`, and `skew` may remain visible when it is
the correct term, but explain it naturally or resolve it through the
contextual glossary. Internal identifiers such as `N-ROOT`, `N-FED`, `N-PATH`,
`L1`, and `L12` have no educational value and must not be shown.

### 0.3.1a V3: no inline glossary markup, standalone node/edge display copy

V3 forbids the inline syntax described in 0.3.2 below as literal text inside
any rendered field. The syntax `[[GLOSSARY_ID|visible text]]` must never
appear in the delivered JSON's human-facing strings. Instead:

- attach a `glossary_refs` array of glossary IDs alongside the plain display
  text field it relates to; or
- when exact term placement inside a sentence matters, use an `annotations`
  array of `{ "visible_text": "...", "glossary_id": "..." }` objects next to
  the plain text field.

The rendered text itself is always plain, final copy with no markup for the
frontend to strip or parse.

Every displayed scenario node must carry, in `presentation.<locale>.scenario_tree_v3.nodes[]`:
`node_id` (structured reference only), `display_title`, `display_body`,
`why_it_matters`, `confirmation_needed`, `display_status`, `display_category`,
and optional `glossary_refs`. Every displayed edge must carry, in
`presentation.<locale>.scenario_tree_v3.edges[]`: `edge_id`, `from_node_id`,
`to_node_id` (structured references only), `display_label`,
`display_explanation`, and `confirmation_needed`. An arrow without a human
causal label is not valid V3 presentation. See `GOLD_PRESENTATION_V3_SPEC.md`
for the full contract, including the human-status vocabulary and the
requirement that macro direction, directional asymmetry, positioning
asymmetry and final edge be displayed as separate, non-conflated fields in
`presentation.<locale>.direction_state`.

### 0.3.2 Standalone guided walkthrough

The guided walkthrough must remain readable from top to bottom when the
diagram is hidden. It must explain where the market currently stands, what is
being watched next and why it matters, where the economic scenarios branch,
what each branch means, which market variables should react first, what would
confirm or contradict each branch, why flows and positioning matter, why the
asymmetry gate exists, and why the current result is bullish, bearish, no
edge, or unresolved.

The walkthrough must follow the graph faithfully without discussing graph
mechanics. Explain what is happening and why, not which internal node
connects to which internal node.

Legacy V2 inline syntax (not permitted in V3, see 0.3.1a):
- `[[GLOSSARY_ID|visible text]]`

Example (French, V2 only): `[[REAL_YIELD|taux réels]]`
Example (English, V2 only): `[[REAL_YIELD|real yields]]`

V3 walkthrough steps use plain `text` plus an optional `glossary_refs` /
`annotations` array on the step, exactly as described in 0.3.1a.

Every referenced glossary ID must exist.

## 0.4 New presentation object contract

New production runs must provide a `presentation` object with `version: 3`,
equivalent to:

```json
{
  "presentation": {
    "version": 3,
    "scope": {
      "reviewed_week_start": "2026-09-07",
      "reviewed_week_end": "2026-09-11",
      "upcoming_week_start": "2026-09-14",
      "upcoming_week_end": "2026-09-18"
    },
    "fr": {
      "title": "Préparation macro de l'or",
      "subtitle": "Semaine du 14 au 18 septembre 2026",
      "direction_state": { "macro_direction": {}, "directional_asymmetry": {}, "positioning_asymmetry": {}, "edge": {} },
      "scenario_tree_v3": { "nodes": [], "edges": [] }
    },
    "en": {
      "title": "Gold Macro Setup",
      "subtitle": "Week of 14 to 18 September 2026",
      "direction_state": { "macro_direction": {}, "directional_asymmetry": {}, "positioning_asymmetry": {}, "edge": {} },
      "scenario_tree_v3": { "nodes": [], "edges": [] }
    }
  }
}
```

The canonical analytical JSON remains unchanged. The presentation layer is
explanatory only. `presentation.version == 2` remains valid for historical
documents produced before this migration; `sunday_read.schema.json` accepts
both, and only requires `direction_state` / `scenario_tree_v3` when
`version == 3`.

---

# 0. Audience rule

The reader is intelligent but still a **finance / macro amateur**.

Therefore:

- keep the real financial vocabulary;
- keep the real data and numbers;
- do not replace precise concepts with vague simplifications;
- explain unfamiliar terms in plain French when they matter;
- explain **why a fact matters here**, not only what the fact is;
- avoid assuming the reader already understands the transmission mechanism;
- do not drown the reader in jargon without explanation;
- do not over-vulgarize to the point of deleting nuance.

Good style:

> Le 2Y a baissé de 14 bp, ce qui signifie que le marché demande désormais un rendement plus faible sur la partie courte de la courbe. Comme le 2Y reflète fortement les attentes de politique monétaire, ce mouvement est cohérent avec un repricing plus dovish de la Fed.

Bad style:

> 2Y -14 bp = bullish Gold.

Bad style:

> Les taux ont baissé donc l’or monte.

The output must **teach while analysing**.

---

# 1. Reading order

The final Sunday Read should be read progressively.

For the V2 presentation layer, the default order is:

1. **Preparation for the upcoming week**
2. **Market Story of the completed week**
3. **Current setup**
4. **Contexts by horizon**
5. **What is priced / what could still surprise**
6. **Consolidated scenario tree**
7. **Guided textual reading of the same tree**
8. **Asymmetry / edge explanation**
9. **Material catalysts**
10. **Invalidations, contradictions, anomalies, and unknowns**
11. **Evidence / source drill-down when requested**

The user should be able to understand the week in roughly 60–120 seconds from the top section, then inspect progressively deeper layers.

---

# 2. Block 1 — Global explanatory recap / market story

This is the first thing the user sees.

It is not a bullet dump.

It is a **coherent explanatory narrative** written in clear French or English and must explain both the completed week and the current setup.

The V2 presentation should separate three distinct ideas:

- `past_week`: what happened over the reviewed week;
- `current_setup`: where the market is now after that week;
- `week_ahead`: what matters next and what the coming week is waiting for.

This should combine:

- what happened Monday → Friday;
- the important changes discovered in the six families;
- the current market setup;
- the main causal links the reasoning model considers credible;
- what is still uncertain;
- what materially matters for the coming week.

It should explain:

- what happened;
- why the market appears to have reacted that way;
- which driver(s) seem to matter;
- which observations are independent vs echoes of the same driver;
- what does not fit the story;
- whether the market looks clean, conflicted, or unresolved.

The top narrative should synthesize the week into a **story a human can understand**.

The system must remain explicit when causal confidence is limited.

Allowed language:

- “the data are consistent with…”
- “the market seems to be responding mainly to…”
- “the most convincing explanation currently is…”
- “this link remains uncertain…”
- “two readings remain possible…”

Forbidden language when evidence is weak:

- “X caused Y” without support;
- “Gold will definitely…”;
- “the market thinks…” without evidence;
- invented certainty.

The user-facing text may reference glossary terms such as `[[REAL_YIELD|real yields]]`, `[[SEP|SEP]]`, or `[[FISCAL_RISK|fiscal risk]]` where needed, but it should not expose raw internal fields or metadata as human copy.

---

# 3. Block 2 — Contexts by horizon

Display three real cards.

## TACTICAL

**Horizon:** minutes → days

Must answer:

1. **Orientation Gold:** `BULLISH / BEARISH / MIXED / UNCLEAR`
2. **Why:** short pedagogical explanation
3. **Evidence:** material facts supporting the view
4. **Competing thesis:** strongest alternative interpretation / counterargument
5. **Invalidation:** what observable development would make this tactical reading wrong

The tactical card answers:

> What is the market responding to now / this week?

## MEDIUM TERM

**Horizon:** days → weeks

Must answer:

1. **Orientation Gold:** `BULLISH / BEARISH / MIXED / UNCLEAR`
2. **Why**
3. **Evidence**
4. **Competing thesis**
5. **Invalidation**

The medium-term card answers:

> What repricing / positioning trend is currently developing?

## STRUCTURAL

**Horizon:** months → years

Must answer:

1. **Orientation Gold:** `BULLISH / BEARISH / MIXED / UNCLEAR`
2. **Why**
3. **Evidence**
4. **Competing thesis**
5. **Invalidation / structural weakening condition**

The structural card answers:

> What slow background remains in force?

Do not force the three horizons to agree.

Valid example:

- Tactical: bearish
- Medium: mixed
- Structural: bullish

A context may also be:

- hybrid;
- transitional;
- no clear regime.

---

# 4. Block 3 — What is priced / what would still be a surprise

This block exists because the market trades **expectations**, not raw facts.

It must answer:

### Already priced

What expectations appear substantially embedded in current market pricing?

Examples:

- next-FOMC pricing;
- expected CPI direction;
- widely expected fiscal / geopolitical development;
- already crowded positioning.

### Still capable of surprising

What new information would materially change expectations?

For each material surprise candidate, state:

- expected / baseline;
- surprise condition;
- likely first transmission channel to watch;
- which scenario branch it would affect.

Do not invent consensus numbers if they were not established during research.

If the system cannot reliably determine what is priced:

`UNKNOWN / PARTIAL`

is valid.

---

# 5. Block 4 — The scenario tree

This is the central visual object of the final Sunday Read.

## 5.1 One consolidated tree

Prefer **one consolidated tree with a shared trunk** and several branches.

Do not create several unrelated diagrams that duplicate the same evidence.

The shared trunk contains what is already established.

Branches begin where the future path or causal interpretation genuinely diverges.

## 5.2 No imposed number of scenarios

The model may produce:

- one currently dominant path;
- two branches;
- three branches;
- more if genuinely required.

Never create “bull / base / bear” merely to fill space.

Never impose a fixed number.

## 5.3 Every node must have a real meaning

A node may represent:

- an established fact;
- a current state;
- a future catalyst;
- a condition waiting to be resolved;
- a positioning constraint;
- a funding constraint;
- an options condition;
- an asymmetry test;
- a final terminal state.

Each node should expose a status where appropriate:

- `CONFIRMED`
- `WATCH`
- `PENDING`
- `UNKNOWN`
- `CONTRADICTED`

`UNKNOWN` is not the same as `PENDING`.

### UNKNOWN

We do not know / cannot measure it reliably.

### PENDING

The information or event has not happened yet.

### CONTRADICTED

Observed evidence currently conflicts with the condition.

## 5.4 Missing-node visualization

If a scenario cannot yet be validated because one material input is missing, **show the missing node**.

Do not hide uncertainty.

Example:

```text
Soft labor trend
      ↓
Fed pricing dovish
      ↓
2Y / real yields lower
      ↓
USD weak
      ↓
ETF inflows ?
[ PENDING / UNKNOWN ]
      ↓
ASYMMETRY TEST
      ↓
BULLISH
```

The unresolved node should visually contrast with confirmed nodes.

## 5.5 Branch logic

A branch can split around a future variable.

Example:

```text
              CPI
               ?
        ┌──────┴──────┐
        │             │
      SOFT           HOT
        │             │
Fed pricing ↓     Fed pricing ↑
        │             │
real yields ↓    real yields ↑
        │             │
USD ↓            USD ↑
        │             │
...
```

Once the evidence only supports one path, the current Sunday output may emphasize that path.

The Sunday Read does not need to preserve dead branches for historical display.

---

# 6. Mandatory asymmetry gate

A directional Market Story is **not sufficient**.

Before a scenario can terminate in `BULLISH` or `BEARISH`, it must pass through an **ASYMMETRY / EDGE** node.

The asymmetry analysis may include, where relevant:

- COT;
- open interest;
- ETF flows;
- options / GVZ / skew;
- funding;
- forced buyers / forced sellers;
- fuses;
- marginal flow;
- crowded consensus;
- physical confirmation / divergence;
- how much of the move has already occurred;
- positioning vulnerability.

The key question:

> Even if the directional story is correct, is there still a useful asymmetry left?

Possible terminal outputs:

- `BULLISH`
- `BEARISH`
- `NO EDGE`

`NO EDGE` is a first-class valid result.

Example:

```text
Macro story = bullish
+
everyone already long
+
options show FOMO
+
ETF inflow slowing
+
price already extended

→ NO EDGE
```

Do not convert a correct macro direction into a trade recommendation when the asymmetry is poor.

---

# 7. Scenario summary text

Each major branch / scenario should have a short human-readable paragraph above or beside the diagram.

It should explain:

- what the scenario means;
- why it exists;
- the central chain;
- what still needs to happen;
- what would kill it.

Do not repeat every node from the diagram in prose.

The prose explains the **logic**.

The diagram exposes the **mechanics**.

---

# 8. Final scenario terminals

The final directional box is placed at the **bottom/end of the scenario path**, not at the top.

Preferred visual semantics:

- `BULLISH` → positive terminal
- `BEARISH` → negative terminal
- `NO EDGE` → neutral terminal
- unresolved branch → no directional terminal yet

Do not label a scenario bullish/bearish before its reasoning chain is visible.

---

# 9. Block 5 — Asymmetry summary

Even though asymmetry is embedded in the tree, include a short summary outside it.

Answer:

- where the asymmetry currently lies;
- what positioning could amplify the move;
- what positioning could limit the move;
- whether the opportunity is early / balanced / crowded / late;
- whether there is currently an actionable edge.

Do not reduce this to a numeric score.

Use plain qualitative language.

## 9.1 Separate display of direction, asymmetry and edge (V3)

For V3 presentation, macro direction, directional asymmetry, positioning
asymmetry and final edge must each be displayed as their own labeled field in
`presentation.<locale>.direction_state`, never merged into one sentence that
lets a bullish/bearish macro direction read as if it were the edge. A bullish
or bearish macro direction does not by itself imply a bullish or bearish
edge; `NO_EDGE` and `UNKNOWN` remain valid displayed outcomes even when the
macro direction is clearly directional. See `GOLD_PRESENTATION_V3_SPEC.md` #6.

---

# 10. Block 6 — Upcoming catalysts

Display only **material catalysts** capable of changing the current read.

For each:

- event;
- date/time if established;
- what the market currently expects;
- what question the event will answer;
- which scenario branch(es) it can activate, weaken, or invalidate.

Tier 1 events deserve stronger visual prominence.

Do not fill the calendar with low-value releases.

---

# 11. Block 7 — Invalidations, contradictions, anomalies, unknowns

This block is mandatory.

## Invalidations

List the conditions that would make the current main read wrong.

Prefer observable and quantified conditions when genuinely supported.

## Contradictions

What evidence currently pushes against the preferred story?

A report with no contradictions should be treated with suspicion.

## Anomalies / unexplained

What behavior has not been explained convincingly?

## Unknowns

What important information is unavailable, stale, delayed, or insufficiently measured?

Never convert:

`UNKNOWN`

into:

`neutral`.

---

# 12. Evidence drill-down

The interface should allow the user to inspect why a node exists.

A clickable or expandable evidence node should ideally expose:

- statement;
- value;
- change;
- AS-OF;
- measurement window;
- family;
- source(s);
- epistemic status;
- reported link vs observed fact;
- short pedagogical explanation;
- which part of the Market Story / scenario uses it.

The final UI implementation may vary.

The information requirement does not.

---

# 13. Weekly chronology drill-down

The chronological Monday → Friday recap remains accessible beneath the synthesis.

For each day:

- material Gold move;
- important events;
- relevant cross-asset move;
- reported attribution.

Keep:

`PRICE FACT`

separate from:

`REPORTED ATTRIBUTION`.

This block exists for auditability and context.

It should not dominate the first screen.

---

# 14. Output vocabulary

Preferred global confidence vocabulary:

- `CLEAR`
- `LIKELY`
- `PLAUSIBLE / MIXED`
- `INSUFFICIENT EVIDENCE / UNKNOWN`

Never invent probability percentages unless they come from an actual measured probability source.

Do not output:

- “73% bullish”
- arbitrary scores
- mechanical weighted totals

---

# 15. Visual truth rules

Every visual element must correspond to a real analytical object.

Do not:

- add arrows because they look good;
- create fake dependencies;
- merge unrelated drivers;
- hide contradictions;
- decorate missing data as if confirmed;
- color something bullish/bearish before the logic reaches that conclusion.

A beautiful diagram that lies is worse than no diagram.

---

# 16. Sunday-only scope

This specification is for the **automated Sunday Read** only.

It does not define:

- manual midweek re-triggers;
- nocturnal recap;
- intraday update logic;
- scenario replacement logic after new events;
- post-trade review.

Those will be designed separately.

---

# 17. Suggested final page skeleton

```text
┌────────────────────────────────────────────────────────┐
│ PREPARATION MACRO DE L'OR / GOLD MACRO SETUP          │
│ week of · upcoming week · reviewed week context        │
└────────────────────────────────────────────────────────┘

1. PREPARATION FOR THE UPCOMING WEEK
   Framing of the next macro decision window.

2. MARKET STORY — PAST WEEK
   Histoire du marché / Market story of the reviewed week.

3. CURRENT SETUP
   Where the market stands now.

4. CONTEXTS BY HORIZON

   ┌────────────────┐
   │ TACTICAL       │
   │ summary        │
   │ supporting     │
   │ counter case   │
   │ invalidation   │
   └────────────────┘

   ┌────────────────┐
   │ MEDIUM TERM    │
   │ ...            │
   └────────────────┘

   ┌────────────────┐
   │ STRUCTURAL     │
   │ ...            │
   └────────────────┘

5. WHAT IS PRICED / WHAT CAN STILL SURPRISE

6. CONSOLIDATED SCENARIO TREE
   Graphical tree + guided textual reading

7. ASYMMETRY / EDGE EXPLANATION

8. MATERIAL CATALYSTS

9. INVALIDATIONS / CONTRADICTIONS / ANOMALIES / UNKNOWNS

10. EVIDENCE & SOURCE DRILL-DOWN (when requested)
```

---

# 18. Machine-readable output

The reasoning pipeline should also produce structured JSON for the UI.

Suggested top-level structure:

```json
{
  "meta": {},
  "executive_narrative": "",
  "contexts": {
    "tactical": {},
    "medium": {},
    "structural": {}
  },
  "priced_in": {},
  "scenario_tree": {},
  "asymmetry": {},
  "catalysts": [],
  "invalidations": [],
  "contradictions": [],
  "anomalies": [],
  "unknowns": [],
  "weekly_timeline": [],
  "evidence": [],
  "sources": []
}
```

The JSON schema should be implemented and validated in code.

The UI should render from this structured representation rather than parsing prose.

---

# 19. Final communication principle

The Sunday Read must answer two human needs simultaneously:

### UNDERSTAND

> What is happening, why, and how do the pieces connect?

### DECIDE WHETHER THERE IS AN EDGE

> Even if the story is right, is there enough asymmetry to care?

The system is successful when the user can understand the market better **without being tricked into false certainty**.

## 20. Production presentation audit

For every new production run, collect the literal IDs defined in
`scenario_tree.nodes[].id` and `scenario_tree.edges[].id`. Verify that none
of those exact strings occurs inside human-facing presentation text. Check at
least titles, subtitles, market story, horizon fields, priced-in and surprise
explanations, scenario labels and descriptions, `walkthrough.intro`,
`walkthrough.steps[].text`, asymmetry presentation, and all other localized
prose. IDs are permitted only in structured reference fields.

Also verify that every material displayed node and edge has usable localized
human copy, glossary tokens resolve, French and English preserve the same
analytical meaning, and the walkthrough is understandable without the
diagram. This is a literal run-specific check; a generic regex alone is not
sufficient.

For V3 runs, additionally verify that zero `[[GLOSSARY_ID|...]]` tokens exist
anywhere in human-facing copy (structured `glossary_refs`/`annotations` only),
and that `direction_state` in both locales matches the analytical
`direction_state` for the same run — presentation must never drift from the
canonical conclusion it is explaining.
