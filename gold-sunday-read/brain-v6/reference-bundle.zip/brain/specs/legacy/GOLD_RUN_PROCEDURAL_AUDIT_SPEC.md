# GOLD RUN PROCEDURAL AUDIT SPEC

## 1. Purpose

The analytical instructions already say what a Sunday or intermediate run must
do (`GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md`,
`GOLD_MACRO_REASONING_MANUAL_SUNDAY.md`, `GOLD_SUNDAY_READ_RUN_PROTOCOL.md`,
`GOLD_CONTINUOUS_RECAP_PROTOCOL.md`). This spec makes it verifiable that a run
actually did it: a run must not be able to claim completion without factual,
machine-checkable traces that every mandatory step was attempted, in a possible
order. It adds no analytical rule and does not repeat the ones above; it points
at them.

Enforced by `tools/procedural-audit.mjs`, wired into `tools/validate.mjs`, with
the shapes in `schema/sunday_read.schema.json` (`procedural_audit`) and
`schema/run_completion_record.schema.json`. Tests:
`tests/procedural_audit.test.mjs`.

## 2. What a trace proves, and what it cannot prove

A procedural trace **proves**:

- each mandatory phase has a status, a timestamp window and an artifact;
- phases happened in a possible order (a phase cannot finish before its
  prerequisite, nor complete after a `FAILED` one);
- each mandatory question has an outcome, or an explicit limitation;
- each outcome points at resolvable evidence and sources, or states why none
  exists;
- source recovery was recorded when the protocol requires it;
- for a Sunday: the completed week, benchmark and cutoff are coherent; for an
  intermediate: the inherited state, handoff, evidence window and scans were
  handled as the continuous recap protocol requires;
- validation, Drive readback and the handoff write happened, in order, after
  the state was produced (completion record, section 10).

A procedural trace **cannot prove**:

- that the analysis is correct, well-sourced or unbiased. Analytical quality
  stays with `competing_hypotheses`, `contradictions`, `anomalies`, `unknowns`,
  `analysis_contract.explicit_unknowns`, the adverse case and the coherence
  validation;
- that a recorded search was thorough, or that a cited source says what the
  question needs. It records the category and reference, not the reading;
- that a timestamp is honest. It rejects impossible or contradictory
  chronologies, not fabricated ones.

## 3. No private reasoning

The audit records **procedure, never thought**. It must not hold a chain of
thought, deliberation, drafts or hidden rationale. The schema objects are closed
(`additionalProperties: false`): only phase status, artifact, question outcome,
references, consulted source categories, recovery attempts, limits and
timestamps can be written. Free text is confined to short factual statements
(`limitation.explanation`, `reason`, `limitations[]`).

## 4. Unknown result versus omitted step

| Situation | Recorded as | Valid? |
|---|---|---|
| The question was attempted and the measure does not exist or is not public | outcome `UNKNOWN` with a `limitation` (`STRUCTURALLY_NON_OBSERVABLE` needs its explanation; `SOURCE_NOT_FOUND`/`SOURCE_INACCESSIBLE` need a source-recovery record) | yes |
| The value exists but is not published yet | outcome `PUBLICATION_LAG` with a `publication_limit` | yes |
| Only part of the measure could be established | outcome `PARTIAL` with a `limitation` | yes |
| The item is contextual or not due this cycle | outcome `NOT_APPLICABLE` with `NOT_MATERIAL_THIS_RUN` or `NOT_DUE_THIS_CYCLE` | yes |
| The tool or resource stopped the attempt | outcome `FAILED` with a limitation and a `procedural_gap` | yes, visible |
| The question or phase is simply absent, or has no outcome | nothing | **rejected** |

An `UNKNOWN` is an answer. A missing record is not. A run with many `UNKNOWN`
outcomes and a complete trace is valid; a run with a rich narrative and one
missing phase is not.

## 5. Where the trace lives

The market-state JSON is generated and frozen locally (its canonical hash is
fixed) before any validation, and it is never uploaded to the Output folder
before the local validation passed. Being frozen, it cannot attest to the
validation, the upload, the Drive readback or the handoff write that come after
it. The trace is therefore split:

1. `procedural_audit` inside the market-state document: the fourteen phases up to
   and including `json_and_reports`, the collection traces, the coverage audit,
   the reasoning components, the procedural gaps, and the Sunday or
   intermediate proof.
2. A `GOLD_RUN_COMPLETION_RECORD` (control plane, `storage_plane: "CONTROL"`,
   `frontend_eligible: false`, never rendered), written last, sealing
   `market_state_validation`, `drive_readback`, `handoff_generation` and
   `handoff_validation`. It carries the SHA-256 of the canonical JSON it seals
   (keys sorted).

A REAL run that has a state but no completion record cannot be treated as
complete (`node tools/validate.mjs <state.json> <completion_record.json>`).

## 6. Applicability and compatibility

`procedural_audit` is **required** for new documents with
`meta.data_mode = "REAL"` and `meta.run_type` in `SUNDAY | INTERMEDIATE`
(schema conditional plus validator). It is **opt-in** for `FIXTURE` documents:
when present it is fully validated. Historical documents carry no
`meta.run_type`, so they are unaffected and are never rewritten
(`schema/minimal_v2_example.json` is the standing regression).

## 7. Phase order

Phases and their prerequisites (`PREREQUISITES` in the module):

| Phase | Prerequisite(s) |
|---|---|
| `initialization` | none |
| `weekly_recap` | `initialization` |
| `F1` `F2` `F3` `F4` `F5` `F6` | `initialization` |
| `collection_coverage_audit` | `weekly_recap`, `F1`..`F6` |
| `reasoning` | `collection_coverage_audit` |
| `asymmetry_gate` | `reasoning` |
| `scenario_tree` | `asymmetry_gate` |
| `presentation` | `reasoning`, `asymmetry_gate`, `scenario_tree` |
| `json_and_reports` | `presentation` |
| `market_state_validation` (record) | none |
| `drive_readback` (record) | `market_state_validation` |
| `handoff_generation` (record) | `market_state_validation`, `drive_readback` |
| `handoff_validation` (record) | `handoff_generation` |

Weekly Recap and F1-F6 may overlap in time (`GOLD_SUNDAY_READ_RUN_PROTOCOL.md`
section 4 allows concurrent collection), so no order is imposed among them.
Every other phase is strictly sequential.

Status vocabulary: `NOT_STARTED`, `IN_PROGRESS`, `COMPLETE`, `PARTIAL`, `FAILED`,
`NOT_APPLICABLE` (only `weekly_recap` of an intermediate). Rules:

- `COMPLETE`/`PARTIAL`/`FAILED` need `started_at <= completed_at`;
  `COMPLETE`/`PARTIAL` need an `artifact`; `PARTIAL` needs `limitations`;
  `FAILED` needs `blocking_issue`.
- A dependent phase marked `COMPLETE` or `PARTIAL` needs every prerequisite
  finished (not `NOT_STARTED`/`IN_PROGRESS`) and must not start or complete
  before it.
- A dependent phase cannot be `COMPLETE` after a `FAILED` prerequisite. It may
  be `PARTIAL` only with a recorded limitation.
- A published state cannot leave a phase `NOT_STARTED` or `IN_PROGRESS`.
- `meta.status = COMPLETE` requires every phase `COMPLETE` (Weekly Recap
  `NOT_APPLICABLE` on an intermediate) and no material gap.

A phase status describes the **procedure**; a question outcome describes the
**evidence**. A family whose questions are all `UNKNOWN` with limitations is a
`COMPLETE` phase. `PARTIAL` means the procedure itself stopped short.

## 8. Collection traces

Each collection module (`weekly_recap`, `F1`..`F6`) carries `questions[]`. A
question records `outcome`, `as_of` or `measurement_window`, `evidence_refs`
(resolving in `evidence[]`), `source_refs` (resolving in `sources[]`),
`source_categories` consulted, `publication_limit`, `limitation` and
`source_recovery`.

Rules per question:

- `ANSWERED`: at least one resolvable evidence reference, an `as_of` or
  measurement window, and a source reference or category. No minimum count.
- Any other outcome: a `limitation` (`reason` + `explanation`). Absence of a
  limitation fails as `<family> marked <status> without evidence or explicit
  limitation`.
- Reasons `PUBLICATION_LAG`, `SOURCE_NOT_FOUND`, `SOURCE_INACCESSIBLE`,
  `SOURCES_CONFLICT` require at least one source or category consulted: an
  unattempted question is unresolved, not `UNKNOWN`.
- Reasons `SOURCE_NOT_FOUND` and `SOURCE_INACCESSIBLE` require `source_recovery`
  (`GOLD_SUNDAY_READ_SOURCE_RECOVERY.md`): registry consulted plus at least one
  attempt, or a stated reason recovery does not apply. Otherwise:
  `source recovery required but not recorded`.
- `STRUCTURALLY_NON_OBSERVABLE` (for example true dealer gamma or a forced actor
  from public data) needs its explanation and needs no recovery.

**Sunday**: every question below is mandatory in its module. **Intermediate**:
the audit is targeted (`GOLD_CONTINUOUS_RECAP_PROTOCOL.md` section 7): each of
F1-F6 needs at least one traced question, and `family_audit` must carry all six
entries (`UPDATED` needs an `ANSWERED` question, `NOT_DUE` only
`NOT_APPLICABLE` ones, `UNCHANGED` needs `checked_against_new_evidence`).

Mandatory Sunday questions (mirrored from the collection spec; a test checks
this table against the validator):

| Question | Module | Source of the question |
|---|---|---|
| WR.DAILY_PRICE_FACTS | Weekly Recap | collection spec section 5 |
| WR.BENCHMARK_CONTRACT | Weekly Recap | section 5 (contract identity, roll) |
| WR.EVENTS | Weekly Recap | section 5 |
| WR.CROSS_ASSET_MOVES | Weekly Recap | section 5 |
| WR.REPORTED_ATTRIBUTION | Weekly Recap | sections 5.2-5.3 |
| F1.FED_PRICING | F1 | section 8A |
| F1.US2Y | F1 | section 8B |
| F1.FED_COMMUNICATION | F1 | section 8C |
| F1.NEXT_FOMC | F1 | section 8D |
| F2.DFII10 | F2 | section 9A |
| F2.NOMINAL_REAL_BREAKEVEN | F2 | section 9B (tenor named) |
| F2.LEADING_MATURITY | F2 | section 9C |
| F2.CURVE_2S10S | F2 | section 9D |
| F2.MOVE | F2 | section 9F (contextual; `NOT_APPLICABLE` is valid) |
| F2.F1_OVERLAP | F2 | section 9 (F1 overlap) |
| F3.DXY | F3 | section 10A |
| F3.GOLD_DXY_30D | F3 | section 10B |
| F3.USDJPY | F3 | section 10C |
| F3.USDCNH | F3 | section 10D |
| F3.USD_LIQUIDITY | F3 | section 10E |
| F4.MACRO_RELEASES | F4 | section 11A |
| F4.OIL | F4 | section 11B |
| F4.TREASURY_AUCTIONS | F4 | section 11C |
| F4.CREDIT_HY_IG | F4 | section 11D |
| F5.COT | F5 | section 12 base layer |
| F5.OPEN_INTEREST | F5 | section 12 base layer |
| F5.ETF_FLOWS | F5 | section 12 base layer |
| F5.OPTIONS | F5 | section 12 base layer, 12A |
| F5.Q1_FLOW | F5 | section 12 Q1 |
| F5.Q2_FORCED_ACTOR | F5 | section 12 Q2 |
| F5.Q3_FUNDING | F5 | section 12 Q3 |
| F5.Q4_FUSE | F5 | section 12 Q4 |
| F5.Q5_MARGINAL_FLOW | F5 | section 12 Q5 |
| F6.CENTRAL_BANK_DEMAND | F6 | section 13A |
| F6.CHINA_PHYSICAL | F6 | section 13B |
| F6.DEDOLLARIZATION | F6 | section 13C |
| F6.DEBASEMENT_THEME | F6 | section 13D |

`collection_coverage_audit` records `families_reviewed`, the recomputed
`unresolved_required_questions` and an `outcome`; the validator recomputes them
from the traces, so a family cannot disappear silently and the audit cannot
misreport.

## 9. Procedural gaps

`procedural_gaps[]` lists deviations of the **procedure** (not measurement
limits, which live in question limitations): a `FAILED` or `PARTIAL` phase, a
required question left unresolved, a resource limit, a resumed run.

- Every `FAILED`/`PARTIAL` phase and every unresolved required question needs a
  matching gap of kind `PHASE_FAILED`, `PHASE_PARTIAL` or
  `UNRESOLVED_REQUIRED_QUESTION`, always `material`. Otherwise:
  `material procedural gap not declared`.
- A material gap must be visible to a reader: its `surface_text` must appear
  verbatim in `unknowns[]` or `analysis_contract.explicit_unknowns[]`. Otherwise:
  `material procedural gap not surfaced`.
- A run with a material gap cannot be `meta.status = COMPLETE`.

A partial phase may leave required questions unresolved only when each is
declared this way. Analytical biases are not recorded here (section 2).

## 10. Reasoning components

`reasoning_components[]` records, for each of `COMPETING_HYPOTHESES`,
`DOMINANT_DRIVER`, `TRANSMISSION_CHAINS`, `CROSS_ASSET_REALITY_TEST`,
`CONTRADICTIONS`, `ANOMALIES`, `PRICED_IN`, `CONTEXTS_BY_HORIZON`,
`INVALIDATIONS`, `UNKNOWNS`, a disposition: `PRODUCED` (its output path resolves
to a non-empty value), or `NONE_FOUND` / `EXPLICIT_UNKNOWN` / `NOT_APPLICABLE`
with a reason. `NO CLEAR DOMINANT STORY` is therefore a valid, traced result. The
asymmetry, tree and presentation phases additionally require their artifacts
(`direction_state` and `asymmetry`, `scenario_tree.nodes`, V3 FR/EN
presentation).

## 11. Sunday proof

### Corrective rebuild after the Sunday Globex reopen

An incomplete Sunday production can be superseded by a new, fully independent
Sunday analysis on Monday. This is an exceptional new state, never an edit of an
immutable state or a relabelled intermediate recap. Its `run_id` and four
output filenames must be unique, and its origin is itself. The old run remains
an audit record if available; the new handoff replaces the old handoff only
after validation and readback.

For the ordinary Sunday run, the full evidence cutoff remains no later than
Sunday 22:00 UTC. A later full evidence cutoff is permitted only when
`procedural_audit.sunday.corrective_rebuild` identifies the target Sunday,
superseded run, correction reason, a Friday weekly-market cutoff before Sunday
reopen, the start of the post-week context, and source-backed dated references
to the new context. The completed Monday-to-Friday Weekly Recap and its
benchmark calculation must still stop at Friday close. Sunday-night and Monday
market activity may enter only the explicitly dated current setup, never as a
cause of the finished Friday move. The corrective proof is rejected if the
Friday cutoff is late, the Monday evidence is undated, the cited evidence is
missing, or a post-week source is silently counted inside the completed week.
The new state must pass every other ordinary REAL Sunday requirement and
local validation before Drive upload.

`procedural_audit.sunday` plus the lineage fields:

- `completed_week`: a Monday-to-Friday span, `analysis_of_completed_week_finished`
  true; it must equal `presentation.scope` when present, and
  `meta.evidence_cutoff_start` must begin on its Monday;
- `benchmark`: instrument and contract identified; a contract roll inside the
  window must be disclosed (`GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md`
  section 5);
- `cutoff`: equals `meta.evidence_cutoff_end`, is after the Friday of the
  reviewed week, and is not later than 22:00 UTC of the following Sunday (Globex
  reopening); `sunday_night_trading_excluded` true;
- `meta.parent_run_id = null` and `meta.origin_sunday_run_id = meta.run_id`
  (`Sunday parent_run_id must be null`, `Sunday origin_sunday_run_id must equal
  its own run_id`), and the same in the completion record;
- the completion record proves a new handoff: created by the Sunday run,
  origin and parent state both equal to the Sunday run.

## 12. Intermediate proof

### One-time partial-week initialization on 25 September 2026

The user authorized one exceptional REAL `SUNDAY` initialization on the morning
of Friday 25 September 2026. This is a new Sunday lineage and must still pass
all F1–F6, V4/V5, evidence, bilingual, completion-record and readback gates.
The only scope exception is that `time_scope.reviewed_week_start` is 2026-09-21,
`reviewed_week_end` is 2026-09-24, and `report_week_start/end` span
2026-09-21 through 2026-09-25. Record the exact Friday cutoff in
`procedural_audit.sunday.partial_week_exception`, including the prior
validated run ID; `completed_week.analysis_of_completed_week_finished` MUST be
false. The cutoff must be on 25 September after midnight New York and before
the end of that market day. No Friday close or future release can be claimed.
Keep Friday observations available by cutoff separate from the Monday–Thursday
chronology and label the partial scope in both user-facing languages. The
normal completed-Friday requirement remains mandatory for every other Sunday.

`procedural_audit.intermediate`:

- `intake`: candidate validated states with cutoffs; the selected parent equals
  `meta.parent_run_id`, is the latest validated candidate, and its cutoff equals
  `meta.evidence_cutoff_start`; a lineage chain from parent to origin without
  cycle; the consumed handoff (id, version, hash, creator) matches
  `consumed_handoff_id`, `handoff_version`, `handoff_content_hash`, was created
  by the parent state, and was read and validated during initialization, before
  any collection; idempotence (`FIRST_CONSUMPTION` needs no prior consumer;
  `RESUME_OF_SAME_RUN` only this run);
- `evidence_roles`: every evidence item is `NEW_POST_CUTOFF`,
  `DIRECT_DATA_REFRESH` (both must be dated after the parent cutoff, and a
  date-only value must fall on a later day) or `BASELINE` with a baseline label.
  A pre-cutoff item labelled new fails with `intermediate evidence predates
  parent cutoff without baseline label`; a scenario transition resting only on
  baseline evidence fails;
- `weekly_history`: inherited unchanged (hash of `weekly_timeline` must match)
  or corrected with a reason and resolvable evidence; when the parent state is
  available its timeline hash and origin must match;
- `inherited_scenarios` and `scenario_transitions`: every inherited scenario has a
  transition; `NOT_TESTED` needs a reason;
- `exogenous_scan`: all nine categories of the continuous recap protocol
  section 8, `UNKNOWN`/`NOT_APPLICABLE` with a limitation, a material factor with
  evidence, a recorded scenario-structure decision, completed before reasoning;
- the Weekly Recap is `NOT_APPLICABLE` (never rerun); F1-F6 targeted audit and
  `family_audit` as in section 8; reasoning and asymmetry are phases of this run;
- the completion record proves the handoff replaced the active file **in place**
  (`UPDATED_IN_PLACE`), only after validation and readback succeeded, with
  exactly one active handoff afterwards.

## 13. Completion record

`schema/run_completion_record.schema.json`.

**Order of operations and when the upload is authorized.**

1. The state JSON, the human report and the run report (`RUN_STATE` snapshot) are
   generated and frozen locally (`json_and_reports`).
2. The local validation runs (`market_state_validation`); its output is the
   validation report. It must be `COMPLETE`.
3. Only then may the four immutable files (`MARKET_STATE_JSON`, `HUMAN_REPORT`,
   `VALIDATION_REPORT`, `RUN_REPORT`) be uploaded to `Gold Sunday Read Output`.
   Nothing is uploaded to the Output folder before the local validation passed.
   Upload and readback both happen inside `drive_readback`; each file records
   `uploaded_at`, `readback_at`, its hash and `readback_verified`. An upload
   earlier than the validation's completion, outside the phase, or a readback
   earlier than its upload, is rejected.
4. Only after validation and readback is the handoff written
   (`handoff_generation`; `GOLD_SUNDAY_READ_RUN_PROTOCOL.md` section 6A: pre-write
   and post-write readback of the active handoff), then validated.
5. The completion record is written last. The run report is frozen before the
   handoff write, so it cannot state the handoff outcome; the completion record
   does.

**Where the completion record lives.** In the Control plane: the
`Gold Sunday Read Control` folder, under
`run_records/RUN_COMPLETION_RECORD_<run_id>.json`, immutable. It is not one of the
four immutable Output files (those roles are closed, and names matching a
completion record or `NEXT_GOLD_RECAP` are rejected), it is never written to
`Gold Sunday Read Output`, and it is not the mutable `NEXT_GOLD_RECAP.json`. Its
`frontend_eligible` is `false`, its `document_type` is `GOLD_RUN_COMPLETION_RECORD`
and its `storage_plane` is `CONTROL`.

**It can never be the current state.** A market-state ingestion selects only
documents where `document_type = GOLD_MARKET_STATE` and `frontend_eligible = true`
(`isFrontendEligibleMarketState` in `tools/procedural-audit.mjs` is the reference
predicate; `GOLD_CONTINUOUS_RECAP_PROTOCOL.md` section 3). A completion record
satisfies neither condition and does not validate as a market state; forging
either field fails its own schema. The trading application is outside this
repository and was not modified: it must apply that predicate.

The record also carries the handoff identity and write mode, and `run_state`.
`COMPLETE` requires all four phases `COMPLETE`. When the sealed state is available
the record must name its run, lineage and hash, and validation must start after
the state's `json_and_reports` completed. The handoff is written only after
validation and readback; `handoff completed before Drive readback` and
`handoff completed before market-state validation` are rejected.

## 14. Why no volume threshold

Nothing here counts sources, facts, nodes, words, votes or scores, and nothing
demands a directional bias or the resolution of an unavailable datum. A source
count would reward padding and punish a week where one authoritative release
carries the answer; a length floor would reward narration. The audit checks that
each step was attempted and recorded and that the recorded story is coherent. A
short, honest run passes; a long one that skips a phase fails.
