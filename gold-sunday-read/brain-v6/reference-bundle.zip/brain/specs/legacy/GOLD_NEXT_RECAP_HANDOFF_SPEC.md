# GOLD NEXT RECAP HANDOFF SPEC

For new REAL states from 26 September 2026, apply
`GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md`: ACTIVE handoffs may request
only an allowed first/second intermediate before Friday 00:00 New York.
CLOSED handoffs keep the stable Drive ID and continuity checkpoint but set
`next_execution: null` and cannot trigger another intermediate. The next
Sunday establishes its independent verdict before reading this checkpoint.

Version 7+ handoffs add `continuity_checkpoint` according to
`GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md`: source run ID and cutoff,
durable foundations, live questions, branch checks and six verdicts. Work
tests foundation validity first, scans material exogenous developments
independently, then resolves scenario questions. The latest handoff also
enables the *next Sunday* to compare its independent new-week conclusion
against the last validated prior-week state, without inheriting its verdict.
The handoff stays in Control and is never a frontend state.

## 9. Asymmetry checkpoints

Handoff version 2 and later carries `asymmetry_checkpoints`. Each checkpoint
must state what to refresh and which transitions to watch: COT availability and
lag, ETF flows, price/OI, price/IV and Gold-specific skew, event premium versus
FOMO, gamma only when observed or modelled, SGE/physical confirmation,
funding/fuse changes, catalyst status, scenario activation/invalidation,
opportunity quality, execution readiness, final edge and new exogenous factors.
These are control-plane instructions, not market analysis and never frontend
content.
# GOLD NEXT RECAP HANDOFF SPEC

## 1. Role

`NEXT_GOLD_RECAP.json` is the sole operational handoff from one validated run to the next intermediate recap.

It is not a report, not a frontend payload and not an analytical conclusion.

It instructs the next Work execution where the system was, what must be checked, when to run and how to determine whether the inherited market state changed.

## 2. Lifecycle

- Exactly one active handoff exists.
- The file keeps a stable Drive file ID and is updated in place.
- The next run must read it before research.
- Once consumed successfully, the resulting run records `consumed_handoff_id`, `handoff_version` and the handoff content hash.
- The completed run replaces the handoff content with the next plan.
- A failed run must not overwrite the active handoff unless it writes a valid recovery plan.
- Repeated execution with the same `handoff_version` must be idempotent.

## 3. Mandatory content

The handoff must contain:

- document identity and version;
- origin and parent run IDs;
- prior evidence cutoff;
- requested next execution time and timezone;
- timing rationale;
- event or condition motivating the recap;
- inherited directional state;
- inherited positioning state;
- inherited edge;
- scenario checks;
- mandatory F1–F6 audit instructions;
- new-source window;
- direct-data refresh requirements;
- exogenous-factor scan instructions;
- article and statement gap scan;
- required reasoning and asymmetry steps;
- expected output filenames;
- expiry and cancellation rules;
- recovery behavior.

## 4. Scenario checks

Each scenario check must state:

- scenario reference;
- economic meaning in plain language;
- condition to observe;
- direct variables or facts to verify;
- first expected transmission;
- cross-asset confirmation;
- flow and positioning confirmation;
- evidence that would contradict it;
- evidence that would invalidate it;
- unresolved data gaps;
- appropriate observation window;
- whether the condition is event-timed or state-dependent.

Scenario checks are hypotheses to test, never conclusions to preserve.

## 5. New information policy

The handoff must define:

```json
{
  "new_information_after": "ISO-8601 timestamp",
  "article_policy": "Only publications after the prior cutoff are new evidence",
  "direct_data_policy": "Refresh authoritative series when a newer observation exists"
}
```

## 6. Exogenous scan

The handoff must always require a scan for material developments outside the inherited scenario structure.

The next run may restructure the scenario tree when new evidence requires it.

## 7. Timing

The requested execution time must reflect when evidence is likely to be interpretable.

Do not schedule a full reassessment at the instant of a release when transmission and flows cannot yet be observed. If useful, preserve an observation timestamp and schedule the full recap after an explicit confirmation delay.

## 8. Frontend exclusion

Mandatory metadata:

```json
{
  "document_type": "NEXT_GOLD_RECAP_HANDOFF",
  "frontend_eligible": false
}
```

The frontend must never render this file as the current Sunday or intermediate read.
