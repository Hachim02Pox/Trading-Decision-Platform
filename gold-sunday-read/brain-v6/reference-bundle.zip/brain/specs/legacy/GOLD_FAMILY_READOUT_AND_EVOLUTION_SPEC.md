# Gold family readout and rolling evolution contract

New REAL runs from 26 September 2026 additionally follow
`GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md`. Every verdict has an explicit
forward case and opposing case; Sunday and intermediate audits reject generic
missing-measurement prose. F5 options may be NOT_APPLICABLE to a weekly bias
when its specific IV/skew/GEX question is reserved for the user-triggered
pre-trade review. This does not remove COT, ETF, comparable futures OI,
participation, forced-actor and funding checks, nor permit a fabricated
dealer-gamma sign. Older states remain valid.

This additive V5 presentation contract applies to REAL market-state JSON generated on or after 2026-09-25T04:00:00Z. It does not change the research questions in `GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md`, the interpretation method in `GOLD_MACRO_REASONING_MANUAL_SUNDAY.md`, or the six existing verdict enums. Historical Drive publications are immutable and remain schema-valid. The cutoff refers to `meta.generated_at`, not the evidence date.

## Sunday: collect first, explain second

For a SUNDAY run, first perform the complete Monday–Friday recap and independent F1–F6 collection. For **each** family, emit `family_readouts[]` with `family_id`, all the questions in the catalog below, and `family_reasoning`. The catalog restates the collection specification's questions; it does not substitute new providers or new market rules. A question is a user-facing French/English sentence, followed by a French/English answer, `status`, the exact `as_of` date and resolvable `evidence_refs`. An ANSWERED answer requires at least one dated source-backed evidence reference. PARTIAL, UNKNOWN and NOT_APPLICABLE answers explain exactly which measurement is missing or why that particular question is immaterial; `unknown_reason` contains the reason kind, actual source/recovery check, and next action, in both languages. Never fill a gap with a plausible number. A future release that has not occurred is different from a failed retrieval. Questions about optional/contextual indicators may be NOT_APPLICABLE with a concrete reason; they must still appear.

After the questions, `family_reasoning` states what the family's evidence establishes, the mechanism that may matter for Gold, independent counterevidence, what it cannot establish, and the conditional next test. This is a **local, provisional** interpretation, not a vote, automatic BUY/SELL or final global direction. Do not recast the fact that Gold already fell as an independent economic cause or a guarantee of further decline. F1–F6 collection stays separate from this reasoning layer.

### Canonical question IDs (each is mandatory in its family)

| Family | Question IDs and collection-spec source |
| --- | --- |
| F1 | `F1_FED_PRICING` next FOMC expectations, last session, five-session path and repricing; `F1_US2Y` level, direction, event behavior; `F1_FED_COMMUNICATION` material Fed statement versus observed repricing; `F1_NEXT_FOMC` meeting date, priced outcome and remaining catalysts. |
| F2 | `F2_REAL_10Y` DFII10 path; `F2_RATE_DECOMPOSITION` nominal, real and tenor-matched breakevens; `F2_CURVE_LEADERSHIP` front/long-end; `F2_2S10S` level, direction and driving leg; `F2_EVENT_DYNAMICS` dated reaction and persistence; `F2_MOVE` relevant Treasury volatility, otherwise reasoned NOT_APPLICABLE. |
| F3 | `F3_DXY` level, path and breadth; `F3_GOLD_DXY_30D` measured/qualitative/unknown relationship; `F3_USDJPY` state and exceptional move; `F3_USDCNH` state and change; `F3_USD_LIQUIDITY` relevant dollar funding, RRP/TGA where material, otherwise reasoned NOT_APPLICABLE. |
| F4 | `F4_RELEASES` material actual versus expected, prior and revisions; `F4_OIL` material oil move and persistence, otherwise NOT_APPLICABLE; `F4_AUCTIONS_FISCAL` material auctions/fiscal facts, otherwise NOT_APPLICABLE; `F4_CREDIT` HY/IG spreads and direction. |
| F5 | `F5_COT` positioning, dated lag and comparable percentile; `F5_OPEN_INTEREST` comparable OI and price window; `F5_ETF_FLOWS` issuer-backed flows and persistence; `F5_OPTIONS` IV, skew, tenor and event premium if available; `F5_MARGINAL_FLOW` who enters/leaves and why now; `F5_FORCED_ACTOR` observed forced buyer/seller or UNKNOWN; `F5_FUNDING` material leveraged funding constraints; `F5_FUSE` observable mechanical unwind trigger or NONE/UNKNOWN; `F5_PRICE_FLOW_DIVERGENCE` fresh capital versus fading participation. |
| F6 | `F6_CENTRAL_BANKS` declared versus estimated buying and publication date; `F6_CHINA_PHYSICAL` comparable physical demand/premium, otherwise UNKNOWN; `F6_DEDOLLARIZATION` observable actions versus narrative; `F6_DEBASEMENT` observed support for the theme or no material change. |

The canonical owner of each source fact remains the one specified in the collection document; cross-references are allowed, double counting is not. The full positioning/asymmetry collection contract and every current V4 field remain required. The 30-second card summary cannot replace these questions.

After all six families, `global_synthesis` separately explains the causal chain, competing explanations and contradictions, which information is already priced, conditional future paths, invalidation, what is unknown, and **why** each of the six final verdicts is supported. Cross-family dependence is explained rather than counted as six independent votes. The authoritative six raw verdicts remain `direction_state`, `opportunity_quality`, `execution_readiness` and their matching V4 localized `verdict_explanations`. A label BEARISH describes a conditional forward bias supported by a mechanism; a declining price alone is not that mechanism. A directional bias is not an executable edge. A strong opposing mechanism must be allowed to leave direction MIXED or UNCLEAR and edge NO_EDGE.

The scenario tree starts with the factual **current** state; following distinct, observable future conditions leads to bullish, bearish or no-edge outcomes when justified. Not every possible branch must exist; never force a bullish/bearish branch for symmetry. Each branch states its trigger, confirming channels, invalidation and unresolved positioning filter. Localized walkthrough text must be regenerated from the *current* tree.

## Intermediate: an evolution report, not another Sunday read

Retain the full canonical analytical JSON and the `intermediate_summary` contract, but the human page shows only the change against `meta.parent_run_id`. Publish `evolution_review` with that exact parent, a detailed narrative covering what was learned, the parent conclusions still supported, what changed, what strengthened, what weakened, what failed, new outside factors, unknowns with their checked causes, next checks, and `thesis_status`. A field with no change says so without manufacturing evidence. The narrative names the *consequences* for Gold and the current six verdicts, including unchanged verdicts. Each new fact is dated and referenced. If there are two successive intermediates, the second compares to the **first intermediate**, not the Sunday origin.

The full F1–F6 evidence audit still runs; the UI need not repeat the Sunday question list for intermediate cards. An intermediate may carry supplementary `family_readouts` for drill-down, but that does not replace the evolution narrative.

## Across Sundays and handoffs

Every completed Sunday or intermediate writes the existing single active `NEXT_GOLD_RECAP.json` handoff, replacing its content after validation while preserving its Drive file identity. Keep the current scheduling/dispatcher workflow. In addition to inherited state and scenario checks, the new `continuity_checkpoint` carries the source run ID, its evidence cutoff, a plain-language state summary, durable foundations, live questions, branch confirmations/invalidation checks, and the six verdicts. This is a control-plane artifact, never rendered directly. For the next intermediate, first test whether foundations still hold, then independently scan exogenous events (strengthening, weakening, invalidating or redirecting the thesis), then test inherited open questions and scenario conditions; refresh all six families for material changes.

The next Sunday conducts a fresh week-specific collection and reasoning **before** using the previous checkpoint. After its independent conclusion, it reads the latest validated state of the preceding week and the `continuity_checkpoint` left by the final run. Publish `weekly_bridge`: prior run ID, independently observed differences, what earlier expectations did or did not resolve, which earlier conclusions survive, what failed and why, and any unverified comparison. Never copy last week's direction into the new Sunday merely because it was the last direction. The new Sunday starts a **new** `origin_sunday_run_id` and a new visible weekly page. Prior states remain queryable archives and are not deleted.

## Publication gate

For a new REAL Sunday require six readouts, every catalog question once, bilingual answers and family reasoning, source-backed answered facts, explained gaps, `global_synthesis`, and `weekly_bridge`. For a new REAL intermediate require `evolution_review` against the immediate parent in addition to the existing `intermediate_summary`. New active handoffs require a validated `continuity_checkpoint`. Validate before Drive upload, then read back all four immutable outputs and the active handoff. The backend stores the entire JSON unchanged; the frontend reads the new fields and archives use their existing renderer.
