# GOLD SUNDAY READ — WORK RUN PROTOCOL

## Forward analysis and weekly stop gate (new REAL runs from 26 September 2026)

Read `GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md` with the current canonical
files. Collect and reason independently before the six verdicts. Record for
each verdict its strongest dated case, the strongest opposing case, why one
prevails or neither prevails, what has already been priced, the next observable
future condition and invalidation. Publish bilingual `forward_verdict_cases`
with resolvable evidence; make the human report's table reflect these exact
arguments. Reject contradictory old copy and generic missing-data text.

In every incomplete family answer, report exact provider, series, timestamp,
attempt and obstacle; classify release lag separately from access and
comparability. Check for an actually available source before leaving a
recoverable value unknown. Weekly F5 continues COT, ETF, comparable futures
price/OI/volume, marginal/forced flow, funding and structural checks. Weekly
option IV/skew/gamma diagnostics may be deferred to a separate user-triggered
pre-execution Work run; weekly option absence alone cannot veto a macro
direction or edge. Keep genuine uncertainty visible.

Never schedule or produce a third intermediate from one Sunday, nor an
intermediate at or after Friday 00:00 America/New_York. After the last useful
run, replace the stable handoff with a validated CLOSED checkpoint and no
`next_execution`. On the next Sunday, do the independent new-week analysis
first, then compare the last validated prior-week state in `weekly_bridge`.
Do not activate a new CLOSED handoff until the deployed dispatcher accepts it.

For a full corrective Sunday rebuild performed after the Sunday Globex reopen,
apply the separate Friday-market and later full-evidence cutoff contract in
`GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md` §11. Execute all Sunday phases again;
keep the reviewed week's price move at Friday close and date post-week context
separately. Do not use an intermediate recap as a substitute for the full
rebuild. Publication, readback, handoff and completion order are unchanged.

## Purpose

This document defines HOW ChatGPT Work must execute a Sunday Read run.

It does not modify:

- Collection methodology
- Macro reasoning methodology
- Output methodology

The canonical analytical specifications remain:

- GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md
- GOLD_MACRO_REASONING_MANUAL_SUNDAY.md
- GOLD_SUNDAY_READ_OUTPUT_SPEC.md
- sunday_read.schema.json

This protocol exists to make long cloud runs:

- resumable
- auditable
- efficient
- resistant to context or usage interruption
- non-duplicative

---

# 1. ONE LOGICAL RUN

A Sunday Read is one logical run identified by:

`RUN_DATE = YYYY-MM-DD`

All intermediate work belongs to that run.

Never silently restart the entire run if some phases are already complete.

---

# 2. LOAD CANONICAL SPECS ONCE

At the beginning of the run, read the current GitHub versions of:

1. README.md
2. GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md
3. GOLD_MACRO_REASONING_MANUAL_SUNDAY.md
4. GOLD_SUNDAY_READ_OUTPUT_SPEC.md
5. sunday_read.schema.json
6. GOLD_SUNDAY_READ_RUN_PROTOCOL.md
7. GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md
8. GOLD_INTERMEDIATE_NARRATIVE_CONTRACT.md (required for new REAL intermediate runs)
9. GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md (required for new REAL Sunday and intermediate runs)

Build a compact internal execution checklist from them.

Do not repeatedly reread the full files between every family unless:

- the repository changed during the run;
- a rule is genuinely ambiguous;
- validation requires checking exact wording.

This prevents unnecessary context consumption.

---

# 3. EXECUTION PHASES

Execute in this logical order:

PHASE 0
Run initialization

PHASE 1
Weekly Gold Recap

PHASE 2
F1 — Fed & Rate Pricing

PHASE 3
F2 — Rates & Real Yields

PHASE 4
F3 — USD & Liquidity

PHASE 5
F4 — Inflation / Growth / Fiscal / Credit

PHASE 6
F5 — Flows & Positioning

PHASE 7
F6 — Structural

PHASE 8
Collection Coverage Audit

PHASE 9
Macro Reasoning

PHASE 10
Asymmetry Analysis

PHASE 11
Scenario Tree Construction

PHASE 12
Presentation Generation

PHASE 13
Final Sunday Read

PHASE 14
JSON Schema Validation

PHASE 15
Next-Recap Handoff Generation

PHASE 16
Handoff Validation

---

# 4. FAMILY INDEPENDENCE DURING COLLECTION

Weekly Recap and F1-F6 are evidence-collection modules.

During their collection:

- do not construct the final Market Story;
- do not force evidence to support an earlier family;
- do not conclude BULLISH or BEARISH;
- preserve UNKNOWN / PARTIAL;
- respect canonical ownership.

Families may be researched independently or concurrently when the execution
environment permits it.

Parallel execution must never change analytical independence.

---

# 5. CHECKPOINT AFTER EVERY COMPLETED PHASE

After each completed phase, update the run checkpoint.

Maintain a compact object conceptually equivalent to:

RUN_STATE

run_date:
started_at:
last_updated_at:

spec_versions:
  README:
  collection_spec:
  reasoning_manual:
  output_spec:
  schema:
  run_protocol:
  procedural_audit_spec:

phases:

  weekly_recap:
    status: NOT_STARTED | IN_PROGRESS | COMPLETE | PARTIAL | FAILED
    as_of:
    artifact:
    key_gaps:

  F1:
    status:
    as_of:
    artifact:
    key_gaps:

  F2:
    ...

  F3:
    ...

  F4:
    ...

  F5:
    ...

  F6:
    ...

  collection_audit:
    status:

  reasoning:
    status:

  asymmetry:
    status:

  scenario_tree:
    status:

  final_output:
    status:

  schema_validation:
    status:

  handoff_generation:
    status: NOT_STARTED | IN_PROGRESS | COMPLETE | FAILED
    handoff_id:
    handoff_version:

  handoff_validation:
    status:

next_phase:

blocking_issue:

---

# 6. DURABLE INTERMEDIATE ARTIFACTS

When the environment allows artifact creation, preserve intermediate results
separately rather than only inside transient reasoning context.

Preferred conceptual artifacts:

runs/YYYY-MM-DD/

  RUN_STATE.md

  collection/
    weekly_recap.md
    F1_fed_rate_pricing.md
    F2_rates_real_yields.md
    F3_usd_liquidity.md
    F4_macro_fiscal_credit.md
    F5_flows_positioning.md
    F6_structural.md

  reasoning/
    collection_audit.md
    reasoning_state.md
    scenario_tree.json

  final/
    SUNDAY_READ_YYYY-MM-DD.md
    sunday_read.json

  handoff/
    NEXT_GOLD_RECAP.json

If Work cannot persist this exact folder structure, preserve the same logical
separation using the artifact/workspace mechanisms available.

The information must not exist only in hidden transient reasoning.

---

# 6A. NEXT-RECAP HANDOFF GENERATION

This applies to every Sunday run and every intermediate run, per
`GOLD_CONTINUOUS_RECAP_PROTOCOL.md` and `GOLD_NEXT_RECAP_HANDOFF_SPEC.md`.

## Ordering

The handoff is generated only after PHASE 13 (Final Sunday Read / final
intermediate recap) and PHASE 14 (JSON Schema Validation) have both
succeeded. A run must never write `NEXT_GOLD_RECAP.json` before its own
market-state JSON has validated against `sunday_read.schema.json`.

Generating the handoff must never alter the already-completed analytical
market-state JSON. The handoff is a forward-looking instruction file; it
reads the finished conclusion, it does not renegotiate it. If handoff
generation reveals that the just-completed conclusion looks wrong, that is
recorded as an open gap for the next recap — the current run's completed
output is not rewritten to fix it.

## Checkpoint and resumability

`handoff_generation` and `handoff_validation` are RUN_STATE phases like any
other (section 5). A run is not COMPLETE until both reach `COMPLETE`. If
execution is interrupted after PHASE 14 but before the handoff is written,
resume at PHASE 15; do not regenerate PHASE 0–14 artifacts that already
validated.

## Drive readback and duplicate-name protection

Before writing `NEXT_GOLD_RECAP.json`:

1. read back the currently active handoff file from its Drive location (do
   not assume the last local write succeeded);
2. confirm there is exactly one active handoff file at that stable Drive
   file ID; never create a second `NEXT_GOLD_RECAP.json` alongside it under a
   different name or timestamp suffix;
3. update the existing file in place rather than creating a new file, so the
   stable Drive file ID is preserved across the run;
4. after writing, read the file back once more to confirm the write
   persisted and parses as valid JSON before marking `handoff_generation`
   COMPLETE.

If a duplicate-named handoff file is discovered (for example from a prior
failed run), treat it as a resumability signal, not as two independent
handoffs: reconcile to the single active file and record why a duplicate
existed.

A failed handoff write must not leave the active handoff missing or
corrupt. If the write cannot be completed and verified, leave the previous
valid handoff in place and record `handoff_generation: FAILED` with the
blocking issue.

---

# 6B. MANDATORY POSITIONING-ASYMMETRY CONTRACT FOR NEW PRODUCTION RUNS
## Opt-in is mandatory, not model behaviour
Every newly generated **REAL** Sunday market state (`meta.run_type = "SUNDAY"`)
and every newly generated **REAL** intermediate market state
(`meta.run_type = "INTERMEDIATE"`) MUST carry an explicit analysis contract:

```json
"analysis_contract": {
  "version": 1,
  "name": "POSITIONING_ASYMMETRY_EXECUTION_READINESS",
  "no_scoring": true,
  "explicit_unknowns": []
}
```

This is a hard requirement of the run, not a suggestion the model may weigh
against its own judgement, and not an optional presentation nicety. A run may
not decline it because the week looks simple, because positioning data are
missing, or because the evidence would be easier to narrate under the older
contract.

The contract is *additive*. It never replaces the market story, and it never
replaces `direction_state`. It adds structured, auditable positioning and
execution fields on top of the analytical layer.

Historical documents that carry no `analysis_contract` MUST remain
schema-valid and MUST NOT be retroactively invalidated. Backward
compatibility is achieved structurally by keying every new requirement on the
presence of `analysis_contract`, so a pre-contract document cannot trigger a
contract rule.

## Mandatory fields for every new production run
When `analysis_contract` is present, the same run MUST also produce all of:

1. **`positioning_evidence`** — COT identity, participant population, metric
   identity, gross longs/shorts, net position and changes, report and
   publication dates, publication lag, lookback, separate percentiles with
   their own epistemic status; price x OI with comparable windows; ETF flow
   observations with price confirmation, persistence and window overlap;
   options price/IV direction, observation window, event-premium check, call/
   put skew and reliable volume/OI when available; Gold's own skew baseline
   (tenor, moneyness, direction, historical comparison, event context); gamma
   with an explicit epistemic status and dealer-sign claim; physical/SGE
   divergence with comparability fields; funding, forced actor and a fuse.
   Every field must be *attempted*. An omission is not an answer: record
   `UNKNOWN`, `PARTIAL`, `PUBLICATION_LAG` or `NOT_APPLICABLE` explicitly.
2. **`dated_catalyst_assessment`** — status, event name, scheduled time,
   timezone, expected baseline, surprise condition, first transmission
   channel, affected scenarios, activation reason and expiry status. Any
   material scheduled timestamp MUST carry a timezone.
3. **`invalidation_fuse`** — an observable condition stating whether the
   thesis is still bounded, whether it is currently measurable, and over what
   horizon. Without an identified fuse the thesis is not bounded and cannot be
   execution-ready.
4. **`opportunity_quality`** — a qualitative value
   (`STRONG` / `MEDIUM` / `WEAK` / `TRAP` / `UNKNOWN`), never a score, never a
   count of satisfied conditions, never a checklist vote. It MUST carry
   localized French and English display copy plus the structured evidence it
   rests on.
5. **`execution_readiness`** — whether an activation mechanism and a
   measurable invalidation exist (`READY_IF_TRIGGERED` /
   `WAITING_FOR_CATALYST` / `CATALYST_PRESENT_BUT_UNCONFIRMED` / `NOT_READY` /
   `UNKNOWN`), with localized French and English display copy and structured
   evidence refs.
6. **`direction_state`** — macro direction, directional asymmetry, positioning
   asymmetry and the final edge, kept as four separate fields.
7. **Localized FR/EN opportunity-quality copy** — inside
   `presentation.fr` / `presentation.en`, as final renderable display copy with
   a natural explanation. Raw tokens such as `FOMO_CONFIRMED` or
   `READY_IF_TRIGGERED` must never appear as user copy.
8. **Localized FR/EN execution-readiness copy** — same requirement as (7).
   French and English MUST express the same analytical conclusion, never a
   differing one.
9. **Next handoff asymmetry checkpoints** — the run's `NEXT_GOLD_RECAP.json`
   (handoff version 2 or later) MUST carry `asymmetry_checkpoints` stating
   what evidence to refresh and which quality/readiness/edge transitions to
   watch.

## No silent fallback to the old V3 contract
A new Sunday or intermediate production file MUST NOT silently fall back to
the pre-contract (V3) shape. Falling back is not a permitted degradation mode.

Concretely:

- omitting `analysis_contract` on a new production run is a **validation
  failure**, not a default;
- omitting any of the nine mandatory items above while `analysis_contract` is
  present is a **validation failure**;
- if a required field genuinely cannot be established, the run records the
  appropriate explicit insufficient state (`UNKNOWN`, `PARTIAL`,
  `PUBLICATION_LAG`, `NOT_APPLICABLE`, `inference`-free) *inside the field*,
  and lists the gap in `analysis_contract.explicit_unknowns`. It never solves
the problem by removing the field.
- the old V3 contract remains available **only** to historical documents that
  were produced before the contract existed. It is not available to new runs.

## Semantic validation of the contract
Beyond structural validation, the run MUST fail if any of the following holds:

- `STRONG` opportunity quality claimed without positioning evidence, without a
  catalyst/activation mechanism, or without an identified measurable fuse;
- `TRAP` claimed without crowding, lateness or extreme evidence;
- `READY_IF_TRIGGERED` claimed without a dated catalyst or an explicit
  activation mechanism;
- a material scheduled catalyst stated without a timezone;
- an expired catalyst still presented as `WAITING_FOR_CATALYST`;
- `FOMO_CONFIRMED` derived from price up + IV up alone, or asserted without an
event-risk check;
- an observed dealer-gamma claim without legitimate evidence;
- a model-estimated gamma without a documented model method;
- large strike OI treated as proof of dealer positioning sign;
- confirmed SGE divergence without comparable methodology and windows;
- a COT percentile without population, metric, lookback and report date;
- any structured evidence reference that does not resolve to an actual
  evidence ID;
- an analytical/presentation opportunity-quality mismatch;
- an analytical/presentation execution-readiness mismatch;
- a French/English opportunity-quality or execution-readiness mismatch;
- `UNKNOWN` positioning evidence silently reinterpreted as neutral/balanced.

These checks are structured where structure exists. Keyword matching alone is
not an acceptable substitute for resolving IDs, statuses and enums.

---

# 6C. PROCEDURAL AUDIT

`RUN_STATE` is no longer only a conceptual checkpoint. For every new REAL
Sunday and intermediate run, the phases of §3 up to the final JSON are recorded
in the market-state document as `procedural_audit`, and the later phases
(schema validation, Drive readback, handoff generation and validation) are
sealed in a `GOLD_RUN_COMPLETION_RECORD` written last, in the Control plane and
never in the Output folder. The state is frozen locally first, and no file is
uploaded to the Output folder before the local validation passed. A run may not claim
`RUN_STATE = COMPLETE` without both. The contract, the question table, the
allowed statuses and the ordering rules are defined once in
`GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md`; they are not repeated here.

The trace records procedure only (status, artifact, outcome, references,
limits, timestamps), never a chain of thought.

# 7. RESUME RULE

If execution is interrupted:

DO NOT restart automatically.

On continuation:

1. recover RUN_STATE;
2. inspect completed artifacts;
3. verify their AS-OF remains acceptable;
4. identify `next_phase`;
5. continue from that phase.

A COMPLETE phase must not be researched again merely because execution resumed.

A phase may be repeated only if:

- its artifact is missing or corrupt;
- validation failed;
- critical evidence materially changed during the interruption;
- the user explicitly requests a refresh.

If repeated, record why.

---

# 8. DO NOT RESEARCH THE SAME FACT REPEATEDLY

Use already established evidence across phases through canonical ownership.

Example:

If raw US 2Y was established correctly in F1,
F2 may reference it rather than researching it again as independent evidence.

If MOVE was established in F2,
F5 may reference it rather than independently reconstructing it.

Reuse does not create an additional confirmation.

---

# 9. SEARCH EFFICIENCY

Quality remains more important than speed.

However, avoid waste.

Do not:

- run multiple equivalent searches with slightly different wording without cause;
- open many syndicated copies of the same article;
- repeatedly retrieve an authoritative fact already established;
- research irrelevant calendar items;
- collect evidence merely to increase evidence count.

Stop researching a sub-question when:

- it is adequately established;
- its provenance is clear;
- AS-OF is known;
- additional sources are unlikely to materially improve confidence.

Continue researching when:

- sources conflict;
- provenance is unclear;
- the measurement window is wrong;
- the value is stale;
- an important requested field remains UNKNOWN and could reasonably be resolved.

---

# 10. SOURCE DEDUPLICATION

Several articles ultimately repeating one source are one evidence lineage.

Example:

Article A → CME
Article B → CME
Article C → CME

This does not equal three independent confirmations.

Preserve ultimate origin whenever identifiable.

---

# 11. CONTEXT EFFICIENCY

Do not carry full article text into later phases unless necessary.

For every established evidence item preserve the compact information needed for
reasoning:

- statement
- value
- change
- AS-OF
- measurement window
- epistemic type
- owner/family
- source references
- relevant reported link
- conflicts
- unknowns

Reasoning should use these evidence representations rather than repeatedly
reprocessing complete source documents.

---

# 12. REASONING START CONDITION

Do not begin final macro reasoning until:

Weekly Recap
F1
F2
F3
F4
F5
F6

have each reached:

COMPLETE
or
PARTIAL.

PARTIAL is acceptable if gaps are explicit.

FAILED must remain visible.

Never fabricate missing evidence just to unlock reasoning.

## PRESENTATION GENERATION

For a new REAL Sunday, collect the exact F1–F6 questions in
`GOLD_SUNDAY_READ_COLLECTION_EVIDENCE_SPEC.md` first; then emit bilingual
`family_readouts` (all catalog questions with answer/date/evidence/checked
unknown reason and a separate family reasoning block), `global_synthesis`,
and `weekly_bridge` per `GOLD_FAMILY_READOUT_AND_EVOLUTION_SPEC.md`. Do
independent new-week research before comparing the last validated prior-week
state and the latest `NEXT_GOLD_RECAP.json` continuity checkpoint. Sunday
starts a new origin chain; do not inherit the old edge as a new conclusion.
After validating the state, create a version 7+ handoff carrying
`continuity_checkpoint`; preserve its stable Drive file ID.

For a new REAL intermediate, continue to audit F1–F6 but publish a detailed
`evolution_review` against the immediate parent, not a repeated Sunday
question list. Check which foundations survive, new exogenous factors,
scenario confirmations and invalidations before retaining a verdict. Replace
the active version 7+ handoff only after validation and upload readback.

For every new REAL intermediate run generated on or after 2026-09-25T00:00:00Z, follow `GOLD_INTERMEDIATE_NARRATIVE_CONTRACT.md` before declaring the presentation complete. Compare to the parent state by `meta.parent_run_id`, publish `intermediate_summary` with meaningful French and English explanations, including `unknown_reasons` for each material missing input and `macro_reading` separating observation, causal evidence, conditional future and invalidation. Identify the reason for missing data (publication lag, recovery failure, access, comparability, method, structural limit or cause undetermined), checks and next action. A declining price alone cannot prove its cause or predict another decline. Rewrite current-state verdict copy, walkthrough and scenario copy whenever the verdict changes. Keep the published September 24 and earlier documents immutable and valid.

After collection, reasoning, asymmetry, and scenario tree are complete, generate the presentation layer only once.

The presentation layer must include:
- glossary entries for materially technical terms used in user-facing prose;
- French presentation content in a locale-specific object;
- English presentation content in a locale-specific object;
- scenario walkthrough steps that faithfully transcribe the current graph;
- localized scenario-tree node and edge labels;
- clear distinction between authoritative analytical fields and explanatory presentation fields.

Everything inside `presentation.fr` and `presentation.en` is final
user-facing copy ready to render directly. Do not leave the frontend to
interpret graph IDs, translate developer terminology, expand shorthand, or
reconstruct causal relationships. The copy must explain the economic meaning
of each displayed node and edge in complete, natural sentences.

The presentation phase must not run new broad research merely to explain the result. It must explain the analytical work already done.

For new REAL intermediate states generated on or after 2026-09-25T00:00:00Z, run `node tools/validate.mjs <state.json> <completion-record.json>` after the required artifacts are available. The narrative validation checks both locales, parent identity and evidence references. The schema leaves this field optional for historical compatibility; the run validator makes it mandatory for newly produced intermediate states. Do not publish a run if this narrative check fails.

For every new run validate, per `GOLD_PRESENTATION_V3_SPEC.md`:
- for every new REAL state: `presentation.version == 4` (V3 is historical)
- `presentation.fr` exists
- `presentation.en` exists
- the two locales share equivalent structure
- every glossary ID is unique
- every `glossary_refs` entry resolves to a `glossary[]` entry (V3 does not use inline `[[GLOSSARY_ID|...]]` markup; see the human-copy audit below)
- every walkthrough node_ref exists in `scenario_tree.nodes`
- every walkthrough edge_ref exists in `scenario_tree.edges`
- every material terminal is represented in the walkthrough
- no walkthrough step invents a non-existent edge
- French and English presentation preserve the same analytical conclusion
- `presentation.fr.direction_state` and `presentation.en.direction_state` each separately expose macro direction, directional asymmetry, positioning asymmetry and final edge, and match the analytical `direction_state`
- `presentation.fr.scenario_tree_v3` and `presentation.en.scenario_tree_v3` give every displayed node and edge full standalone display copy

### PRESENTATION HUMAN-COPY AUDIT

Before schema validation and completion, collect the actual literal values in
`scenario_tree.nodes[].id` and `scenario_tree.edges[].id` for this run. Verify
that none appears inside presentation prose, including titles, subtitles,
market story fields, horizon fields, priced-in and surprise explanations,
scenario labels and descriptions, `walkthrough.intro`,
`walkthrough.steps[].text`, asymmetry presentation, and other localized copy.
IDs are allowed only in structured reference fields such as `node_refs` and
`edge_refs`; do not rely on a generic regex.

Also verify:
- every material displayed node has a usable French and English human label;
- every material displayed edge has an understandable localized label or explanation;
- zero raw `[[GLOSSARY_ID|visible text]]` tokens appear anywhere in human-facing copy (V3 forbids this markup outright; use `glossary_refs` / `annotations` instead, per `GOLD_PRESENTATION_V3_SPEC.md` #2);
- French and English preserve the same analytical meaning;
- the walkthrough is standalone-readable with the diagram hidden;
- the walkthrough explains economic meaning rather than graph mechanics.

If this audit fails, fix presentation copy only. Do not redo research or
analytical reasoning.

Historical V1 and V2 JSON remain schema-valid through backwards compatibility;
the V3 presentation fields (`direction_state`, `scenario_tree_v3`, and the
prohibition on inline glossary markup) are optional for older documents but
required for new runs.

---

## SOURCE RECOVERY BEFORE FINAL UNKNOWN

Before finalizing a REQUIRED evidence field as UNKNOWN or PARTIAL because of source-discovery failure:

1. verify that normal web research was attempted;
2. check whether `GOLD_SUNDAY_READ_SOURCE_RECOVERY.md` contains a relevant recovery source;
3. attempt that source if reasonably accessible;
4. preserve the result only if it is semantically correct and properly sourced.

Do not repeatedly retry:

- inaccessible sources;
- paywalled/licensed sources;
- stale sources;
- sources that do not actually provide the requested metric.

If the recovery attempt fails:

UNKNOWN / PARTIAL remains the correct result.

Source recovery must not materially delay the run for a field that is structurally non-observable.

# 13. REASONING DOES NOT REDO COLLECTION

Once collection is complete:

Reasoning consumes the evidence base.

It does not restart broad web research.

A targeted verification is allowed only if reasoning discovers:

- a genuine contradiction;
- an impossible chronology;
- a critical missing fact;
- a likely factual error.

Record such verification separately.

---

# 14. INTERRUPTION / USAGE LIMIT

If the environment indicates that execution cannot continue because of:

- usage limit;
- context limit;
- execution timeout;
- temporary tool limitation;
- other resource constraint;

prioritize preserving:

1. completed family artifacts;
2. RUN_STATE;
3. `next_phase`;
4. unresolved gaps.

Do not spend the remaining execution budget writing a long narrative.

Return a compact continuation marker:

RUN PAUSED
RUN_DATE:
LAST COMPLETE PHASE:
NEXT PHASE:
COMPLETED ARTIFACTS:
OPEN GAPS:
RESUME INSTRUCTION:

The next execution must continue rather than restart.

---

# 15. CURRENT RUN VS OLD RUN

Artifacts from previous Sunday Reads may be used for continuity and
`what changed?`.

They are not substitutes for current evidence.

Never mark a current phase COMPLETE simply because a previous week's artifact
exists.

---

# 16. FINAL OUTPUT ONLY ONCE

Do not repeatedly regenerate the complete Sunday Read during intermediate
phases.

Generate the final human narrative and final machine JSON only after:

collection
→ audit
→ reasoning
→ asymmetry
→ scenario tree

are ready.

This reduces unnecessary model usage.

---

# 17. FINAL VALIDATION

Before marking the run COMPLETE verify:

- Weekly complete/partial
- F1 complete/partial
- F2 complete/partial
- F3 complete/partial
- F4 complete/partial
- F5 complete/partial
- F6 complete/partial
- collection audit performed
- competing hypotheses considered
- cross-asset reality test performed
- priced-in analysis performed
- tactical / medium / structural contexts addressed
- asymmetry gate performed
- scenario tree constructed
- invalidations explicit
- unknowns preserved
- sources preserved
- presentation human-copy audit passed
- for a new production run: `analysis_contract` present, `version: 1`,
  `name: "POSITIONING_ASYMMETRY_EXECUTION_READINESS"`, `no_scoring: true`, and
  `explicit_unknowns` listing every gap that could not be resolved
- for a new production run: `positioning_evidence`, `dated_catalyst_assessment`,
  `invalidation_fuse`, `opportunity_quality`, `execution_readiness` and
  `direction_state` all present and internally coherent
- for a new production run: localized FR/EN opportunity-quality copy present
  and semantically identical in conclusion to the analytical value
- for a new production run: localized FR/EN execution-readiness copy present
  and semantically identical in conclusion to the analytical value
- for a new production run: no field was silently removed to escape an
  unproven state, and no new production file fell back to the pre-contract V3
  shape
- for a new production run: every structured evidence reference in
  `positioning_evidence`, `dated_catalyst_assessment`, `invalidation_fuse`,
  `opportunity_quality` and `execution_readiness` resolves to a real evidence
  ID in `evidence[]`
- handoff carries `asymmetry_checkpoints` (handoff version 2 or later)
- final JSON validates against current schema
- `NEXT_GOLD_RECAP.json` generated only after the above validated, and validates against `next_gold_recap.schema.json`
- handoff carries `document_type: "NEXT_GOLD_RECAP_HANDOFF"` and `frontend_eligible: false`
- Drive readback confirmed the handoff write persisted and no duplicate active handoff exists
- for a new REAL run: `procedural_audit` validates and a `GOLD_RUN_COMPLETION_RECORD` sealing the state exists and validates (§6C)

Only then:

RUN_STATE = COMPLETE****
