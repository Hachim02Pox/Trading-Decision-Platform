# Migration Drive du 28 septembre 2026

## Résultat vérifié

Demande explicite d’Hachim : promouvoir les quatre fichiers expérimentaux,
les ranger/renommer selon l’ingestion Trading Platform, supprimer le dossier
expérimental et reconstruire Control depuis cette lecture. Aucune nouvelle
analyse de marché du lundi ni intégration applicative n’est revendiquée.

| Rôle | Nom officiel dans Output | Drive ID conservé |
|---|---|---|
| État JSON | sunday_read_2026-09-27.json | 1xw5uGbCNhXsOTzRAKPHoCVUbedvqZ56M |
| Rapport | sunday_read_2026-09-27.md | 1_tNquNaEqdKRGGYlR5UsWcaC6BGTAaKc |
| Preuves/validation | VALIDATION_REPORT_2026-09-27.md | 1na86_VfXkH9gHRlKS2B7fMUL9Ht-umVw |
| Note de run | RUN_REPORT_2026-09-27.md | 1us1dIXbCB8WPwqd3Qv53oI4oHBiiacWy |

Output : `1otzXd6sEBAaMn_dh-DmMxoiszs4_7aVm`.
Run : `gold-sunday-2026-09-27-editorial-v6-01` ; format 6.0 ; REAL/PARTIAL ;
SUNDAY index 0 ; parent null ; origine identique au run.
Cutoff conservé : `2026-09-27T18:57:35.740939Z`.
Semaine observée 21–25 septembre ; préparée 28 septembre–2 octobre.

Les quatre contenus et parents ont été relus et comparés octet pour octet.
Le JSON réel original, pas une fixture, a fourni le contenu de la migration.
Les phases PARTIAL sont des contrôles techniques des archives le 28 ; elles
ne reconstruisent pas les heures de recherche initiales. Le bridge date la
relecture de migration et explique que l’heure comparative initiale n’est pas
attestée. Le cutoff, les preuves et les limites historiques restent visibles.
La migration ne renouvelle aucune éligibilité de trading.

Correction explicite : spread lundi 2s10s = 4,96 − 4,76 = 20 pb, non 25.
La trace directe GLD est reliée au journal depuis la revue historique conservée.
La révision de handoff initiale non consignée reste déclarée non attestée.
Le Markdown est généré par `renderEditorialMarkdown`, avec parité exacte.

## Empreintes

| Pièce | SHA-256 |
|---|---|
| JSON original avant migration | 7c2a41a4b076951005bb7f6515134ac4e6a4478a7f10dc1935681ba45c2dc18e |
| JSON officiel, octets exacts / trigger | b7275abffadd1e355770c06538e147fc40d60b655a96873e7f189ee9b23d621d |
| JSON officiel, canonique / scellement | 0f725251843dc95085112763338adf4b90434f13026ce45b6c678842e451f82e |
| Rapport | 0e72540779374a6143118fa1844f33b7b5bc2e48892969b5908ef97a4cbf7328 |
| Preuves | fc60e820cdd2e628945042f1ab3b3fb3f0b14aea72249fe028840bf06f9472cb |
| Note | d7ee46b69e4d445b79954c5ab41531ea80a4781f0fac6acd28c0163fd7a32035 |

Ne pas confondre SHA des octets et SHA du JSON canonique à clés triées.

## Archives et Control

Les huit copies déjà présentes dans Output ont été vérifiées identiques aux
originaux puis déplacées dans Control/Gold — Archives de migration — 2026-09-28,
ID `1HMcncHXbZz23drmv05R1TYfNUFcHrnjP`. Elles préservent le brouillon original.
L’ancien dossier expérimental `1UQrH0qdgCJ6zt7lOvr7WGFVbNHofa8wy`, vérifié vide,
a été supprimé. Aucune archive publiée antérieure n’a été supprimée par ce travail.

Control : `1cfLw7eK4pnw33P_K4PIq6IgWgXgua8Ot`.
L’ancien handoff était absent de la liste Control après la suppression signalée
par l’utilisateur, mais restait accessible directement. Il a été archivé puis
annulé (`expiry.cancelled=true`, `expiry.status=CANCELLED`) et déplacé sous le
nom `RETIRED_NEXT_GOLD_RECAP_v12.json` dans l’archive. Son ID
`1kz-OvJ-8lYlV1Z6zOo5Q8wsIWq0Qm1uM` ne doit plus être utilisé en production.
Copie intégrale avant annulation : `1SFn_5ZDAk8rhlPAzdr_pJ0c5iX-mKgci`.

**Unique fichier actif : NEXT_GOLD_RECAP.json, nouveau stable ID
`1vjvIgPV7umsbaCiuUdyxu6R980zg_dsU`.** Création initiale v13, puis remplacement
en place v14 après relecture, sous l’identité logique
`handoff-gold-2026-09-29-post-jolts-v6-01-sealed`. Le reçu atteste ce remplacement.
Les mentions « v13 préparé » des rapports figés décrivent la préparation ;
Control v14 et le reçu final sont l’autorité sur le handoff effectivement scellé.

Reçu immuable :
`RUN_COMPLETION_RECORD_gold-sunday-2026-09-27-editorial-v6-01.json`,
ID `1YSbjdmbNX2R8W_Yr3o6prwQ1OEmvoe41`, dans run_records
`1T881GeH72cVhoz3R0xi50KpfaBVYzt_Y`. Relecture octet pour octet réussie.
Ses phases validation/livraison/handoff sont COMPLETE ; le run global reste
PARTIAL pour les limites de procédure historique et d’intégration externe.

## Prochain contrôle et automatisations

Premier point demandé : mardi 29 septembre 2026, **11 h 30 America/New_York**,
90 minutes après JOLTS prévu à 10 h. Les horaires BLS ont été revérifiés le 28 :
https://www.bls.gov/schedule/news_release/jolts.htm.
Deuxième candidat à reconsidérer au premier récap : mercredi 30, 10 h 30,
au moins 120 minutes après GDP/PCE prévu à 08 h 30 selon
https://www.bea.gov/news/schedule. Aucune valeur future présumée.
Le délai est compté depuis la publication effective ; retard, nouvelle preuve
ou changement de calendrier imposent réexamen. Ces heures concernent le début
de la recherche, pas une heure garantie de livraison. Maximum deux contrôles,
avant vendredi 00 h NY ; CLOSED après le dernier point utile.

Le handoff décrit les 32 questions, les sept nœuds hérités, les fondations,
inconnus, observations/contradictions/invalidations, délai et noms attendus.
L’intermédiaire doit être un snapshot complet v6 + evolution_review, jamais
seulement une liste de différences.

Consignes mises à jour avec le nouvel ID et v6 :
- Gold Sunday Read `6ab2ddfe1bf48191906cbf4b66dc7ce5` : reste activé, cadence inchangée.
- Gold Recap Dispatcher `6aab3e6089388191a39eee49ea959fc3` : reste en pause,
  cadence horaire existante à :30. Réactivation après intégration v6 vérifiée.

Le fichier Control ne réactive pas une automatisation. Aucun run futur garanti
tant que le dispatcher est en pause. Ne pas créer une deuxième automatisation.

## Vérification et frontière applicative

`npm test` et `npm run validate` : PASS. Preflight source/handoff : PASS.
Bundle source + handoff v14 + completion record : **11 checks, 0 failed**.
La validation locale ne prouve ni exactitude économique ni déploiement.
Permissions du nouveau Control incluent le lecteur de service Gold existant ;
un test avec l’identité du backend demeure nécessaire lors de l’intégration.

Trading Platform inspecté au commit `51ad9b3ef0f017b024f2533d3ae0372262a93a73`.
Le code ne reconnaît pas encore le contrat v6. Son trigger est laissé inchangé.
La migration applicative, les variables Railway et le renderer sont décrits
dans `docs/CODEX_PLATFORM_V6_INTEGRATION.md` ; aucun déploiement n’est annoncé ici.
