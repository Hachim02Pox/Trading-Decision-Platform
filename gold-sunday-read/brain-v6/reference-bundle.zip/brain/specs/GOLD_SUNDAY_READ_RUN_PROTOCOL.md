# Protocole de run officiel — v6

Ce protocole produit les quatre livrables éditoriaux du README et conserve la
continuité opérationnelle. Lire les fichiers canoniques dans l’ordre du README,
le schéma éditorial et les schémas Control avant la collecte. Consigner leurs
révisions. Les questions et le manuel ne changent pas ; leurs anciennes références
à des champs d’exécution ne réintroduisent pas ces jugements dans la sortie v6.

## Un run logique, des checkpoints durables

Un `run_id` unique identifie le Sunday ou l’intermédiaire. Conserver un checkpoint
avec phases, heures, artefacts, lacunes et prochaine action. À l’interruption,
reprendre la première phase incomplète ; ne pas relancer celles achevées pour la
seule raison que le contexte a changé. Une preuve ancienne ne prouve pas qu’une
collecte courante a eu lieu. Une limite de ressources reste une lacune explicite.

Ne pas rechercher répétitivement le même fait : réutiliser sa preuve datée tant
que sa période est pertinente. Dédupliquer les reprises d’agence par origine.
Les recherches peuvent être groupées, mais aucune famille ne collecte pour
justifier une conclusion préalablement choisie. Le raisonnement ne refait une
collecte que pour une lacune précise, et reconsidère sa conclusion après récupération.

## Ordre des phases

1. `initialization` : versions, identité, périodes, cutoff et checkpoint.
2. `weekly_recap`, puis F1–F6 : collecte indépendante ; ces modules peuvent se
   chevaucher après initialisation. Pour un intermédiaire, weekly_recap est hérité,
   explicitement NOT_APPLICABLE, jamais une nouvelle étude de semaine passée.
3. `collection_coverage_audit` : toutes les questions tentées, résultats et limites.
4. `reasoning` : hypothèses, driver, chaînes causales, test inter-marchés,
   contradictions, anomalies, prix intégrés, horizons, invalidations et inconnues.
5. `asymmetry_gate` : distinguer direction, asymétries et les deux filtres exacts.
6. `scenario_tree` : conditions observables et alternatives causales.
7. `presentation` : contenu français complet, détail progressif, aucune source visible.
8. `json_and_reports` : JSON figé et ses trois rapports ; aucune attestation de
   validation/upload/readback futur dans cet état immuable.

Une phase dépendante attend la fin de ses prérequis. PARTIAL est permis si la
limite et son effet sont consignés ; un résultat UNKNOWN après recherche réelle
n’est pas une phase omise. Ne pas déclarer COMPLETE une procédure inachevée.

## Particularités Sunday et intermédiaire

Le Sunday étudie la semaine lundi–vendredi achevée et prépare le lundi–vendredi
suivant. Le cutoff de marché vendredi reste séparé du cutoff documentaire et du
contexte du week-end. Geler la lecture indépendante avant de lire l’ancien verdict
pour la comparaison ; enregistrer le bridge et les limites d’accès éventuelles.
Un rebuild correctif le lundi répète toutes les phases Sunday, conserve ces deux
périodes, explique quel run il corrige et ne réécrit jamais l’ancien état.

L’intermédiaire charge le dernier état **validé et scellé**, son completion record
et le handoff stable. Vérifier identités, hash canonique, parent, origine, cutoff,
index, expiry et statut ACTIVE avant exécution. Une même version de handoff est
consommée au plus une fois : reprendre un run existant plutôt qu’en créer un autre.
Consigner `consumed_handoff` et vérifier le parent effectif. Tout conflit avec un
état plus récent ou une écriture concurrente empêche de remplacer le handoff.
Les six familles et les facteurs exogènes sont contrôlés jusqu’au nouveau cutoff.

## Validation locale, publication, puis continuité

Exécuter `npm test` et `npm run validate` pour les contrats, puis :

```sh
node tools/validate.mjs --preflight <state.json> <parent.json>
```

Omettre le parent pour un Sunday. Cette commande contrôle l’état et ses liens,
mais ne certifie ni Drive ni l’exécution totale. Vérifier aussi calculs, unités,
contrats, dates répétées, cohérence économique et faits de la version finale.
Générer le rapport par `renderEditorialMarkdown`, conserver le texte exact dans
`content_preview.markdown`, vérifier son SHA-256 et la concordance des verdicts.
La revue de preuves dit exactement quels contrôles ont été exécutés et ce qui
reste non vérifié. Ne pas revendiquer une vérification du renderer externe.

Après validation locale seulement :

1. Déposer les quatre fichiers sous noms uniques dans Gold Sunday Read Output.
2. Relire chaque fichier, vérifier contenu/hashes et dossier parent. Ne pas écraser
   une archive ni publier un handoff comme état de marché.
3. Préparer le nouveau NEXT_GOLD_RECAP selon la spécification dédiée. Relire le
   handoff en place, vérifier version attendue et absence d’autre écrivain,
   actualiser le même Drive file ID et relire après écriture. Ne jamais créer
   un deuxième fichier portant ce nom. Valider le handoff avec l’état source.
4. Écrire en dernier le `RUN_COMPLETION_RECORD_<run_id>.json` immuable dans Control,
   sous run_records. Il scelle les quatre rôles, hashes, heures, readbacks et
   phases validation/Drive/handoff. Il ne fait pas partie des quatre Output.
5. Valider le bundle final avec `node tools/validate.mjs <state.json> <handoff.json>
   <completion.json> <parent.json> <parent-completion.json>` ; omettre le parent
   pour un Sunday. Le reçu parent peut nécessiter ses propres pièces si v6.

Le hash de l’état scellé est le SHA-256 du JSON canonique (clés triées,
séparateurs compacts, UTF-8), distinct du hash binaire du Markdown. Les fichiers
Output ne s’auto-attestent pas après upload. Un échec ne remplace pas le handoff
avec un plan non validé ; garder un checkpoint de reprise et déclarer le run
PARTIAL/FAILED. Ne jamais annoncer COMPLETE sans reçu vérifié.

## Frontière d’intégration

Ce dépôt ne déploie pas le terminal ou son dispatcher. Ceux-ci doivent reconnaître
v6 et le handoff ACTIVE/CLOSED avant activation de leur ingestion correspondante.
Un format inconnu doit être signalé, jamais transformé silencieusement en état
ancien ou incomplet. Les futures productions utilisent v6 ; si le consommateur
n’est pas prêt, conserver les artefacts validés et documenter le blocage de
publication/ingestion. Ne pas réintroduire l’ancien format pour contourner ce point.
