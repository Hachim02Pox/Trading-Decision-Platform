> Archive de migration V3/V4. Le contrat courant est documenté dans GOLD_V6_MIGRATION.md et le README.

# GOLD V3 / CONTINUOUS RECAP INTEGRATION — CHANGELOG

> Documents the integration of the continuous recap protocol, the next-recap
> handoff spec, the Presentation V3 spec and the handoff schema into the
> canonical system. Per the repository's documentation convention, this file
> records what changed and why; it is not itself a canonical rule file.

## Files added (pre-existing at the start of this integration)

- `specs/GOLD_CONTINUOUS_RECAP_PROTOCOL.md`
- `specs/GOLD_NEXT_RECAP_HANDOFF_SPEC.md`
- `specs/GOLD_PRESENTATION_V3_SPEC.md`
- `schema/next_gold_recap.schema.json`

## Files changed in this integration

- `README.md` — added the four files above to the canonical file map;
  documented Sunday initialization, intermediate updates, and rolling-state
  lineage; documented that handoff JSON is never frontend content; migrated
  the presentation contract description from V2 to V3.
- `specs/GOLD_SUNDAY_READ_RUN_PROTOCOL.md` — added PHASE 15 (Next-Recap
  Handoff Generation) and PHASE 16 (Handoff Validation) to the execution
  order and to `RUN_STATE`; added section 6A defining handoff ordering
  (only after the market-state JSON validates), resumability, Drive readback,
  and duplicate-name protection; added handoff checks to the final
  validation checklist (§17); migrated the presentation validation checklist
  from `presentation.version == 2` to `== 3` and from inline glossary markup
  to `glossary_refs` resolution, while explicitly preserving V1/V2 backward
  compatibility.
- `specs/GOLD_SUNDAY_READ_OUTPUT_SPEC.md` — retitled §0 from "V2 contract" to
  "V3 contract" with an explicit backward-compatibility note; added §0.3.1a
  (no inline glossary markup, standalone node/edge display copy fields);
  marked the legacy `[[GLOSSARY_ID|...]]` walkthrough syntax as V2-only;
  updated §0.4's example `presentation` object to `version: 3` with
  `direction_state` and `scenario_tree_v3`; added §9.1 requiring macro
  direction, directional asymmetry, positioning asymmetry and final edge to
  be displayed as separate fields; extended the §20 production audit to
  check for zero raw glossary markup and for presentation/analytical
  `direction_state` parity.
- `schema/sunday_read.schema.json` — extended (not replaced):
  - `meta` gained optional `document_type`, `frontend_eligible`, `run_type`,
    `parent_run_id`, `origin_sunday_run_id`, `evidence_cutoff_start`,
    `evidence_cutoff_end`. None of these are in `meta`'s `required` array, so
    every historical document without them remains valid.
  - New top-level optional fields: `direction_state` (analytical macro
    direction / directional asymmetry / positioning asymmetry / edge, kept
    separate from the pre-existing `asymmetry` object), `family_audit`,
    `scenario_transitions`, `consumed_handoff_id`, `handoff_version`,
    `handoff_content_hash`.
  - `presentation.version` enum extended from `[2]` to `[2, 3]`.
  - `localePresentation` gained optional `direction_state` (V3 display
    block) and `scenario_tree_v3` (V3 node/edge display copy), plus optional
    `glossary_refs` / `annotations` on several existing presentation blocks
    (market story, horizons, surprises, asymmetry, walkthrough steps) so V3
    plain-copy glossary references have a documented home instead of relying
    only on `additionalProperties: true`.
  - Two `allOf`/`if`/`then` conditionals enforce, at the schema level, that
    (a) any document carrying `meta.run_type` (i.e. participating in the
    continuous recap lineage) must carry the full lineage/frontend-eligible
    metadata and an analytical `direction_state`, and (b) any document with
    `presentation.version == 3` must carry `direction_state` and
    `scenario_tree_v3` in both locales. Neither conditional's `if` matches a
    document that lacks these fields, so historical V1/V2 documents (no
    `meta.run_type`, `presentation.version == 2`) are structurally unable to
    trigger either `then` branch.
- `schema/next_gold_recap.schema.json` — reviewed, not modified; it already
  fully covered the handoff spec's requirements.
- `specs/GOLD_MACRO_REASONING_MANUAL_SUNDAY.md` — reviewed, not modified.
  Verified that macro direction (Market Story) and asymmetry/positioning
  (ch. 21) are already treated as separate analytical layers, that scoring
  and voting are already explicitly forbidden (§17.1), and that
  `MIXED`/`UNKNOWN`/`NO CLEAR STORY` are already established as valid
  outputs. No change was needed to satisfy the "preserve" requirements for
  this file.

## New tooling

- `package.json`, `package-lock.json`, `node_modules/` (gitignored) — added
  `ajv` (draft 2020-12 validator) and `ajv-formats` as dev dependencies.
- `tools/validate.mjs` — validates the historical example and all fixtures
  under `tests/fixtures/` against the two JSON Schemas, plus protocol-level
  checks that JSON Schema cannot express on its own: no raw scenario
  node/edge IDs in human-facing copy, zero raw `[[GLOSSARY_ID|...]]` tokens,
  every displayed V3 edge has causal copy, all structured references
  (`node_refs`/`edge_refs`/`glossary_refs`/`scenario_tree_v3` ids) resolve,
  FR/EN and presentation/analytical `direction_state` parity, and handoff /
  market-state frontend-eligibility flags. Run with `npm run validate` or
  `node tools/validate.mjs`.
- `tests/fixtures/FIXTURE_sunday_v3_state.json`,
  `tests/fixtures/FIXTURE_intermediate_v3_state.json`,
  `tests/fixtures/FIXTURE_next_gold_recap.json` — hand-built fixtures (no
  real market evidence; every value is prefixed `FIXTURE:` and
  `meta.data_mode` / equivalent is `FIXTURE`) exercising the Sunday lineage,
  the intermediate lineage with a pending asymmetry gate, and the handoff
  schema respectively.

## Why extend rather than replace the schema

The task requires that the existing production JSON for 2026-09-13 not be
invalidated. That file lives on Google Drive (the system's production
storage, per `GOLD_CONTINUOUS_RECAP_PROTOCOL.md` §3) and was not read or
modified as part of this work — this integration has no Drive access and did
not attempt any. Compatibility is instead guaranteed structurally: every new
requirement is either an optional field or gated behind an `if` condition
keyed on a field (`meta.run_type`, `presentation.version == 3`) that no
pre-V3 document sets. `schema/minimal_v2_example.json`, the repository's
existing checked-in historical example, is used as a standing regression
fixture in `tools/validate.mjs` to demonstrate this in CI/local runs.

## Positioning asymmetry and execution-readiness contract

The existing Chapter 21 methodology was retained and made machine-auditable.
New opt-in state documents now carry explicit collection fields for COT,
price/OI, ETF flows, options/IV/FOMO, Gold-specific skew, gamma, SGE/physical
confirmation, funding/forced flows and fuses. They also carry dated catalyst,
invalidation/fuse, qualitative opportunity quality and execution readiness.

`direction_state.edge` remains the terminal edge. `STRONG`, `MEDIUM`, `WEAK`,
`TRAP` and `UNKNOWN` describe opportunity quality without scoring; readiness
describes whether an activation mechanism is present. The handoff schema v2
adds scenario-specific asymmetry checkpoints. Historical documents remain
valid because the new contract is opt-in.
## Completion of the positioning-asymmetry contract enforcement

This section records the completion work on top of commit `66b23de`, which had
added most of the schema and spec surface for the positioning-asymmetry
contract but left the enforcement incomplete.

- `specs/GOLD_SUNDAY_READ_RUN_PROTOCOL.md` — added §6B. It makes
  `analysis_contract` mandatory for every newly generated REAL Sunday and
  intermediate run, enumerates the nine mandatory outputs (positioning
  evidence, dated catalyst assessment, invalidation fuse, opportunity quality,
  execution readiness, direction state, localized FR/EN opportunity-quality
  copy, localized FR/EN execution-readiness copy, next-handoff asymmetry
  checkpoints), forbids silent fallback to the pre-contract V3 shape, and lists
  the semantic checks the run must fail on. §17's final validation checklist
  gained the corresponding entries.
- `specs/GOLD_MACRO_REASONING_MANUAL_SUNDAY.md` — added §21.7, a concise
  integration subsection that does not repeat §21.1–§21.6. It separates the six
  distinct readings (macro direction, directional asymmetry, positioning
  vulnerability, opportunity quality, execution readiness, final edge), states
  that vulnerability can exist without a dated catalyst, that vulnerability
  without a catalyst/activation mechanism and invalidation is not
  execution-ready, that `STRONG/MEDIUM/WEAK/TRAP/UNKNOWN` does not replace
  `BULLISH/BEARISH/NO_EDGE`, that price up + IV up requires an event-premium
  check before FOMO, that Gold call skew is judged against Gold's own baseline,
  that gamma stays `UNKNOWN` unless legitimately observed or explicitly
  model-estimated, and that no scoring or checklist voting is allowed.
- `schema/sunday_read.schema.json` — the rolling-lineage conditional now
  additionally requires `analysis_contract`, `positioning_evidence`,
  `dated_catalyst_assessment`, `invalidation_fuse`, `opportunity_quality` and
  `execution_readiness`. Because the conditional is keyed on `meta.run_type`,
  historical documents (including `schema/minimal_v2_example.json`) are
  structurally unable to trigger it. `opportunityQuality.display_fr` and
  `.display_en` were relaxed from a single-token enum to non-empty strings, so
  the contract can carry the localized sentence-level copy the presentation
  spec asks for.
- `tools/validate.mjs` — added `checkContractOptIn`, `checkScenarioBranchRefs`,
  `checkChronology`, `checkLineage`, `checkHandoffAsymmetryCheckpoints`, and a
  rewritten `checkPositioningContract` with structured evidence-reference
  resolution across the whole contract, canonical localized display maps for
  quality and readiness, and semantic gates for STRONG, TRAP,
  READY_IF_TRIGGERED, catalyst timezone/expiry, FOMO corroboration, Gold skew
  baseline, gamma epistemic status, SGE comparability, COT provenance, and
  UNKNOWN-not-relabeled-as-neutral.
- `tests/fixtures/FIXTURE_a_strong_bullish.json` … `FIXTURE_g_handoff_asymmetry_checkpoints.json`
  — seven deterministic positive fixtures (A–G), generated by
  `tests/fixtures/build_positive_fixtures.mjs`.
- `tests/negative_validator_smoke.mjs` — expanded from 2 ad-hoc cases to a
  25-case negative matrix plus 3 validity controls, covering every prohibited
  state listed in the audit.
- `.github/workflows/validate.yml` — minimal CI: `npm ci`, `npm run validate`,
  `node tests/negative_validator_smoke.mjs` on push and pull request, Node LTS,
  no secrets and no production dependencies.
- `package.json` — added `test`, `test:negative` and `build:fixtures` scripts.

`direction_state.edge` remains the terminal edge. No production data was
created and no Drive file was read or modified.

## Auditable run procedure (procedural audit)

Problem: the analytical instructions already existed, but a run could still
claim completion without any factual trace that its mandatory phases had been
attempted. `RUN_STATE` and the Collection Coverage Audit existed only as prose,
and `family_audit` was optional and never validated. This change adds
verifiable procedural traces; it adds no analytical rule, no volume threshold
and no record of private reasoning.

- `specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md` (new) — the single definition of the
  contract: what a trace proves and cannot prove, unknown result versus omitted
  step, phase order and status rules, the mandatory Sunday question table,
  procedural gaps, reasoning components, the Sunday and intermediate proofs and
  the run completion record. `README.md`, `GOLD_SUNDAY_READ_RUN_PROTOCOL.md`
  (§2, §6C, §17) and `GOLD_CONTINUOUS_RECAP_PROTOCOL.md` (§13) only point to it.
- `schema/sunday_read.schema.json` — new closed `procedural_audit` definition.
  A conditional makes it required for `meta.data_mode = REAL` with a
  `meta.run_type`; FIXTURE documents opt in by carrying it; historical documents
  carry no `run_type` and are unaffected.
- `schema/run_completion_record.schema.json` (new) — control-plane record
  (`frontend_eligible: false`) sealing validation, Drive readback of the four
  immutable files, and the handoff write. It exists because the state JSON is
  frozen locally before those phases and cannot attest to them.
- `tools/procedural-audit.mjs` (new) and `tools/validate.mjs` — the checks, with
  precise messages (for example `F3 missing from procedural audit`, `source
  recovery required but not recorded`, `handoff completed before Drive
  readback`, `material procedural gap not surfaced`). The validator now pairs a
  child state with its parent and a completion record with the state it seals,
  accepts explicit files (`node tools/validate.mjs <state> <record>`), and
  rejects a REAL state without a completion record. Lineage messages now read
  `Sunday parent_run_id must be null` and `Sunday origin_sunday_run_id must equal
  its own run_id`.
- Fixtures — `tests/fixtures/build_positive_fixtures.mjs` now generates the
  procedural audit for fixtures A-F, two completion records, the extra evidence
  and reasoning outputs they point at, and the prior-week timeline that
  intermediates inherit. Fixture F named a parent (E) whose origin was not its
  own origin; F and the handoff G now carry E as origin. No historical document
  was rewritten.
- Tests — `tests/procedural_audit.test.mjs` (23 mandatory cases plus 14
  boundary cases) and 11 end-to-end cases in `tests/negative_validator_smoke.mjs`.
  `npm test` and the CI workflow run them.

### Clarification: upload authorization and completion-record isolation

The first version of this section said the state was "published before"
validation. That was wrong: the state JSON is generated and frozen locally
before validation, and nothing is uploaded to the Output folder before the
local validation passed.

- `schema/run_completion_record.schema.json`: each published file now records
  `uploaded_at`; `storage_plane` is the constant `CONTROL`.
- `tools/procedural-audit.mjs`: an upload before the local validation completed
  (or while it is not `COMPLETE`), outside the Drive readback phase, or after its
  readback, is rejected; control-plane file names cannot be listed among the four
  Output files; `isFrontendEligibleMarketState` is the reference ingestion
  predicate. `tools/validate.mjs` checks the record is control-plane and not
  frontend eligible.
- `specs/GOLD_RUN_PROCEDURAL_AUDIT_SPEC.md` section 13 fixes the order of
  operations, the storage location (`Gold Sunday Read Control/run_records/`) and
  the ingestion filter; `GOLD_CONTINUOUS_RECAP_PROTOCOL.md` section 3 now lists
  the completion record among the documents ingestion must ignore.
- Tests X15 to X17. The trading application repository was not modified; it must
  apply the documented predicate.
