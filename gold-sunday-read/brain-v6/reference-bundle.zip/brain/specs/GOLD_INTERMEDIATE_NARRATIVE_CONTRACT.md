# Récap intermédiaire — même contrat éditorial v6

L’intermédiaire n’est ni un Sunday recopié ni un bref delta sans explication.
Il charge l’état validé immédiatement précédent et son reçu, consomme le handoff,
audit les six familles et réapplique le manuel. Il produit le même JSON éditorial,
les mêmes six jugements et la même profondeur que le Sunday, avec un nouveau cutoff.

L’ouverture répond au biais actuel, aux filtres futures/CFD, aux raisons et aux
conditions futures. `evolution_review` répond ensuite à ce qui a changé depuis le
parent : nouvelles observations, fondations toujours valables, éléments renforcés,
affaiblis, invalidés, facteurs exogènes, inconnues et prochains tests. Chaque carte
est une explication française complète avec références d’audit. Aucun id brut
ni lien ne s’affiche au lecteur.

`parent_run_id` et `parent_cutoff` correspondent exactement au parent chargé.
`judgment_changes` explique chaque valeur modifiée parmi les six jugements, avec
valeur précédente, actuelle, raison, conséquence et preuves datées.
`scenario_transitions` distingue condition déclenchée, transmission partielle ou
confirmée, flux en attente ou confirmés, contradiction, invalidation, expiration
ou non-testé. Une condition isolée ne valide pas tout un chemin causal.

Les 32 questions sont conservées ; chaque réponse explique ce qui est neuf ou
pourquoi elle reste pertinente et porte son contrôle daté. La chronologie de
semaine passée reste identique au parent, vérifiée par hash canonique dans
`weekly_history_sha256`. Une correction exige `correction_fr`, sa preuve et sa
conséquence. Pour le premier parent antérieur à v6, expliquer le mapping historique
dans ce champ ; ne pas fabriquer rétroactivement ses six nouveaux jugements.

Les anciens articles gardent leur statut historique. Une nouvelle observation
d’une série existante est autorisée avec date de mesure/publication. Réconcilier
l’ouverture, toutes les explications et scénarios avec la nouvelle conclusion.
Ne pas maintenir une phrase « publication future » lorsque le résultat est déjà
consommé. Distinguer mouvement, cause, scénario conditionnel et invalidation.

Produire quatre fichiers immuables, puis le prochain handoff et le reçu final
selon le même ordre que le Sunday. Le planning reste motivé économiquement,
maximum deux intermédiaires avant vendredi New York. Le bouton manuel de contrôle
pré-trade reste une fonctionnalité séparée à concevoir ultérieurement.
