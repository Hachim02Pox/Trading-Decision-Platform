# Continuité Sunday / intermédiaires — v6

Le Sunday initialise une semaine ; les intermédiaires réévaluent son état roulant.
Ils utilisent tous `schema/gold_editorial.schema.json`, le même récit explicatif,
les mêmes familles/questions et les mêmes filtres. Les archives restent immuables.
Le manuel, la collecte et les critères de preuve continuent à s’appliquer.

`meta` conserve run_id, run_type, parent_run_id, origin_sunday_run_id, week_of,
generated_at et les deux cutoffs. Sunday : parent null, origine propre, index 0.
Intermédiaire : dernier état validé comme parent, origine conservée, index +1,
fenêtre commençant exactement au cutoff parent. Aucun saut silencieux vers Sunday
si un intermédiaire plus récent existe. Maximum index 2, arrêt vendredi 00:00 NY.

Chaque intermédiaire produit une lecture actuelle complète et `evolution_review`.
Il ne répète pas la recherche de semaine passée : `chronology` est héritée, avec
correction sourcée explicitée si nécessaire. Les faits datés ne deviennent pas
neufs parce qu’ils sont cités de nouveau. Les articles sont nouveaux seulement
si publiés après le cutoff parent ; une série peut être relue pour une observation
plus récente, avec période, méthode et contrat comparables. Les reprises d’une
agence ne multiplient pas les preuves indépendantes.

Vérifier toutes les familles avant UNCHANGED. Une publication retardée n’est pas
un échec de recherche, et l’absence de données n’est pas une confirmation.
Rechercher aussi géopolitique, énergie, financement/collatéral, crédit, fiscal,
interventions de banque centrale, marché/clearing, liquidation et sanctions.
Relier chaque développement à son canal, sans double comptage ni causalité
certaine déduite d’une attribution journalistique. Un nouveau moteur peut imposer
un nouveau scénario et une autre hiérarchie ; expliquer pourquoi.

Les transitions distinguent condition, transmission et flux. Une branche non testée
reste non testée. Un scénario invalidé ne rend pas automatiquement vrai l’opposé.
La lecture globale et toutes les explications doivent être réconciliées au nouveau
cutoff. Les deux filtres restent conditionnels et ne sont pas des ordres de trading.

## Output et Control

Output : quatre publications immuables par run, uniquement après validation locale.
Control : un NEXT_GOLD_RECAP.json à Drive file ID stable, plus reçus immuables sous
run_records. Le handoff a `document_type: NEXT_GOLD_RECAP_HANDOFF` et
`frontend_eligible: false`. Le reçu GOLD_RUN_COMPLETION_RECORD est également exclu.
Le terminal sélectionne seulement GOLD_MARKET_STATE, frontend_eligible true,
meta.data_mode REAL, version reconnue et reçu de validation vérifié. Jamais un
simple « dernier JSON » ni un tri sur le nom pour choisir l’état.

Le handoff contient prochaine heure et raison économique, conditions à tester,
données à actualiser, fondations, branches, inconnues et scan exogène indépendant.
Il est écrit après readback des quatre fichiers. CLOSED conserve le checkpoint
mais ne planifie rien. Le prochain Sunday compare ce checkpoint seulement après
sa propre collecte/interprétation. Voir la spécification handoff pour le format.

Le résumé public du prochain récap peut exposer date et raison française, jamais
le fichier Control complet. Le contrôle manuel avant trade et le module options
restent hors de cette migration ; ils ne remplacent ni ne suppriment les récaps.
