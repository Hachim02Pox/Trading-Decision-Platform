# GOLD SUNDAY READ — SOURCE RECOVERY REGISTRY

## New-run recovery discipline (from 26 September 2026)

Apply `GOLD_FORWARD_DECISION_AND_WEEKLY_CYCLE_SPEC.md` before declaring a
question UNKNOWN or PARTIAL. This file is a list of *candidates*, not proof
that any given source was actually accessed. Do not copy a single source-
recovery statement to unrelated questions. The direct provider, exact
series/contract, measurement date, attempt timestamp, observed error or
comparability gap and a question-specific next action belong in the source
audit and bilingual unknown explanation. Distinguish source-not-retrieved
from a series published only after cutoff. No unaudited claim of successful
QuantWheel sign-in, OTP retrieval, or dealer-gamma observation.

When a same-day value might exist, check the matching direct publication:

| Target | First recovery path | Essential limitation |
| --- | --- | --- |
| US 2Y / 10Y, real TIPS and 2s10s | U.S. Treasury daily nominal and real yield tables, matched date/tenor | Distinguish data-publication time from observed market time; 2s10s needs same-day legs. |
| COT | CFTC futures-only/disaggregated report and release schedule | Published Friday for Tuesday positions; never call it Friday positioning. |
| ETF share count | The fund issuer's dated GLD/IAU holdings and shares | Shares are not the same measurement as estimated dollar flow; check both endpoints before declaring unavailable. |
| GC/MGC volume and open interest | CME product-specific daily volume/OI with matched contract and session | A single current level does not establish change or dealer sign. |
| Next FOMC/pricing | Fed calendar and CME FedWatch or listed futures with a recorded timestamp | Meeting date and probability are distinct questions; verify observed rather than infer. |
| USD crosses, HY/IG, RRP/TGA | Dated direct market/central-bank series and publisher-specific lag | A missing intraday quote does not imply that the latest official daily series is absent. |
| Central banks / China physical | Latest WGC/official declared release; timed Shanghai and international benchmark with USD/CNY | A structural update need not be daily; a non-comparable premium must not be fabricated. |

Options-specific expiry/tenor/skew/model-GEX recovery below is used primarily
for a separately triggered pre-execution check. New weekly F5 can explicitly
defer these to that check when immaterial to the weekly macro judgment. If
a dated weekly options observation exists and contradicts the thesis, review
it; deferral is never a license to ignore available counterevidence. Keep
true dealer inventory unknown when only open interest/model estimates exist.

# F5 — ETF flow and news recovery

Optional ETF flow recovery/discovery candidate:
`https://www.etf.com/sections/daily-etf-flows`. It is secondary and must not
replace an available official issuer observation; preserve publication date,
measurement window and whether the value is reported or aggregated.

Optional news omission/discovery candidate: `https://finviz.com/news`. It is a
discovery surface, not automatically primary evidence. Follow items to the
original release where possible, do not count syndicated copies independently,
separate event fact from attribution and inference, and respect the parent
cutoff for intermediate recaps.

## Purpose

This file is an advisory fallback registry for difficult-to-source evidence.

It is NOT a mandatory provider list.

Normal research behavior remains:

1. Research the requested fact normally across the web.
2. Prioritize freshness, reliability, semantic exactness and direct authoritative data when available.
3. If the field is established correctly, stop.
4. If a REQUIRED field remains UNKNOWN or PARTIAL because the source could not be found, consult this registry.
5. Attempt the relevant recovery source(s).
6. If the field still cannot be established correctly, preserve UNKNOWN / PARTIAL.

Never manufacture a value merely because a candidate source is listed here.

Semantic correctness is more important than filling every field.

---

# F4 — TREASURY AUCTIONS

## Requested evidence

- auction result
- high yield
- bid-to-cover
- direct / indirect / primary dealer participation when relevant
- amount tendered / accepted
- auction date
- maturity

## Recovery source

Preferred primary source:

U.S. Treasury / TreasuryDirect — official auction results.

Use TreasuryDirect before secondary media transcriptions when accessible.

Secondary sources may still be used for market interpretation.

The auction FACT itself should preferentially come from TreasuryDirect.

If the primary result is inaccessible:
use a reliable secondary source and mark provenance accordingly.

---

# F5 — GOLD OPTIONS

## Numerical skew / risk reversal

Recovery candidate:

CME Group QuikStrike and CME official Gold options tools.

Search specifically for:

- implied volatility
- volatility smile / skew
- call versus put volatility
- risk-reversal-type metrics
- expiration-specific option information

IMPORTANT:

Do not assume that a generic skew measure equals a 25-delta risk reversal.

Only report a numerical 25-delta risk reversal if:

- Gold is the correct underlying;
- expiration is identified;
- delta convention is identifiable;
- call and put sides are comparable;
- the value can actually be established.

Otherwise:

PARTIAL / UNKNOWN.

## Open interest by strike / expiration

Preferred recovery:

CME Group QuikStrike / official CME option Open Interest tools.

Capture when available:

- product
- expiration
- strike
- call / put
- open interest
- change in open interest
- trade date

## Dealer gamma

True dealer gamma is not directly observable from public OI alone.

Do NOT convert option OI into an observed dealer gamma fact.

If a gamma estimate is calculated, it must be explicitly labelled:

MODEL-DERIVED / ASSUMPTION-DEPENDENT

and must disclose:

- option-chain inputs
- methodology
- dealer-sign convention
- measurement timestamp

If these conditions are not met:

Dealer gamma = UNKNOWN.

---

# F5 — GOLD ETF FLOWS

## Requested evidence

- marginal Gold ETF flows
- direction of capital
- recent creation / redemption behavior
- global context when available

## Recovery sources

World Gold Council remains a preferred source for global Gold ETF holdings and flows.

Important limitation:

A global daily Gold ETF series may not be publicly available with the required completeness.

For short-window analysis:

individual large fund holdings such as GLD / GLDM may be used when available,
but they must be explicitly identified as a PARTIAL universe.

Never add incompatible fund subsets or measurement windows and label them as global Gold ETF flow.

If only a partial daily universe is available:

status = PARTIAL.

---

# F5 — FUNDING / FORCED FLOWS

## Requested concepts

- direct leveraged-Gold funding conditions
- mechanically forced buyer / seller
- carry stress
- funding fuse
- cross-currency basis
- dealer balance-sheet stress

These concepts may not have one direct public metric.

Search for direct evidence first.

Possible contextual proxies include:

- USDJPY
- JPY funding conditions
- JGB stress
- SOFR / overnight funding
- credit spreads
- MOVE / rates volatility
- VIX
- liquidation reporting
- margin changes
- positioning / OI behavior

IMPORTANT:

A proxy is not proof of a forced buyer or seller.

Do not claim:

"forced liquidation"

unless a mechanical constraint or credible evidence is actually established.

If actor / constraint / funding mechanism cannot be identified:

UNKNOWN.

---

# F2 / F5 — MOVE

Primary MOVE data may be licensed or inaccessible.

Attempt a legitimate primary source if available.

If not:

- use a reliable redistribution;
- record the ultimate origin when identifiable;
- mark source quality accordingly.

Primary MOVE unavailability does NOT block the family.

PARTIAL is acceptable.

---

# F3 / F5 — CROSS-CURRENCY BASIS AND DEALER CAPACITY

Requested evidence may include:

- cross-currency basis
- dealer balance-sheet capacity
- signs of USD funding stress

Search for direct observable data first.

Do not infer exact dealer balance-sheet capacity from general market stress.

If only contextual proxies are available:

status = PARTIAL.

If no defensible evidence exists:

status = UNKNOWN.

---

# CROSS-ASSET INTRADAY EVENT DECOMPOSITION

Requested when material:

synchronized reaction around an event in:

- nominal yields
- real yields
- breakevens
- USD / FX
- Gold

Only calculate precise intraday relationships if timestamp-compatible series are available.

Do NOT reconstruct exact intraday decomposition from narrative articles.

Articles may support:

REPORTED REACTION

but not a precise synchronized calculation.

If timestamp-compatible data is unavailable:

PARTIAL / UNKNOWN.

---

# F6 — CHINA PHYSICAL

## Requested evidence

- Shanghai premium / discount
- SGE benchmark
- withdrawals
- imports
- investment demand
- jewelry demand

Prefer:

- Shanghai Gold Exchange
- official Chinese data
- customs data
- credible industry datasets

## Shanghai premium

A deterministic premium calculation is allowed only if:

- SGE benchmark price is available;
- comparable international Gold price is available;
- FX conversion is available;
- timestamps / windows are sufficiently aligned;
- methodology is disclosed.

Otherwise:

PARTIAL / UNKNOWN.

## Publication lag

If current-month imports or withdrawals have not yet been published:

use the latest available data.

Explicitly disclose the lag.

Publication lag is NOT a research failure.

---

# F6 — CENTRAL BANK GOLD

Separate:

DECLARED / REPORTED purchases

from:

ESTIMATED full-universe demand.

Never add incompatible universes or periods.

If current-month country-level reporting is incomplete:

use latest available published data and disclose the lag.

Unreported purchases may remain:

ESTIMATED

or:

UNKNOWN

depending on evidence.

Do not convert an estimate into a declared purchase.

---

# EVENT-SPECIFIC MARKET REACTION

Example:

isolated market reaction to a Fed speaker.

Search for:

- timestamped reporting
- timestamped market data
- explicit before / after observations

If the speech itself is known but its isolated market reaction cannot be separated from other contemporaneous events:

speech fact = DECLARED

market reaction = UNKNOWN.

Do not manufacture an event reaction.

# VALIDATED RECOVERY SOURCES — 2026-09-14

The following recovery sources were reviewed after the first full Sunday Read benchmark.

General rule remains unchanged:

NORMAL WEB RESEARCH
→ if the required fact is established correctly: STOP
→ otherwise consult the relevant recovery source below
→ if the recovery source resolves it correctly: preserve evidence
→ otherwise preserve UNKNOWN / PARTIAL

These sources are fallbacks, not mandatory starting points.

Never force a field to become ANSWERED merely because a recovery source exists.

---

# F4 — TREASURY AUCTIONS

## Preferred recovery source

U.S. Treasury / TreasuryDirect official auction results.

Use TreasuryDirect as the preferred source for auction FACTS when available.

Requested fields may include:

- security / maturity
- auction date
- high yield
- bid-to-cover
- amount tendered
- amount accepted
- direct bidder awards
- indirect bidder awards
- primary dealer awards

Rule:

Normal web research
→ if auction facts remain incomplete
→ use TreasuryDirect official auction results / historical results
→ preserve official values
→ use media only for market interpretation, not as the preferred source for the auction fact.

Status when official result is available:

ANSWERED

---

# F5 — GOLD OPTIONS — OPEN INTEREST

## Preferred recovery source

CME Group QuikStrike official options tools.

Relevant tools include:

- Open Interest Heatmap
- Open Interest Profile
- Most Active Strikes / Volume & Open Interest tools

Attempt to recover:

- Gold option product
- expiration
- strike
- call / put
- open interest
- change in open interest
- trade date

Rule:

Normal web research
→ if strike/expiration OI remains unavailable
→ attempt CME QuikStrike
→ extract only values actually visible and identifiable.

Do NOT infer dealer inventory sign from open interest.

Open interest by strike is an OBSERVED positioning input.

Dealer positioning is not.

If QuikStrike is inaccessible or the exact expiration/product cannot be established:

PARTIAL / UNKNOWN.

---

# F5 — GOLD OPTIONS — NUMERICAL SKEW / 25-DELTA RISK REVERSAL

## Recovery candidates

1. CME Group QuikStrike / QuikVol
2. FlashAlpha Gold / GC skew tools

CME is preferred for official underlying option information.

FlashAlpha may be used as a secondary recovery source when it exposes
Gold-specific 25-delta call/put implied volatility or skew.

Requested evidence:

- 25-delta call IV
- 25-delta put IV
- risk reversal = call IV - put IV
- expiration
- underlying Gold contract
- observation date

IMPORTANT:

Do not assume that a generic skew chart equals a 25-delta risk reversal.

Only report numerical 25-delta RR when:

- the Gold underlying is identifiable;
- expiration is identifiable;
- both call and put 25-delta IV are available or the RR itself is explicitly supplied;
- measurement definition is sufficiently clear.

If exact delta convention or measurement cannot be established:

status = PARTIAL.

If no defensible number is available:

status = UNKNOWN.

Do not manufacture a value by visually estimating a chart with false precision.

---

# F5 — DEALER GAMMA / GEX

True dealer inventory and true dealer gamma sign are not publicly observable from listed open interest alone.

## Recovery candidates

- CME QuikStrike for option-chain inputs
- FlashAlpha GC GEX as a MODEL-ESTIMATED metric

FlashAlpha GEX must NEVER be labelled:

OBSERVED DEALER GAMMA

It may only be represented as:

MODEL_ESTIMATED / ASSUMPTION_DEPENDENT GEX

because dealer-side positioning must be inferred using a positioning convention/model.

If using a model-estimated GEX value, disclose when possible:

- source
- underlying
- expiration universe
- OI basis
- gamma methodology
- dealer-sign assumption
- observation date

Possible outputs include:

- estimated GEX
- estimated gamma flip
- estimated call wall
- estimated put wall

These remain model outputs, not observed dealer books.

Rule:

Normal web research
→ if useful option convexity information remains missing
→ attempt FlashAlpha/CME
→ if a transparent model-derived value exists, classify MODEL_ESTIMATED
→ otherwise UNKNOWN.

True dealer gamma may legitimately remain UNKNOWN.

---

# F5 — GOLD ETF FLOWS

## Structural/global source

World Gold Council remains the preferred source for broad global Gold ETF context.

Use WGC for:

- weekly / monthly global holdings
- global flows
- regional trends
- historical structural context

## Daily recovery source

Recovery candidate:

WatchGold / bold.report daily Gold ETF flow and holdings aggregation.

This is a THIRD-PARTY AGGREGATOR.

It may be used for:

- daily directional flow
- daily aggregate holdings changes
- fund-level daily changes
- marginal-flow context

It must NOT automatically be treated as equivalent to the official WGC universe.

Rule:

Normal web research
→ use WGC when its frequency satisfies the question
→ if DAILY marginal flow is specifically required and WGC cannot answer it
→ attempt WatchGold / bold.report
→ label clearly:

AGGREGATOR_COMPILED_DAILY_FLOW

→ cross-check direction with major funds / WGC context when possible.

If coverage or methodology cannot be validated:

PARTIAL.

Never combine incompatible WGC monthly totals and aggregator daily totals
as though they were one homogeneous series.

---

# F5 — LEVERAGED GOLD FUNDING / MARGIN PRESSURE

There is no known single public metric representing the direct funding cost
of all leveraged Gold positions.

## Recovery sources / observable proxies

### CME margin notices

Use CME clearing / margin notices to detect material changes in Gold futures
margin requirements.

This is useful for identifying changes in collateral pressure.

### Gold futures basis / co-basis

A Gold futures-versus-spot basis may be used as a funding/carry proxy when
the underlying prices and timestamps are sufficiently compatible.

Possible recovery source:

Gold Basis Monitor or another transparent basis source.

IMPORTANT:

These are PROXIES.

They do not directly measure:

- broker-specific leverage
- margin loans
- hedge-fund financing cost
- forced liquidations

Rule:

If Gold-specific funding evidence is unavailable:

attempt:
- CME margin changes
- futures/spot basis
- broader funding context

Classify as:

PARTIAL / PROXY

Never present SOFR, basis or margin requirement alone as direct proof of
leveraged-Gold funding stress.

---

# F5 — FORCED BUYER / FORCED SELLER

True forced-flow identification is structurally difficult.

## Recovery evidence

CFTC COT may be used to observe:

- Managed Money positioning
- gross longs / shorts
- weekly position changes
- crowding
- positioning extremes

Other transparent model-based CTA estimates may be used only as:

MODEL_ESTIMATED

COT cannot directly prove:

- margin call
- forced liquidation
- mechanical short covering
- CTA execution
- dealer hedging flow

Rule:

Use positioning and flow evidence to test whether a forced-flow hypothesis
is plausible.

Do NOT promote:

crowding
+
price move
+
OI change

into proof of forced liquidation.

Unless the mechanical constraint itself is credibly established:

forced actor = UNKNOWN.

---

# F3 / F5 — CROSS-CURRENCY BASIS

A reliable free daily USD/JPY cross-currency basis series has not been established.

Do NOT substitute:

USDJPY spot

for:

USD/JPY cross-currency basis.

USDJPY may remain useful as a funding/carry CONTEXT variable,
but it does not answer the basis question.

Rule:

Normal research
→ attempt to find legitimate current basis evidence
→ if no reliable free series exists
→ preserve:

UNKNOWN / FREE_SOURCE_NOT_FOUND

Do not manufacture a basis estimate from spot FX alone.

---

# F3 / F5 — DEALER BALANCE-SHEET CAPACITY

## Preferred recovery source

Federal Reserve Bank of New York — Primary Dealer Statistics / FR2004.

Relevant observable proxies may include:

- Treasury dealer positions
- financing / repo
- securities fails
- transaction activity
- inventory changes

These are official aggregate dealer statistics.

They are NOT Gold-specific dealer balance-sheet measurements.

Classification:

DEALER_BALANCE_SHEET_PROXY

Rule:

Normal research
→ if dealer/intermediation capacity is material
→ use NY Fed Primary Dealer Statistics where relevant
→ describe the observed aggregate condition
→ never claim it directly measures Gold dealer capacity.

PARTIAL / PROXY remains appropriate.

---

# F2 — MOVE INDEX

MOVE is a licensed index.

If a legitimate primary free source is unavailable:

recovery sources may include reputable free chart providers such as:

- TradingView
- Investing.com

Use them only for:

- current MOVE level
- direction
- approximate recent change when reliably observable

Clearly disclose secondary provenance.

Do NOT claim access to an official ICE/BofA free historical dataset if one
is not available.

If exact historical observations cannot be established:

PARTIAL.

Primary-data unavailability does not block F2.

---

# CROSS-ASSET INTRADAY EVENT DECOMPOSITION

The ideal requested evidence around events may include synchronized:

- nominal Treasury yield
- real Treasury yield
- breakeven
- USD / DXY
- Gold

High-frequency public real-yield and breakeven data may not be available.

Official Treasury / FRED daily observations may be used for the broader
daily move but NOT presented as an intraday 08:30 / 14:00 reaction.

Secondary intraday charts may support:

REPORTED / OBSERVED INTRADAY REACTION

for variables actually visible intraday.

Rule:

Do not create a synchronized real-yield/breakeven decomposition unless
timestamp-compatible data actually exists.

If real yields are only daily:

state that explicitly.

PARTIAL / UNKNOWN is valid.

---

# F6 — SHANGHAI GOLD PREMIUM

## Preferred recovery source

World Gold Council — China / Shanghai Gold premium and discount dataset.

Prefer the existing WGC calculated series when it provides the required
daily observation.

This is preferable to reconstructing the premium manually when the WGC
series is available and sufficiently fresh.

## Secondary recovery / reconstruction

If the required WGC observation is unavailable, a deterministic calculation
may be attempted using:

- Shanghai Gold Exchange benchmark
- comparable international Gold benchmark
- compatible FX conversion
- sufficiently aligned timestamps

The methodology must be disclosed.

Rule:

Normal web research
→ attempt WGC Gold premium dataset first
→ if unavailable/stale for required window
→ attempt primary SGE-based reconstruction
→ if timestamps cannot be aligned defensibly
→ PARTIAL / UNKNOWN.

Never introduce false precision through mismatched timestamps.

---

# F6 — CHINA GOLD IMPORTS / SGE WITHDRAWALS

## Preferred sources

### SGE withdrawals

Shanghai Gold Exchange monthly reports.

Use the latest published monthly value.

### Imports

Prefer official Chinese customs data where accessible.

Monthly publication lag is expected.

Rule:

If current-month information has not yet been published:

use the latest available observation.

Explicitly state:

AS-OF
publication date
measurement month
lag

Do NOT classify normal publication lag as failed research.

status may be:

PUBLICATION_LAG

rather than UNKNOWN.

---

# F6 — CENTRAL BANK GOLD PURCHASES

World Gold Council remains a preferred aggregation source for central-bank
Gold statistics.

Maintain strict separation between:

DECLARED / REPORTED country-level reserve changes

and:

ESTIMATED full-universe central-bank demand.

Current-month data may legitimately be incomplete because of publication lag.

Identity of unreported buyers remains UNKNOWN unless directly supported.

Do not infer the identity of undisclosed purchasers from aggregate estimates.

---

# EVENT-SPECIFIC MARKET REACTION

When attempting to isolate a reaction to:

- Fed speakers
- CPI
- NFP
- FOMC
- other macro events

possible recovery evidence may include:

- CME FedWatch repricing
- timestamped Gold prices
- timestamped DXY
- timestamped Treasury-yield charts
- reputable timestamped market reporting

Official Treasury daily yields must not be described as intraday data.

If multiple important events occurred in the same window and their effects
cannot be separated:

EVENT FACT = established

ISOLATED MARKET REACTION = UNKNOWN / PARTIAL

Do not force causal attribution.
