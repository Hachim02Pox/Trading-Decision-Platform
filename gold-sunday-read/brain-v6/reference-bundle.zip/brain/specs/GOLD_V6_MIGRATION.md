# Officialisation éditoriale v6 — 28 septembre 2026

Demande d’Hachim : rendre officiel le résultat éditorial expérimental et appliquer
la même granularité aux intermédiaires. Ce changement concerne le contrat du dépôt,
pas un nouveau biais de marché ni le déploiement du terminal externe.

## Champs et frontières

| Avant / expérimental | Officiel v6 |
|---|---|
| JSON libre experimental-1 | gold_editorial.schema.json, format_version 6.0 |
| GOLD_EXPERIMENTAL_EDITORIAL_DRAFT | GOLD_MARKET_STATE, meta.data_mode REAL ou FIXTURE |
| run_id isolé | meta avec parent, origine, cutoffs ; weekly_cycle 0/1/2 |
| opening_thesis, decision_panel, six_judgments | conservés, structurés et validés |
| opportunity_quality / execution_readiness / final edge | solidité des preuves / portée fondamentale / conclusion séparée futures et CFD |
| presentation FR/EN V3/V4 | français complet dans champs éditoriaux ; aides anglaises facultatives fidèles |
| aperçu comprenant des liens d’audit | projection de lecture sans sources/URLs/IDs ; preuve conservée à part |
| intermédiaire ancien résumé/delta | même JSON complet + evolution_review, 32 réponses contrôlées |
| ancien six_verdicts du handoff | six jugements v6, fundamental_eligibility ; enveloppe et stable Drive ID conservés |
| brouillon isolé sans handoff | quatre Output + NEXT_GOLD_RECAP + completion record Control selon protocole |

Les questions, le manuel et Source Recovery sont identiques octet pour octet.
Les anciens contrats sont copiés dans specs/legacy pour la lecture des archives.
Les validateurs et fixtures historiques restent testés ; les nouveaux REAL ne
peuvent pas revenir silencieusement à l’ancien format après la date d’effet.

Le Sunday de référence reprend le contenu daté du 27, avec une correction de
cohérence : spread 2s10s du lundi = 4,96 − 4,76 = 20 pb. Il est marqué FIXTURE,
avec traces synthétiques explicites. L’intermédiaire est un exemple synthétique
de réévaluation limitée, jamais présenté comme une observation réelle ultérieure.
Aucun de ces exemples ne doit être ingéré comme une publication actuelle.

## Intégration future du terminal

Le backend doit discriminer format_version, conserver JSON/source audit complet,
lineage et receipt, rejeter FIXTURE et fichiers Control pour le current state.
L’API lecteur utilise la projection explicite de tools/editorial.mjs ou une
projection équivalente testée. Le frontend conserve la thèse/panneau en première
vue, les jugements, puis les détails progressifs et nœuds lisibles indépendamment.
Ne pas afficher récursivement le JSON ni les sources. Aucun modèle ne doit
réécrire/raccourcir les raisonnements pendant le rendu.

Vérifier cette intégration avec les deux fixtures, le Markdown exact, les archives,
les états UNKNOWN/PARTIAL, les deux filtres, les transitions et les limites de
fraîcheur. Le dispatcher doit comprendre handoff ACTIVE/CLOSED, la nouvelle forme
des jugements et la limite de deux intermédiaires. La migration du contrat ne
modifie ni le handoff Drive déjà actif, ni une automatisation, ni l’application.
Le prompt Codex pour cette application sera une étape distincte demandée par l’utilisateur.

Le bouton manuel de vérification de thèse et le module options/GEX restent à
concevoir ultérieurement. Leurs anciens schémas de démonstration sont conservés
pour compatibilité, sans prétendre qu’un nouveau parcours est implémenté.

## Validation

npm test couvre les anciens contrats et la matrice v6 ; npm run validate contrôle
toutes les fixtures. v6 ajoute schéma strict, gates, couverture, preuves,
chronologie, phases, arbre, continuité, projection sans liens et parité exacte.
Un preflight séparé évite d’attester Drive avant upload. Les checks sont des
conditions de cohérence, pas une validation scientifique des prévisions.

La validation historique a aussi révélé un décalage préexistant : le code et le
test de l’exception partielle du 25 septembre acceptaient `partial_week_exception`,
mais le schéma ne déclarait pas cette propriété. La propriété est désormais typée
avec les dates historiques exactes ; cela n’autorise aucune nouvelle exception.

## Vérifications de cette migration

Le 28 septembre 2026, sous Node v24.19.0 : `npm test` passe intégralement :
215 contrôles de documents, 39 cas de matrice négative, 14 contrôles de présentation,
45 tests d’audit de procédure, 17 tests famille/évolution/cycle et 62 tests éditoriaux
v6, plus les contrôles des anciens schémas options et de cohérence documentaire.
Les tests v6 couvrent les deux filtres, données manquantes, fraîcheur, questions,
scénarios, preuves, ordre des phases, parité Markdown, parent, handoff et reçu final.
Les archives/questions/manuels sont préservés. Les fixtures éditoriales et leurs
rapports se régénèrent sans différence. Aucune recherche de marché nouvelle,
livraison Drive, modification de scheduler ou vérification du terminal externe
n’est revendiquée par ces tests.

Le scan par défaut des fixtures ignore les fichiers temporaires de tests négatifs ;
ceux-ci restent vérifiés explicitement par leur matrice. Cela empêche qu’un test
interrompu laisse un cas volontairement invalide contaminer la validation suivante.
