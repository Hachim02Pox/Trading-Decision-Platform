# Lecture future et cycle hebdomadaire — v6

Les exigences de recherche du 26 septembre sont conservées. Leurs anciens champs
`forward_verdict_cases`, `edge`, `opportunity_quality` et `execution_readiness`
sont remplacés en sortie par les six jugements éditoriaux et les deux filtres.
La version précédente est archivée dans `legacy/`.

## Raisonnement tourné vers l’avenir

Séparer mouvement observé, driver économique, transmission, alternative et surprise
encore possible. Comparer publication, consensus, révisions, prix anticipé et
réaction observable. Ne pas extrapoler la baisse/hausse passée ; ne pas compter
les échos corrélés Fed/taux/dollar comme des moteurs indépendants.
Chaque jugement fournit cas actuel, mécanisme, meilleur contraire, préférence,
déjà intégré, prochain test, invalidation et conséquence. En cas d’incertitude,
dire précisément pourquoi aucun sens ne domine. Conserver plusieurs horizons.

Le positionnement requiert une exposition résiduelle et un mécanisme futur plausibles.
Une baisse passée du COT ou des parts ETF ne suffit pas. Distinguer vulnérabilité,
catalyseur plausible et contrainte observée. Le filtre futures dépend seulement
du biais macro clair, actuel et étayé ; CFD exige aussi l’asymétrie de positionnement
dans le même sens. L’asymétrie directionnelle est expliquée séparément, sans veto
supplémentaire. La technique et la préparation à l’exécution sont hors périmètre.

## Données difficiles

Avant PARTIAL/UNKNOWN : vérifier observation exacte, instrument, fenêtre, publication
et sources accessibles ; consulter Source Recovery si nécessaire. Décrire chaque
essai daté, URL, résultat, obstacle et action suivante dans l’audit. Identifier
la conséquence sur le macro, le positionnement ou seulement le futur diagnostic
options. Ne pas appeler « inexistante » une donnée non récupérée ; ne pas appeler
« accès restreint » un échec sans preuve. Une lacune générique ne suffit pas.

F5 continue CFTC/COT avec population et retard, ETF émetteurs et parts/tonnes,
prix-volume-OI de contrats comparables, roll, marges/funding, acteurs marginaux
et contraints, demande physique/structurelle. Percentiles seulement calculables,
skew comparé à une base pertinente, gamma dealer inconnu sans méthode défendable.
F5_OPTIONS reste une question obligatoire : NOT_APPLICABLE est permis si
l’absence est réellement sans conséquence pour la lecture hebdomadaire et que
le diagnostic par contrat/échéance est différé. Ne pas écarter un signal options
fiable et matériel déjà disponible. Aucun worker/bouton options n’est déployé ici.

## Dates et handoff

Un Sunday indépendant initialise index 0, puis au maximum deux intermédiaires,
index 1 et 2, liés au parent immédiat. Cutoff et prochaine exécution doivent être
dans la semaine d’origine avant vendredi 00:00 New York. Après index 2, ou après
un premier intermédiaire jeudi, fermer le handoff. Le fermer également lorsqu’il
n’existe plus de point de contrôle utile avant vendredi.

ACTIVE exige une heure future motivée par un événement/condition et un délai
suffisant pour observer la transmission. CLOSED exige `next_execution: null`.
Le Drive file ID du handoff reste stable. Le Sunday suivant collecte et raisonne
indépendamment avant la lecture comparative de l’ancien état/checkpoint.
Les faits antérieurs restent historiques, les nouveaux facteurs peuvent changer
la hiérarchie ou remplacer un scénario. Une invalidation ne signifie pas
automatiquement biais inverse. Le bouton manuel hors quota reste une étape future.
