# Présentation officielle v6 (chemin historique conservé)

Le contrat V3/V4 est archivé dans `legacy/GOLD_PRESENTATION_V3_SPEC.md`.
Le lecteur courant utilise `format_version: "6.0"` et le schéma éditorial.
La référence est le rapport validé du 27 septembre, adapté dans la fixture v6.

## Lecture progressive

Première vue : thèse conditionnelle et « Que puis-je envisager ? », réponse directe
futures/CFD, pourquoi, horizon et moment où la lecture doit être réexaminée.
Ensuite : six jugements expliqués, attentes déjà intégrées et surprises possibles,
scénarios et calendrier. Les scénarios sélectionnables, F1–F6, évolution/bridge,
chronologie et vocabulaire se développent à la demande. Les intermédiaires donnent
également « Depuis le dernier récap » au début, sans perdre cette profondeur.

Une interface agréable et concise à l’ouverture ne doit pas tronquer le détail
analytique. Ne pas faire lire une liste de métadonnées pour trouver la réponse.
Éviter les badges omniprésents, les longues répétitions et les codes machine.
Les titres disent ce que le lecteur apprend ; les paragraphes relient fait,
acteur, comportement, conséquence et condition. Expliquer les termes en contexte.

## Projection du lecteur

`readerSections(state)` et `renderEditorialMarkdown(state)` dans
`tools/editorial.mjs` sont la projection déterministe de référence. Le frontend
peut en faire des cartes/accordéons et un graphe sélectionnable tout en conservant
chaque explication. `content_preview.markdown` et le rapport exporté doivent
correspondre exactement à ce rendu. Le terminal ne fabrique pas un nouveau résumé
à partir de données brutes et ne devine pas les explications absentes.

Aucune source, URL, bibliographie, identifiant de run/question/nœud, enum brut,
champ d’audit, journal de recherche ni lien technique dans la lecture utilisateur.
Les dates économiques, chiffres utiles et limites concrètes restent visibles.
Les liens causaux sont des explications économiques, pas des hyperliens.
Conserver les preuves dans le JSON complet et PREUVES_VALIDATION pour l’audit.
La projection fonctionne par liste explicite de champs : ne jamais afficher
récursivement toutes les propriétés du JSON. Échapper les textes dans le terminal ;
ne pas rendre de HTML arbitraire ou de liens injectés dans un champ narratif.

Le français est la version complète obligatoire. Les champs anglais facultatifs
sont des aides fidèles, sans repli silencieux de paragraphes français vers l’anglais.
Une vue anglaise intégrale ne peut être annoncée que si tous ses contenus existent
et ont été contrôlés. Ni la fixture ni ce dépôt ne prouvent un rendu applicatif.

## Contrôles

Vérifier verdicts/panneau/scénarios, ordre, dates, unités et chiffres répétés.
Le validateur contrôle la projection exacte, son hash, l’absence d’URL/markup,
les questions et références, les filtres et la continuité. La relecture humaine
vérifie aussi le sens, les contradictions, l’autonomie des nœuds et l’absence de
répétitions ; un hash ne sait pas juger une explication. Ne pas utiliser l’ancienne
couverture V3/V4 pour forcer des champs d’exécution dans v6.
