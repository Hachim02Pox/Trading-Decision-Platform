# Prompt Codex — intégrer Gold éditorial v6 dans Trading Platform

Tu travailles dans **Hachim02Pox/Trading-Decision-Platform**, pas dans un dépôt
« Trading ». Termine l’intégration backend, API, frontend, ingestion et contrôle
du Gold Sunday Read et des récaps intermédiaires. Les données Drive sont déjà
migrées. Inspecte, implémente, teste, documente, commit et push les changements
autorisés. Vérifie les déploiements réellement accessibles et rapporte les
étapes inaccessibles ; un push ne prouve pas un déploiement réussi.

Le bouton manuel de vérification de thèse, le diagnostic options par échéance
et le module GEX seront conçus plus tard. Ne les implémente pas dans cette mission.

## 1. Lire avant de modifier

Lis AGENTS.md, AI_WORKFLOW.md, DESIGN.md pour le frontend et
docs/AUTH_SUPABASE.md avant toute action auth/Supabase/déploiement. Inspecte git
status/diff et préserve le travail préexistant. Ne refais pas les fondations
auth/déploiement déjà fonctionnelles. Le snapshot inspecté pour ce prompt était
`51ad9b3ef0f017b024f2533d3ae0372262a93a73` ; vérifie les évolutions de main.

Lis le README **courant** de Hachim02Pox/gold-market-story-brain/main, puis tous
les documents qu’il impose, notamment collecte, manuel de raisonnement, sortie,
présentation, cycle hebdomadaire, récit intermédiaire, handoff et audit. Lis :

- schema/gold_editorial.schema.json ; schema/next_gold_recap.schema.json ;
  schema/run_completion_record.schema.json ; anciens schémas pour compatibilité.
- tools/editorial.mjs, tools/validate.mjs, tools/procedural-audit.mjs.
- tests/editorial.test.mjs et fixtures éditoriales Sunday/intermédiaire/handoff/reçu.
- specs/GOLD_DRIVE_MIGRATION_2026-09-28.md et GOLD_V6_MIGRATION.md.

Les anciens documents copiés dans Trading Platform peuvent décrire V3/V4/V5 :
ils ne remplacent pas le contrat actif Brain. Ne modifie pas un schéma pour faire
passer un fichier ni les observations de marché pour satisfaire une interface.
Les fixtures sont exclusivement des tests ; ne jamais les publier comme REAL.

## 2. Emplacements et identités exacts

| Élément | ID |
|---|---|
| Gold Sunday Read Output | 1otzXd6sEBAaMn_dh-DmMxoiszs4_7aVm |
| Gold Sunday Read Control | 1cfLw7eK4pnw33P_K4PIq6IgWgXgua8Ot |
| NEXT_GOLD_RECAP.json — **nouvel ID stable actif** | 1vjvIgPV7umsbaCiuUdyxu6R980zg_dsU |
| Control/run_records | 1T881GeH72cVhoz3R0xi50KpfaBVYzt_Y |
| Archive des copies/migration, hors ingestion | 1HMcncHXbZz23drmv05R1TYfNUFcHrnjP |
| Reçu du Sunday migré | 1YSbjdmbNX2R8W_Yr3o6prwQ1OEmvoe41 |

Les quatre fichiers officiels sont déjà dans Output ; **ne les recrée pas** :

| Ancien nom | Nouveau nom | ID conservé |
|---|---|---|
| GOLD_EXPERIMENTAL_2026-09-27_COMPLET.json | sunday_read_2026-09-27.json | 1xw5uGbCNhXsOTzRAKPHoCVUbedvqZ56M |
| GOLD_EXPERIMENTAL_2026-09-27_RAPPORT.md | sunday_read_2026-09-27.md | 1_tNquNaEqdKRGGYlR5UsWcaC6BGTAaKc |
| GOLD_EXPERIMENTAL_2026-09-27_PREUVES_VALIDATION.md | VALIDATION_REPORT_2026-09-27.md | 1na86_VfXkH9gHRlKS2B7fMUL9Ht-umVw |
| GOLD_EXPERIMENTAL_2026-09-27_NOTE_RUN.md | RUN_REPORT_2026-09-27.md | 1us1dIXbCB8WPwqd3Qv53oI4oHBiiacWy |

Run : `gold-sunday-2026-09-27-editorial-v6-01`.
Type SUNDAY, origine égale au run, parent null, index 0, `week_of=2026-09-28`.
Cutoff `2026-09-27T18:57:35.740939Z`. Enveloppe générée le 28 ; **le marché du
lundi n’a pas été réanalysé**. Les phases PARTIAL sont des contrôles techniques
de promotion d’archives, pas des horaires historiques reconstruits. Préserver
research_audit.migration_provenance et les limites du bridge. Le contenu est
REAL historique, jamais une fixture convertie. L’éligibilité au cutoff ne devient
pas une éligibilité actuelle par l’effet du téléchargement ou de la génération.

Le dossier expérimental `1UQrH0qdgCJ6zt7lOvr7WGFVbNHofa8wy` a été vidé puis
supprimé. Les huit copies identiques ont été archivées. Ne chercher aucun fichier
de production à l’ancien emplacement.

L’ancien ID `1kz-OvJ-8lYlV1Z6zOo5Q8wsIWq0Qm1uM` est **retiré**. Il contient
désormais un handoff v12 annulé, renommé RETIRED_NEXT_GOLD_RECAP_v12.json dans
l’archive. Ce n’est ni une valeur par défaut valide ni un fallback. Une copie
intégrale préannulation existe dans l’archive. Le nouveau stable ID ne doit plus
changer lors des runs suivants.

Le handoff courant est v14, logique
`handoff-gold-2026-09-29-post-jolts-v6-01-sealed`. v13 était la création initiale,
puis v14 a été écrit en place après relecture et scellé par le reçu. Si un run
plus récent a déjà renouvelé ce fichier quand tu exécutes ce prompt, respecte
la version courante ; ne restaure pas aveuglément v14.

## 3. Circuit observé et configurations à respecter

Inspecte ces fichiers réels et leurs dépendances :

- .github/workflows/gold-state-refresh.yml et sunday-read-ingest.yml ;
  runtime/README.md et runtime/gold-refresh-trigger.json.
- apps/backend/src/config/env.ts ; goldMarketState/ingestion/discovery.ts,
  driveClient.ts, ingest.ts ; goldMarketState/selection.ts, presentation.ts,
  store.ts ; goldNextRecap/service.ts ; sundayRead/schema.ts.
- apps/backend/src/db/goldMarketStates.ts et migrations associées ; routes du
  serveur pour /api/gold/read/*, prochain récap et /internal/gold/refresh.
- apps/frontend/src/lib/api/goldReadClient.ts et goldNextRecapClient.ts ;
  app/sunday-read/page.tsx ; components/sundayRead/ScenarioTree.tsx,
  V4Presentation.tsx, V5FamilyReadout.tsx ; lib/sundayRead/*.

La chaîne : Work produit/valide → quatre Output + handoff + reçu Control →
push du trigger après livraison → Action → POST `/internal/gold/refresh` →
ingestion Drive → validation/DB → sélection par lignée → API → frontend.
L’Action **ne crée pas une analyse et ne réveille pas Work**.

`gold-state-refresh.yml` réagit au push de `runtime/gold-refresh-trigger.json`
ou à workflow_dispatch. Secrets existants : GOLD_TERMINAL_BACKEND_URL et
INTERNAL_INGEST_SECRET ; header X-Internal-Ingest-Secret. Ne pas créer un second
secret ni afficher leur valeur. Le workflow vérifie le run_id retourné.
Le refresh manuel n’hérite pas du vieux run_id du trigger.

`sunday-read-ingest.yml` appelle `/api/internal/sunday-read/ingest` pendant la
fenêtre du dimanche. Vérifie son articulation avec l’ingestion unifiée v6 ; ne
laisser aucun des deux chemins convertir v6 en V4. La garde datée du 14 septembre
est historique ; elle ne programme pas les intermédiaires.

Configuration observée : GOLD_OUTPUT_FOLDER_ID, fallback GOOGLE_DRIVE_FOLDER_ID ;
GOLD_NEXT_RECAP_FILE_ID, actuellement avec l’ancien ID codé par défaut ; cache
GOLD_READ_CACHE_TTL_SECONDS. Mettre le nouvel ID dans la configuration effective
Railway et corriger/documenter le défaut du code : changer seulement le défaut
ne remplace pas une variable d’environnement déjà définie. Vérifier le dossier
Output effectif et l’accès du lecteur de service Gold aux nouveaux fichiers.
Le connecteur Work a vu sa permission sur le nouveau Control ; tester aussi
avec l’identité réelle du backend, sans rendre les fichiers publics.

Préserver les routes historiques, les archives publiées, l’auth et la base.
Ne pas sélectionner un état selon Drive modifiedTime ou selon le nom seul.

## 4. Backend : v6 explicite, validation et continuité

Créer une discrimination typée entre archives et v6. Les champs
`document_type=GOLD_MARKET_STATE`, `frontend_eligible=true`, `format_version=6.0`
sont **à la racine** v6 ; `data_mode=REAL`, identité, type, statut et cutoff sont
dans meta. Contrairement à l’ancien contrat, v6 n’a pas besoin de
meta.document_type, meta.frontend_eligible, direction_state, presentation.fr/en
ou présentation V4. Ne pas ajouter de faux champs legacy au fichier Drive.

Les fichiers actuels validateFinalRead/processCandidate supposent ces anciennes
formes. Implémente un chemin v6 utilisant le schéma Brain strict, ses contrôles
sémantiques, les références, phases, couvertures, graphe, parité et filtres.
PARTIAL expliqué n’est pas FIXTURE. Un contrôle structurel réussi ne doit pas
transformer une recherche partielle en COMPLETE.

Conserver le JSON d’audit complet en stockage autorisé et ses références. Lire
le reçu dans Control/run_records, vérifier identité, quatre rôles et hash
canonique. Pour un intermédiaire, vérifier le parent publié/scellé, son reçu,
origine, index, cutoff avancé, handoff consommé et chaîne d’ancêtres nécessaire.
Les fichiers Control et archives de migration ne sont jamais des candidats.

Pour la découverte, conserver les noms compatibles :
`sunday_read_YYYY-MM-DD[_suffix].json` et
`gold_intermediate_YYYY-MM-DD[_suffix]_NN.json`. Rapport `.md` au même basename.
Le premier intermédiaire attendu est `gold_intermediate_2026-09-29_01.json/.md`,
avec RUN_REPORT_INTERMEDIATE_2026-09-29_01.md et
VALIDATION_REPORT_INTERMEDIATE_2026-09-29_01.md. Respecter le handoff courant si
un checkpoint est décalé ; ne créer aucun fichier de marché futur pour tester.

Deux risques d’ingestion à traiter explicitement :

1. L’ancien backend peut déjà avoir mémorisé ce JSON sous REJECTED au même
   run_id/hash. processCandidate retourne actuellement immédiatement cette
   erreur mémorisée. Après mise à niveau du validateur, permettre une
   revalidation ciblée et traçable des anciens rejets liés au contrat, avec
   idempotence. Ne supprimer aucune archive PUBLISHED et ne changer les octets
   Drive simplement pour contourner ce cache.
2. Plusieurs états peuvent arriver avant un poll. Traiter les parents avant
   leurs enfants, avec stratégie déterministe/reprise, même si les noms trient
   le deuxième intermédiaire avant le premier. Ne pas rejeter définitivement
   un enfant simplement parce que son parent attend dans le même lot.

Normaliser les métadonnées de DB/API sans réinterpréter le récit : as_of depuis
le cutoff v6, type et lignée depuis meta, version éditoriale explicite. Garder
la sélection par lignée et cutoff ; une migration générée lundi reste datée du
cutoff dimanche. Ne pas réécrire les archives ni effacer l’historique.

Distinguer deux hashes : SHA-256 des octets exacts pour transport/trigger et
SHA-256 du JSON canonique trié pour scellement/consumed_handoff. Actuellement
goldNextRecap/service.ts calcule le SHA du raw et cherche les anciens champs
racine/procedural_audit.idempotence. Il doit aussi reconnaître v6
`consumed_handoff.{handoff_id,handoff_version,content_sha256}` avec la convention
canonique exacte ; garder la lecture legacy séparée. Tester espaces, ordre des
clés, Unicode et nombres avec l’implémentation canonique du dépôt.

## 5. API et handoff : aucun faux statut

v6 reader projection par whitelist, équivalente à readerSections et au renderer
Brain. Le terminal ne rend jamais récursivement JSON/audit. Le détail explicatif
reste complet ; conserver sources/URLs/IDs dans l’audit hors lecture. Maintenir
les enveloppes current/history/by-run et leurs métadonnées, avec une branche
typée v6. presentationCompleteness doit tester le contrat v6, pas déclarer
« complet » automatiquement parce que presentation.version n’existe pas.

La lecture publique du prochain récap doit comprendre ACTIVE et CLOSED avec
next_execution null. L’ancien validateur exige une date et renvoie INVALID pour
un CLOSED valide : corriger ce chemin et le frontend. Préserver distinctions
SCHEDULED, DUE, CONSUMED, EXPIRED, CANCELLED, INVALID et UNAVAILABLE, et représenter
CLOSED explicitement. Ne pas afficher une prochaine date pour un cycle fermé.
Valider également parent/origine/index et éviter d’afficher un plan rattaché à
un autre état courant. Afficher motif français et délai de confirmation.

Freshness du cache réseau et validité économique sont deux informations
différentes : FRESH/CACHED ne signifie pas biais encore valide. Afficher cutoff,
horizon et condition de réexamen. Au-delà de scheduled_expiry ou en présence
d’une invalidation connue, ne pas présenter le panneau historique comme une
permission actuelle. Conserver la conclusion d’archive telle quelle avec son
statut temporel ; ne déduire aucun nouveau biais du seul temps écoulé.

## 6. Frontend : même profondeur Sunday/intermédiaire

Suivre DESIGN.md et conserver l’identité du terminal. La première vue donne la
thèse future conditionnelle puis « Que puis-je envisager ? », par instrument.
Ensuite six jugements argumentés, surprises/chemins possibles, scénarios,
familles/questions, chronologie et explication des termes en détail progressif.
Le Markdown officiel sert de référence de contenu ; aucune réécriture/réduction
par modèle lors du rendu.

Les six IDs sont macro_direction, directional_asymmetry, positioning_asymmetry,
evidence_quality, analysis_scope, fundamental_conclusion. Ne pas recycler les
badges opportunity_quality/execution_readiness/edge sous de nouveaux titres.
Futures GC/MGC : macro clair, actuel, étayé dans le sens considéré seulement.
CFD : même filtre + positionnement actuel dans le même sens. L’asymétrie
directionnelle reste expliquée, sans devenir un troisième filtre. Pas de gate
technique, stop, taille, payoff, readiness ou absence d’options.

Arbre : afficher la topologie de scenario_tree ; parent_id/from_id/to_id servent
au graphe, pas au texte. Chaque nœud sélectionné donne title_fr, condition_fr,
causal_path_fr, observable_confirmation_fr, time_window_fr,
opposing_evidence_fr, invalidation_fr, practical_interpretation_fr. Chaque arête
explique sa condition observable et sa transmission. Garder les preuves dans
l’audit ; ne pas afficher current_evidence_refs comme des badges lecteur.
Ne pas inventer un statut CONFIRMED absent du contrat v6. Support clavier,
petit écran et textes longs ; aucune explication inaccessible ou coupée.

L’intermédiaire utilise **le même composant de lecture complet**. Ajouter
« Depuis le dernier récap » en vue initiale : toujours vrai, nouveau, renforcé,
affaibli, invalidé, facteurs exogènes, non résolu, prochains tests, jugements
avant/après et transitions de scénarios motivées. Le détail intégral demeure
accessible, avec 32 réponses, refresh_status/checked_at et arbre complet.
Hériter la chronologie hebdomadaire ; ne pas la présenter comme nouvellement
produite. « Pas de nouvelle publication » n’équivaut pas à « confirmé ».

Français complet ; anglais facultatif fidèle. Ne pas produire une traduction
automatique ni bloquer le rendu v6 en exigeant toute une branche presentation.en.
Gérer honnêtement une aide anglaise absente. Aucun lien de source ou identifiant
technique visible dans le récit ; sécuriser aussi le rendu Markdown.

## 7. Planning et automatisations Work

Les consignes ont déjà été mises à jour vers v6 et le nouveau Drive ID :
Sunday Read `6ab2ddfe1bf48191906cbf4b66dc7ce5` reste activé ; dispatcher
`6aab3e6089388191a39eee49ea959fc3` **reste en pause** tant que l’intégration n’est
pas vérifiée. Ne pas créer de doublon et ne pas prétendre que le fichier Control
réactive Work. Après déploiement vérifié, réactiver cet existant avec l’outil
Automations s’il est disponible ; sinon signaler exactement cette action à
effectuer dans Work. GitHub Actions ne remplace pas ce scheduler.

Prochain début de recherche : mardi 29 septembre 2026 11 h 30 New York, 90 minutes
après la publication effective JOLTS prévue à 10 h. BLS revérifié le 28.
Le handoff contient les questions/scénarios et les conditions de retard. Après
ce premier intermédiaire, le second est à choisir selon les preuves : candidat
mercredi 30 à 10 h 30 après PCE/GDP prévu 08 h 30, calendrier BEA revérifié le 28.
Ne pas transformer ce candidat en programmation automatique inconditionnelle.
Maximum deux intermédiaires avant vendredi 00 h NY ; fermeture après le deuxième
ou après un premier jeudi. Si la migration termine après l’heure prévue, relire
le handoff courant, le calendrier et sa pertinence ; ne pas antidater un run.

## 8. Vérifier avant activation, puis livrer

Tests ciblés : schema/REAL/FIXTURE/Control, parité Markdown et projection sans
fuite d’audit, filtres indépendants futures/CFD, UNKNOWN/PARTIAL et fraîcheur,
arbre complet et accessibilité, Sunday/intermédiaire détaillés, lignée et ordre
d’ingestion, hash canonique, une seule consommation, rejets anciens revalidés,
CLOSED/expiry/annulation/parent incohérent, et maintien des archives legacy.
Reprendre les suites tests/gold-market-state-*, gold-next-recap,
gold-read-client-lineage, gold-presentation-lineage, gold-intermediate-narrative,
gold-family-readout-contract et sunday-read-timeline-ui selon leur état courant.
Exécuter les vérifications pertinentes du monorepo (tests, typecheck, lint/build)
et une inspection navigateur du rendu Sunday + intermédiaire fixture en local.
Ne pas écrire la fixture dans la DB de production ni dans Output.

Ordre de livraison : code testé/documenté et commit/push ; backend/frontend v6
effectivement déployés ; nouvelle variable Control effective et accès lecteur
vérifié ; fichiers Drive + reçu relus ; ingestion/revalidation ; current/history
et rendu vérifiés ; activation du dispatcher existant. Si un accès de déploiement
manque, livrer le code et la commande/action exacte restante sans revendiquer le
succès live. Respecter les autorisations réelles de l’environnement.

Seulement quand le consommateur v6 est prêt, mettre à jour EN PLACE le trigger
de Trading Platform (pas Brain) avec schema_version 1, event
MARKET_STATE_PUBLISHED, document_type GOLD_MARKET_STATE, run_id attendu et nom
officiel. Le SHA-256 **octets** du JSON livré est
`b7275abffadd1e355770c06538e147fc40d60b655a96873e7f189ee9b23d621d` ; son SHA
canonique de reçu est
`0f725251843dc95085112763338adf4b90434f13026ce45b6c678842e451f82e`.
Recalculer depuis Drive avant le trigger. completed_at doit refléter la
vérification réellement effectuée. Si un descendant plus récent existe,
rafraîchir/vérifier ce dernier conformément à la lignée, sans forcer cet ancien
Sunday à redevenir current. Lire le SHA GitHub courant avant écriture, pas de
force push, et vérifier résultat Action + run_id backend.

Le trigger n’a pas été touché par la migration Drive. Son ancien contenu ne
prouve pas ce qui est actuellement sélectionné dans la DB. Ne pas lancer un
refresh prématuré simplement pour tester l’Action contre un backend incompatible.

Termine avec : commits poussés ; tests réellement passés/échoués ; fichiers et
variables modifiés ; IDs Output/Control utilisés ; run réellement sélectionné ;
statut de déploiement backend/frontend ; résultat de refresh ; prochaine date
et statut du dispatcher ; blocages restants. Mettre à jour la documentation
d’intégration et docs/AUTH_SUPABASE.md si le déploiement a été touché. Ne déclare
« tout relié et fonctionnel » qu’après vérification de bout en bout.
