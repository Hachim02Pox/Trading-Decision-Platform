# Exemple historique — Gold — semaine du 28 septembre au 2 octobre 2026

## Biais pour la semaine du 28 septembre au 2 octobre 2026

Le biais macro est baissier, sous condition que le régime de rendements réels élevés résiste aux prochaines publications. L’horizon principal est la semaine à venir, avec réexamen immédiat après toute nouvelle qui change ce régime. Le fait décisif est la hausse hebdomadaire du rendement réel américain à dix ans, de 2,68 % à 2,83 %, dans une économie dont les données de demande n’imposent pas encore un recul de la Fed. Pour un investisseur qui arbitre entre or et actifs rémunérés, un meilleur rendement réel augmente le coût de détention de l’or. Il peut réduire son allocation, différer un achat ou réclamer un prix plus bas. Ce comportement est une transmission économique plausible, pas une intention directement observée chez tous les porteurs.

## Pourquoi ce cas domine encore

Le meilleur cas opposé combine une surprise de ralentissement ou de désinflation avec le besoin de protection contre les tensions géopolitiques et la dette. Il est vivant: les taux réels ont baissé vendredi, l’or a rebondi, la confiance des ménages reste fragile et l’accumulation structurelle ne s’est pas évanouie. Il ne domine pas encore car la détente de vendredi n’efface pas le renchérissement réel de la semaine, tandis que les données productives vérifiées ne décrivent pas encore une contraction. La hausse du long terme oblige à garder une explication fiscale ouverte; pour qu’elle devienne franchement haussière pour l’or, il faut constater une préférence durable pour le métal face à la dette et à la monnaie, et pas seulement des obligations moins chères.

## Ce qui est déjà dans les prix

La hausse Fed du 16 septembre est connue. La probabilité d’un nouveau relèvement en octobre est déjà majoritaire dans le dernier instantané Reuters. Les taux et le dollar en ont absorbé une partie, et GC décembre a déjà baissé de 2,34 % entre les règlements retenus des 18 et 25 septembre. Cette baisse décrit le passé; elle n’est pas une cause de baisse future. Le prochain mouvement dépendra du décalage entre données et attentes, ainsi que de la réaction des investisseurs. Un PCE simplement élevé mais conforme peut ne pas ajouter de pression; une publication franchement faible peut faire davantage réviser la trajectoire. Il n’existe ici aucune estimation chiffrée de probabilités de scénarios ni de gain potentiel.

## Ce qui ferait renforcer, renverser ou suspendre le biais

Le cas baissier se renforce si le PCE et l’emploi résistent davantage qu’attendu et si le deux ans, les rendements réels et le dollar conservent leur réévaluation après la réaction initiale. Le cas haussier devient plausible si les surprises et révisions montrent un refroidissement, suivi d’une détente durable du réel et d’un dollar plus faible; une demande de protection autonome peut aussi le rendre plausible. Il faut rester sans direction claire si les canaux se contredisent durablement — par exemple rendements réels en hausse mais achats d’or persistants et dollar faible — jusqu’à identifier le moteur marginal. Ces conditions sont économiques; aucun niveau d’entrée, de sortie ou de prix technique n’est requis pour juger le biais.

## Le week-end n’a pas encore de verdict de marché

Les nouvelles diplomatiques des 26–27 septembre modifient le risque de réouverture. Un blocage persistant peut accroître simultanément le besoin de protection et les anticipations de coûts énergétiques. Ces effets vont en sens opposés pour l’or lorsque le second provoque un resserrement réel. Les cours de vendredi ne révèlent pas la réponse à une nouvelle du dimanche. Le biais conserve sa fondation macro au cutoff, mais son usage après réouverture exige une nouvelle lecture de la combinaison pétrole–taux–dollar–or.

## Ce que le positionnement ajoute réellement

Le COT montre une réduction des longs Managed Money jusqu’à mardi. L’historique émetteur GLD confirme ensuite un solde de rachats sur la semaine, interrompu par des créations mardi et mercredi puis une stabilité vendredi. Cela appuie une réduction d’exposition déjà réalisée. Cela ne démontre ni un excès statistique de longs encore à liquider, ni une contrainte de financement, ni une obligation de vendre la semaine prochaine. Une liquidation déjà avancée peut au contraire réduire le nombre de vendeurs restants. Le rebond de vendredi ne suffit pas davantage à prouver un achat structurel neuf: l’OI agrégé est presque stable et le contrat décembre absorbe un roulement d’échéance. La conclusion de positionnement est donc non établie, distincte du biais macro baissier.

## Que puis-je envisager ?

Lecture au 2026-09-27T14:57:35.740939-04:00. Horizon : 2026-09-28/2026-10-02.

Filtres fondamentaux uniquement

## GC/MGC futures

Short éligible au cutoff; long non éligible

Rendement réel et demande résistante maintiennent le coût d’opportunité de l’or.

Détente réelle de vendredi et potentiel de surprise faible; protection géopolitique.

Long si refroidissement/détente réelle persistante ou protection dominante établit un biais haussier; aucun sens si nouvelle contradiction matérielle laisse le moteur indéterminé.

## CFD

Aucun sens éligible au cutoff

Macro baissière, mais ventes futures contraintes et déséquilibre résiduel non établis.

Sorties GLD mixtes et stabilisées vendredi; COT retardé, roll GC.

Short seulement si la macro reste baissière et de nouvelles preuves établissent une asymétrie baissière: exposition résiduelle vulnérable, catalyseur et participation concordante; long seulement si les deux deviennent haussiers.

## Quand réexaminer cette lecture ?

À réexaminer dès la réouverture si pétrole, dollar, taux ou flux changent matériellement après les nouvelles du week-end; au plus tard avant JOLTS mardi 29 septembre à 10 h New York, puis après PCE mercredi et emploi vendredi. Ce n’est pas une autorisation persistante pour un autre jour.

À réexaminer au plus tard le 2026-09-29T10:00:00-04:00.

Toute nouvelle matérielle ou réponse de marché contradictoire à la réouverture

Le trader choisit séparément sa configuration technique, ses niveaux et son risque. Ce document ne les évalue ni ne les demande.

## 1. Direction macro

Baissière conditionnelle

Le rendement réel plus élevé et la demande productive résistante favorisent le coût d’opportunité de l’or sur la prochaine semaine. Le mécanisme demeure tant que les données et la réaction de marché ne le défont pas. La meilleure contradiction est une détente durable après PCE/emploi ou une demande de protection devenue dominante. Cette direction ne dépend pas d’une validation du positionnement.

## 2. Asymétrie directionnelle

Avantage relatif des surprises non démontré

Le scénario baissier de base n’établit pas qu’une surprise positive d’inflation fasse davantage baisser l’or qu’une surprise faible ne le ferait monter. Une hausse Fed est déjà largement attendue, et vendredi montre une sensibilité à la détente. Sans distribution fiable des attentes ni réactions intraday comparables, on ne chiffre pas ce déséquilibre. Une nouvelle surprise forte avec réévaluation persistante pourrait l’établir; des données faibles et un abandon des hausses attendues favoriseraient l’asymétrie inverse.

## 3. Asymétrie de positionnement

Non établie

Le COT et les rachats nets GLD décrivent des sorties passées. Le stock long résiduel est connu, son caractère extrême et ses contraintes ne le sont pas. Le roll empêche d’interpréter décembre seul comme capital neuf. Une réduction passée peut retirer du combustible à une liquidation future. Il faudrait des flux contemporains persistants et une exposition résiduelle vulnérable à un catalyseur observable pour confirmer le sens baissier; des créations ETF durables avec reprise des engagements après détente favoriseraient le sens haussier.

## 4. Solidité de la lecture fondamentale

Fondation macro étayée; lecture des positions partielle

La décision Fed, les courbes du Trésor, les publications de demande et l’archive GLD sont vérifiables. Les lacunes sont précises: grille FedWatch, statistique de corrélation, historique COT pour percentiles, série OI définitive, IAU et prime physique comparable. Elles ne rendent pas tous les faits incertains. Elles réduisent surtout la capacité à mesurer une surprise relative et à attribuer les flux. Cette solidité décrit la recherche fondamentale; ce n’est pas une note de rendement-risque technique.

## 5. Portée du jugement

Filtres fondamentaux uniquement

L’expérience s’arrête à la direction macro et à sa confirmation éventuelle par le positionnement. Aucune aptitude à exécuter un ordre n’est évaluée. Les données d’options par échéance appartiennent au contrôle manuel distinct. L’absence de ces éléments ne diminue pas le biais macro et ne crée pas de condition supplémentaire pour les futures ou les CFD. La seule fraîcheur exigée ici est celle des preuves économiques et des positions utilisées.

## 6. Conclusion fondamentale par instrument

GC/MGC: short éligible; CFD: aucun sens éligible

La direction baissière étayée suffit au filtre futures GC/MGC, même si les deux asymétries ne sont pas démontrées. Pour le CFD, la confirmation du même sens par une asymétrie de positionnement manque: aucun sens ne reçoit l’éligibilité fondamentale. Un biais macro devenu haussier ouvrirait le filtre long des futures; il faudrait en plus une asymétrie haussière de positionnement pour le CFD. Une nouvelle information matérielle impose une mise à jour plutôt que la réutilisation de cette photographie.

## Les horizons

2026-09-28/2026-10-02

Jusqu’au FOMC 27–28 octobre, réévaluation continue

Mois/années; demande de diversification retardée, distincte du biais tactique

## JOLTS août

2026-09-29T10:00:00-04:00

Consensus non capturé

Offres, embauches et démissions ensemble: modifier la lecture du travail avant PCE.

## PCE/revenus/dépenses août et mises à jour annuelles BEA

2026-09-30T08:30:00-04:00

Consensus PCE non vérifié; à fixer avant publication

Inflation core et headline, consommation réelle, revenus et révisions; le mois seul peut tromper.

## Employment Situation septembre

2026-10-02T08:30:00-04:00

Reuters au 25: +100 000 emplois, chômage 4,2 %; à actualiser

Emplois, révisions, salaires, chômage et participation; puis réel/dollar après réaction initiale.

## Commandes manufacturières et révisions Census août

2026-10-02T10:00:00-04:00

Consensus non capturé

Vérifier si la vigueur des biens d’équipement est maintenue dans les données détaillées.

## Un coût d’opportunité accru, face à un besoin de protection

État observé au cutoff: biais macro baissier, confirmation de positionnement non établie.

Des rendements réels plus rémunérateurs peuvent détourner l’investisseur marginal de l’or; la protection géopolitique et monétaire peut agir en sens inverse.

Actualiser les canaux économiques et les flux après réouverture, sans traiter vendredi comme réponse aux nouvelles du dimanche.

Du 28 septembre au 2 octobre; première vérification à la réouverture.

Détente vendredi, demande structurelle et fragilité des ménages.

Une nouvelle information qui rend la fondation des taux ou de la demande obsolète exige une nouvelle racine.

Partir des deux filtres actuels, puis suivre les changements observables ci-dessous.

## La demande résiste et le coût réel reste élevé

PCE/emploi surprennent du côté de la résistance ou ne provoquent aucun abandon durable du resserrement.

Les investisseurs maintiennent un rendement réel exigé élevé et certains réduisent leur exposition non rémunérée. Une nouvelle réévaluation peut ajouter une pression à celle déjà incorporée.

Rendements réels et deux ans qui conservent leur réaction, dollar confirmé par plusieurs devises, or qui répond au même canal; ne pas compter ces trois prix comme trois chocs.

PCE le 30 septembre, emploi le 2 octobre; examiner persistance après réaction initiale et clôture suivante.

Hausse Fed déjà largement anticipée; ménages fragiles; couverture géopolitique.

Surprise faible suivie d’une détente durable des taux réels ou demande de protection qui domine malgré eux.

Biais baissier renforcé: filtre short futures maintenu. Le CFD exige encore la confirmation de positionnement du nœud suivant.

## La vulnérabilité restante devient observable

Le régime macro baissier persiste et des preuves fraîches identifient une exposition vulnérable au même catalyseur.

Des porteurs encore exposés et soumis à une contrainte documentée réduisent l’or; les nouveaux flux confirment l’incitation, au lieu de répéter seulement le passé.

Créations/rachats émetteurs sur plusieurs dates et OI final hors effet de roll, confrontés au prochain COT et à une contrainte éventuelle. Un acteur forcé est un exemple de preuve forte, pas une obligation ajoutée si une autre asymétrie démontrable existe.

Après publications du 30 septembre–2 octobre; prochain COT pour positions du 29 septembre, avec son retard explicite.

GLD vendredi stable; longs déjà allégés; financement benchmark sans dislocation au 24.

Flux qui se stabilisent ou deviennent acheteurs, disparition de la vulnérabilité ou macro devenue mixte.

Short CFD devient éligible uniquement lorsque l’asymétrie baissière est réellement établie avec la macro. Tant que ce test manque, la branche reste conditionnelle.

## Le refroidissement déclenche une détente durable

PCE/emploi et révisions sont plus faibles qu’attendu, et la réponse des taux confirme un changement de régime.

Les investisseurs réduisent leurs anticipations de resserrement; le coût d’opportunité de l’or baisse et certains réallouent vers le métal.

Détente persistante du réel et du deux ans, dollar plus faible au-delà d’une intervention isolée, demande d’or qui tient après la première réaction; consensus actualisé avant publication.

30 septembre–2 octobre et séances suivantes pour confirmer.

PMI, commandes et claims récents ne signalent pas encore ce refroidissement; révisions peuvent compenser la surprise.

Rebond bref sans détente réelle, données/révisions redevenues fortes ou dollar qui conserve son régime.

Un biais macro haussier clair ouvrirait le long futures. Le CFD long demande en plus des flux et positions favorisant réellement ce même sens.

## La protection domine le rendement

Escalade ou défiance envers dette/monnaie engendre des achats d’or persistants même sans baisse initiale des taux réels.

Des investisseurs recherchent un actif sans risque de crédit souverain; leurs achats peuvent dépasser la pression du rendement. Une simple hausse du pétrole ne suffit pas à prouver ce comportement.

Flux d’or nouveaux et persistants, détérioration de la confiance obligataire/monétaire cohérente, ou demande de protection clairement observable; vérifier dollar, crédit et financement pour distinguer refuge et cash.

Réouverture puis semaine entière; horizon structurel si le régime persiste.

Le dollar a progressé sur la semaine et le réel domine encore; aucune fuite systémique dette/dollar vérifiée.

L’escalade renforce surtout le dollar et les taux réels, ou l’or est vendu pour fournir du cash; retour crédible de la diplomatie.

Passer au biais haussier seulement si ce canal devient dominant et étayé. Évaluer ensuite séparément le filtre de positionnement du CFD.

## Les canaux se contredisent

PCE, emploi, taux, dollar et demande de métal envoient des messages incompatibles ou les données de base deviennent périmées.

Plusieurs clientèles peuvent agir dans des sens opposés; une variation de prix agrégée ne permet pas d’identifier le moteur marginal.

Contradiction persistante après les premières réactions, plutôt qu’un mouvement de quelques minutes; vérifier d’abord dates, unités et contrats.

À tout moment de la semaine, particulièrement autour des publications.

Une détente ou un durcissement cohérent peut rapidement restaurer une direction.

Un moteur économique clair et des observations concordantes remplacent le conflit.

Aucun sens futures ni CFD éligible sous les filtres tant que le biais macro n’est plus clair. Ce constat concerne les filtres, pas une interdiction générale de négocier.

## Le besoin de cash prend le dessus

Stress de financement ou contraintes vérifiées provoquent des réductions de levier, malgré un récit de protection.

Des détenteurs vendent les actifs liquides disponibles, y compris l’or, pour répondre aux besoins de collatéral. Le récit de refuge peut alors échouer temporairement.

Écart de financement réellement tendu, marges/rachats documentés, crédit qui se dégrade et ventes cohérentes; ne pas substituer un faible RRP à ces preuves.

Fin de trimestre le 30 septembre et épisodes de stress éventuels.

SOFR proche d’IORB au 24; aucun acteur Gold contraint établi; stress de crédit observé encore limité.

Liquidité normalisée et achats de protection persistants sans ventes contraintes.

Réévaluer le biais baissier sur des preuves nouvelles; le CFD ne devient short éligible que si la même direction est confirmée par le positionnement.

## Comment le scénario se transmet

PCE/emploi surprennent du côté de la résistance ou ne provoquent aucun abandon durable du resserrement.

Les investisseurs maintiennent un rendement réel exigé élevé et certains réduisent leur exposition non rémunérée. Une nouvelle réévaluation peut ajouter une pression à celle déjà incorporée.

## Comment le scénario se transmet

Le régime macro baissier persiste et des preuves fraîches identifient une exposition vulnérable au même catalyseur.

Des porteurs encore exposés et soumis à une contrainte documentée réduisent l’or; les nouveaux flux confirment l’incitation, au lieu de répéter seulement le passé.

## Comment le scénario se transmet

PCE/emploi et révisions sont plus faibles qu’attendu, et la réponse des taux confirme un changement de régime.

Les investisseurs réduisent leurs anticipations de resserrement; le coût d’opportunité de l’or baisse et certains réallouent vers le métal.

## Comment le scénario se transmet

Escalade ou défiance envers dette/monnaie engendre des achats d’or persistants même sans baisse initiale des taux réels.

Des investisseurs recherchent un actif sans risque de crédit souverain; leurs achats peuvent dépasser la pression du rendement. Une simple hausse du pétrole ne suffit pas à prouver ce comportement.

## Comment le scénario se transmet

PCE, emploi, taux, dollar et demande de métal envoient des messages incompatibles ou les données de base deviennent périmées.

Plusieurs clientèles peuvent agir dans des sens opposés; une variation de prix agrégée ne permet pas d’identifier le moteur marginal.

## Comment le scénario se transmet

Stress de financement ou contraintes vérifiées provoquent des réductions de levier, malgré un récit de protection.

Des détenteurs vendent les actifs liquides disponibles, y compris l’or, pour répondre aux besoins de collatéral. Le récit de refuge peut alors échouer temporairement.

## Fed et anticipations

Le régime restrictif est une fondation vérifiée, mais déjà partiellement anticipée. Des investisseurs sensibles au rendement peuvent préférer un placement rémunéré à l’or si les prochaines données prolongent ce régime. Le recul des anticipations en fin de vendredi rappelle qu’une surprise faible pourrait rapidement inverser ce comportement. Le test est la révision persistante de la trajectoire après PCE/emploi, pas le seul ton d’un discours.

## Que price le prochain FOMC et comment cela a-t-il changé ?

La dernière édition Reuters FX consultée donne environ 66 % de probabilité de hausse en octobre, contre environ 58 % une semaine avant. Le reportage or du matin indiquait 71 % : ce sont des observations successives, pas deux probabilités à moyenner. La Fed a déjà relevé sa fourchette de 25 points de base le 16 septembre. Une grande partie du risque de resserrement est donc connue. La grille CME directe, les cinq clôtures consécutives et le niveau exact juste avant/après chaque publication n’ont pas été extraits. Le biais ne dépend pas d’une probabilité précise au point près.

Observation : 2026-09-25.

Grille dynamique sans cellules numériques; relais Reuters horodatés mais non clôtures synchronisées

Limite la mesure du potentiel de surprise; ne supprime pas le signal direct des taux réels.

Exporter la grille CME et ses historiques datés; conserver instrument, heure et distribution complète.

## Que dit le taux américain à deux ans ?

Le deux ans finit à 4,81 %, soit +5 pb depuis le 18, après 4,71 % mardi et 4,87 % jeudi. Le mouvement mercredi–jeudi confirme une réévaluation restrictive; le recul de 6 pb vendredi montre qu’elle n’est pas linéaire. Le deux ans n’est pas une probabilité Fed pure: il comprend une moyenne anticipée de taux et des primes. Les cotations quotidiennes ne permettent pas d’attribuer chaque point de base à une annonce isolée.

Observation : 2026-09-25.

## Les annonces de la Fed sont-elles nouvelles et confirmées par le marché ?

Le communiqué du 16 septembre établit la hausse à 3,75–4,00 % et décrit une économie résistante avec une inflation élevée. Reuters rapporte vendredi les préoccupations inflationnistes de Beth Hammack. La hausse hebdomadaire des taux réels et la probabilité de hausse d’octobre vont dans le même sens; ils ne constituent pas trois moteurs indépendants. Les propos seuls ne suffisent pas à annoncer une autre baisse de l’or: il faut que les investisseurs maintiennent ou augmentent le rendement exigé face aux prochaines données.

Observation : 2026-09-16/2026-09-25.

## Quel est le prochain FOMC et quels événements peuvent changer son prix ?

Le prochain FOMC se tient les 27–28 octobre. Avant lui, JOLTS le 29 septembre à 10 h, PCE le 30 à 8 h 30 et l’emploi le 2 octobre à 8 h 30, heures de New York, peuvent modifier la trajectoire attendue. Une hausse en octobre est favorisée, non certaine. Une surprise doit être mesurée contre le consensus actualisé, avec les révisions, puis contre la réaction persistante du deux ans et du taux réel.

Observation : Calendrier consulté au cutoff.

## Taux et rendements réels

La composante réelle domine la hausse du dix ans: c’est le support le plus direct au coût d’opportunité de l’or. La courbe longue mène, donc une prime de terme/fiscale coexiste possiblement avec la Fed. Cette alternative deviendrait favorable à l’or si elle s’accompagnait de fuite du dollar et d’achats de métal. Sans cette combinaison, elle ne suffit pas à renverser le biais. La détente vendredi empêche d’extrapoler mécaniquement la vitesse de mercredi.

## Le rendement réel dix ans monte-t-il réellement ?

Oui sur la semaine: 2,68 % le 18, 2,62 % lundi, 2,63 % mardi, 2,76 % mercredi, 2,85 % jeudi, 2,83 % vendredi. Le gain vendredi-sur-vendredi est 15 pb, et non 21: 21 pb décrit lundi–vendredi. Le recul final de 2 pb est une contre-observation réelle mais n’annule pas la hausse de la semaine. Le rendement réel est le rendement de marché d’une obligation indexée; il augmente l’alternative rémunérée à l’or, sans établir à lui seul un flux de vente.

Observation : 2026-09-25.

## La hausse du dix ans vient-elle du réel ou de l’inflation anticipée ?

Le nominal dix ans passe de 5,01 à 5,17 % (+16 pb), le réel de 2,68 à 2,83 % (+15 pb), et l’écart nominal–réel de 2,33 à 2,34 % (+1 pb). La hausse est essentiellement réelle sur cette fenêtre. Cela contredit une explication exclusivement inflationniste favorable à l’or. Le breakeven inclut des primes de risque et de liquidité; la décomposition ne mesure pas séparément la politique anticipée et la prime de terme.

Observation : 2026-09-18/2026-09-25.

## Quelle partie de la courbe mène le mouvement ?

Le long terme mène: deux ans +5 pb, dix ans +16 pb, trente ans +15 pb. Qualifier tout le mouvement de simple anticipation Fed serait excessif. L’offre de dette et le rendement exigé pour immobiliser du capital longtemps sont des explications concurrentes. Elles peuvent pénaliser l’or par le coût d’opportunité ou lui profiter si la confiance dans la dette et le dollar se dégrade ensemble. La hausse longue seule ne tranche pas entre ces deux transmissions.

Observation : 2026-09-18/2026-09-25.

## Comment évolue la pente deux–dix ans ?

L’écart dix ans moins deux ans passe de +25 à +36 pb, soit une pentification de 11 pb. Il est de +20 lundi, +25 mardi, +26 mercredi, +31 jeudi et +36 vendredi. Vendredi, la pentification provient surtout de la baisse du deux ans, pas d’une nouvelle flambée du dix ans. La direction de la pente et celle du niveau des taux sont deux informations différentes.

Observation : 2026-09-25.

## La réaction aux publications a-t-elle persisté ?

Mercredi, après le flash PMI, le réel dix ans progresse de 13 pb sur la journée; jeudi il ajoute 9 pb, puis rend 2 pb vendredi. L’adjudication et le pétrole ont également pu contribuer: cette concordance journalière n’est pas une identification causale minute par minute. La persistance partielle rend le mécanisme restrictif crédible, tout en laissant une réévaluation après PCE. L’affirmation « le PMI a causé toute la hausse » n’est pas retenue.

Observation : 2026-09-23/25.

Seules observations quotidiennes et reportages intraday non synchronisés obtenus

Confiance moindre dans l’attribution de la variation à chaque événement, pas dans la variation elle-même.

Récupérer séries intraday datées, fenêtres pré/post et contrôle des annonces simultanées.

## La volatilité obligataire change-t-elle le risque de transmission ?

La recherche secondaire signale une forte hausse de la volatilité obligataire, mais le niveau et la série comparables du MOVE, l’indice de volatilité implicite des taux, ne sont pas établis. Les variations publiées utilisent des fenêtres différentes et ne sont pas combinées. La question est matérielle: des contraintes de risque peuvent entraîner des ventes d’actifs liquides. Ce mécanisme reste un scénario, sans vendeur d’or forcé identifié.

Observation : 2026-09-25.

Yahoo historique en erreur; recherches donnent pourcentages de fenêtres différentes et aucune série primaire exploitable

Impossible de quantifier le choc de volatilité ou de confirmer un désendettement mécanique.

Obtenir série ICE/licenciée datée; confronter à financement, marges et positions.

## Dollar et financement

Le dollar accompagne le régime de rendement, avec des exceptions liées aux interventions et aux politiques locales. Il ne compte pas comme un second choc indépendant. Le financement public observé n’établit pas une pénurie de dollars. Une baisse large et persistante du dollar avec détente réelle constituerait une vraie contradiction, tandis qu’une seule hausse du yen reste insuffisante.

## Le dollar est-il fort et ce mouvement est-il large ?

Reuters situe le DXY à 100,95, −0,3 % sur son instantané du vendredi, mais en hausse sur la semaine. L’euro et la livre remontent sur la séance; le yuan offshore recule face au dollar et le yen bénéficie d’avertissements d’intervention. Le mouvement n’est donc pas uniforme. DXY représente un panier concentré, particulièrement sensible à l’euro; ce n’est pas la liquidité mondiale en dollars. La série de cinq clôtures et un indice large concordant restent manquants.

Observation : 2026-09-25.

Historique Yahoo DX-Y.NYB non récupéré; instantanés Reuters et devises disponibles, pas série close-to-close

Ne permet pas un rendement hebdomadaire DXY précis ni une confirmation de force universelle.

Récupérer clôtures ICE et indice broad dollar de même fenêtre.

## Quelle est la relation or–dollar mesurée sur trente séances ?

Aucun coefficient n’est publié dans cet exemple historique. Les deux séries homogènes, même fixing et même nombre de séances, n’ont pas été récupérées. Les coïncidences vendredi et le mouvement hebdomadaire permettent seulement une lecture qualitative compatible avec le canal dollar. Elles ne prouvent ni une corrélation de trente jours ni une causalité stable. Le futur terminal doit afficher cette absence, sans transformer quelques observations en statistique.

Observation : 30 séances jusqu’au 2026-09-25.

Historique Gold partiellement indexé; DXY non extrait; API Yahoo HTTP429; changements de contrat et fixings à contrôler

La relation USD n’est pas une confirmation statistique autonome.

Obtenir 31 niveaux alignés; calculer 30 rendements, contrôler calendrier et contrat, publier méthode et dates.

## Le yen signale-t-il une exception au dollar fort ?

Le yen se renforce de 1,06 % dans le reportage Reuters, USD/JPY à 157,13, après des déclarations de coordination japonaise et américaine. Un rebond du yen peut donc refléter le risque d’intervention, sans annoncer un assouplissement de la Fed. FRED ne va que jusqu’au 18: son 156,87 est une observation de midi antérieure et n’est pas utilisé comme clôture comparable du 25. Une poursuite du mouvement avec dollar large et taux réels en baisse renforcerait le cas haussier de l’or.

Observation : 2026-09-25 intraday.

## Que montre le yuan offshore ?

Le yuan offshore vaut 6,6946 par dollar lundi en Asie et 6,723 dans le reportage du vendredi. Ces instantanés suggèrent un yuan moins fort en fin de semaine, mais ne constituent pas un rendement clôture-à-clôture. La politique de change et le sommet commercial peuvent dominer cette paire. Le mouvement ne démontre ni fuite mondiale vers le dollar ni ralentissement chinois nouveau; il empêche surtout de présenter la baisse du dollar vendredi comme totalement générale.

Observation : 2026-09-21/25 intraday.

## Le financement en dollars confirme-t-il un stress ?

SOFR vaut 3,88 % le 24 contre IORB 3,90 %, écart −2 pb: ce benchmark ne montre pas de dislocation ce jour-là. Le reverse repo est 0,576 Md USD le 25. Le TGA moyen hebdomadaire passe de 877,028 à 977,084 Md USD, ce qui peut absorber des réserves toutes choses égales. Ni ce mouvement ni un faible RRP ne prouvent une pénurie systémique: les autres facteurs du bilan et les financements transfrontières manquent. La fin de trimestre justifie une surveillance distincte.

Observation : 2026-09-23/25.

SOFR publié seulement jusqu’au 24; TGA moyenne hebdomadaire, aucune série basis actuelle capturée

Limite un diagnostic de liquidation systémique; ne constitue pas un veto au biais macro.

Actualiser NY Fed après publication du 28, ajouter réserves et basis, comparer mêmes dates.

## Demande, inflation, énergie et crédit

L’activité productive et les commandes rendent crédible la capacité de la Fed à maintenir des taux restrictifs, tandis que les ménages expriment de la fragilité. Les prix énergétiques peuvent augmenter les coûts sans soutenir durablement la demande. La prochaine lecture doit donc distinguer croissance forte, stagflation et ralentissement. Une crise de crédit ou une rupture diplomatique peut changer les besoins de liquidité et de protection: leur effet sur l’or n’est pas univoque.

## Les publications surprennent-elles et dans quel sens ?

Le composite PMI passe à 58,4 contre 56,0 en août; son consensus n’est pas établi. Les claims sont 197 000 contre 201 000 attendus, précédent révisé 198 000 depuis 196 000. Les commandes de biens d’équipement hors défense/aviation font +1,6 % contre +0,5 % attendu; juillet est révisé de 0 à +0,6 %. Le total des biens durables est quasi inchangé: ce n’est pas la même mesure. Michigan final 48,1 reste inférieur à août 51,7, avec anticipations d’inflation un an 4,6 %. Demande productive résistante et ménages fragiles coexistent.

Observation : 2026-09-23/25.

Publication primaire fournit le réalisé mais pas le consensus; calendriers secondaires retournent séries incohérentes

Impossible de chiffrer la surprise composite; la hausse observée reste vérifiée.

Récupérer sondage daté antérieur au 23 septembre; ne pas reconstruire le consensus après coup.

## Le pétrole crée-t-il une impulsion durable pour l’or ?

Le Brent recule vendredi dans le reportage intraday à 103,64 USD/b; ce prix n’est pas présenté comme un règlement. Le week-end, Reuters rapporte un rejet public du plan iranien et la poursuite des efforts diplomatiques. Le canal vers l’or est double: prime de protection favorable, mais inflation importée et taux réels possiblement défavorables. Il faut observer lequel domine à la réouverture. La baisse du pétrole vendredi ne prouve pas que le risque de rupture d’approvisionnement a disparu.

Observation : 2026-09-25 et nouvelles 26–27.

Article récupéré intraday sans série homogène; aucune séance post-week-end avant cutoff

Pas de rendement hebdomadaire pétrole exact ni de confirmation du canal dominant du week-end.

Récupérer règlements ICE/CME identifiés et comparer après réouverture pétrole, réel, dollar et or.

## Les adjudications appuient-elles le récit fiscal ?

Le PDF officiel du sept ans confirme un rendement de 5,085 % et une couverture de 2,42, sur 44,0000551 Md USD hors SOMA. La part indirecte calculée sur les offres compétitives acceptées est 57,197 %. La hausse longue rend ce canal pertinent. En revanche, le when-issued juste avant l’enchère et la comparaison homogène au mois précédent ne sont pas vérifiés: aucun tail ni « échec d’adjudication » n’est affirmé. Le rachat SOMA n’est pas, en soi, un nouveau programme de monétisation.

Observation : 2026-09-24.

Page générale Treasury sans tableau; PDF sept ans récupéré via lien secondaire; pas de when-issued dans le PDF; chiffres secondaires non admis comme preuve primaire de tail

La prime de terme/fiscal reste une explication concurrente non quantifiée.

Obtenir résultats cinq ans et cotations when-issued de même instant; analyser allocations et réaction sans extrapoler à une crise.

## Le crédit montre-t-il déjà une crise ?

Les spreads corrigés des options, ou OAS, montent de 2,68 à 2,80 % pour le haut rendement et de 0,77 à 0,79 % pour l’investment grade entre le 18 et le 24. C’est un élargissement de 12 et 2 pb, pas une preuve suffisante de crise systémique. La date est jeudi, pas vendredi. Une accélération persistante pourrait déplacer le débat du coût d’opportunité vers la protection ou la vente d’actifs pour obtenir du cash; ces deux réactions ne doivent pas être confondues.

Observation : 2026-09-24.

## Positions et flux

Les rachats nets GLD sont désormais établis, mais alternent avec deux journées de créations et s’arrêtent vendredi. Les positions longues résiduelles constituent une exposition, pas une obligation de vendre. La réduction déjà accomplie peut diminuer le combustible d’un futur débouclage. Les shorts réduits laissent aussi moins de positions à racheter en urgence. L’historique IAU incomplet et le roll GC empêchent de départager les effets globaux. Il faut une réaction nouvelle aux catalyseurs et une participation cohérente; reconduire les rachats passés ne suffit pas.

## Qui reste positionné et le niveau est-il extrême ?

Managed Money détient 135 699 longs et 8 310 shorts, soit 127 389 nets longs; variation nette −5 727 depuis le 15. Les longs baissent de 6 695 et les shorts de 968: réduction du risque des deux côtés, principalement des longs, plutôt qu’ouverture agressive de shorts. Des investisseurs restent exposés à une nouvelle hausse des rendements, mais leurs coûts, marges et contraintes ne sont pas connus. Les percentiles 156 semaines manquent. Le relevé de mardi ne voit pas les décisions prises après les publications de mercredi à vendredi.

Observation : Positions 2026-09-22; publication 2026-09-25.

ZIP 2026 indisponible via web et HTTP403; environnement PRE vide dans extraction; historique complet non téléchargé

Interdit de qualifier le positionnement d’extrême; baisse passée insuffisante pour asymétrie baissière future.

Télécharger 2023–2026 CFTC, conserver 156 rapports comparables, contrôler doublons et calculer rangs empiriques.

## Le prix et l’intérêt ouvert décrivent-ils de nouveaux engagements ?

GC décembre règle à 4 321,20 USD/oz, +23,20 vendredi. Le bulletin indique OI décembre 323 251, variation +5 799, mais octobre −6 669 et total GC 408 109, variation −236. Le déplacement vers décembre est compatible avec un roulement d’échéances, pas une preuve autonome d’argent haussier neuf. Le volume décembre est 138 694 Globex et 1 398 PNT. La série quotidienne définitive d’OI du même contrat et la date de référence clearing complète ne sont pas réconciliées; aucune attribution directionnelle aux acteurs n’en est tirée.

Observation : Bulletin préliminaire 2026-09-25.

Page volume dynamique; bulletin courant préliminaire seulement, série réconciliée multi-séances absente; volume Yahoo différent du périmètre CME

Ne permet pas de conclure à achats nouveaux ou liquidation persistante à partir du seul décembre.

Obtenir bulletins finaux datés, aligner prix/OI et isoler rolls, spreads, livraisons et ajustements.

## Les ETF confirment-ils des créations ou des rachats persistants ?

L’archive officielle GLD est finalement récupérée et ses colonnes vérifiées: 370,60 millions de parts le 18, 370,00 lundi, 370,20 mardi, 370,50 mercredi, 369,70 jeudi et vendredi. Le net est −0,90 million (−0,243 %). Deux jours de rachats, deux de créations et un stable: la sortie n’est pas persistante chaque jour. IAU fournit seulement le stock vendredi (792,15 millions de parts; 463,20 t). GLD confirme une réduction d’exposition sur la semaine, mais ne prouve pas que les porteurs restants soient contraints de vendre après PCE.

Observation : 2026-09-25.

GLD résolu par téléchargement direct XLSX; IAU historique toujours non récupéré, page fournit un stock unique; WGC août ne remplace pas septembre

GLD réduit l’incertitude et confirme des rachats nets modestes; persistance globale et fragilité future non établies.

Récupérer historique IAU/émetteur et données hebdomadaires WGC, sans substituer performance/AUM aux flux.

## Les options sont-elles nécessaires à cette lecture hebdomadaire ?

Le diagnostic IV, skew et gamma/GEX propre à une échéance appartient au contrôle manuel distinct prévu par le README. Aucun signal option fiable et matériel n’a été capturé ici. Il ne devient pas un veto hebdomadaire. Le gamma des teneurs de marché n’est pas observable par le seul intérêt ouvert: toute estimation exigerait des hypothèses d’inventaire, un sous-jacent, une échéance et un modèle explicites.

Observation : Au cutoff.

Hors périmètre explicite de la lecture fondamentale, non une défaillance de collecte obligatoire

Aucune conséquence sur les deux filtres fondamentaux.

Seulement à la demande distincte de l’utilisateur avec données, échéance et méthode.

## Quel acteur marginal entre ou sort, et pourquoi maintenant ?

Le seul acteur spéculatif catégorisé directement est Managed Money, qui réduit ses positions nettes jusqu’à mardi. Un investisseur sensible au rendement réel pourrait continuer à diminuer l’or si le PCE et l’emploi prolongent le resserrement; c’est une inférence conditionnelle, pas une intention observée. L’alternative est qu’une partie des vendeurs ait déjà terminé et revienne sur surprise faible. Les ETF ne donnent pas les motivations de chaque porteur et le roulement GC ne révèle pas un nouveau pari directionnel.

Observation : 2026-09-22/25.

COT antérieur aux principales publications; données agrégées ne révèlent ni identité complète ni motivation

Empêche de présenter la transmission théorique comme flux effectif confirmé.

Confronter prochain COT, créations/rachats ETF et OI réconcilié, sans attribuer des intentions non observées.

## Un acheteur ou vendeur forcé est-il identifié ?

Aucun acteur forcé de l’or n’est identifié dans les sources capturées. Détenir encore des longs ne prouve pas devoir les vendre; fermer des shorts ne prouve pas une compression imminente. Les contraintes individuelles de collatéral, limites de risque et demandes de rachats ne sont pas publiques dans les relevés utilisés. La possibilité de désendettement existe, notamment autour de la fin de trimestre, mais ne soutient pas un verdict d’asymétrie confirmé.

Observation : 2026-09-25.

Données CFTC agrégées; aucune déclaration vérifiée de contrainte individuelle; table de marges non extraite

L’asymétrie de positionnement demeure non établie.

Chercher annonce de marge/rachat/liquidation datée et participation concordante; ne pas exiger un inventaire dealer non observable.

## Le coût de financement force-t-il déjà le levier à se réduire ?

Le benchmark SOFR proche d’IORB ne confirme pas de tension exceptionnelle au 24. Il ne couvre toutefois pas le financement propre d’un fonds, les haircuts ni ses pertes. La hausse des taux longs peut créer des pertes obligataires et des réductions de risque transversales; l’élargissement modeste du crédit ne suffit pas à établir leur urgence. La fin de trimestre est un rendez-vous de surveillance, pas une preuve de liquidation automatique de l’or.

Observation : 2026-09-24/25.

Benchmarks publics disponibles mais contraintes bilatérales non révélées; table CME non extraite

Ne permet pas de convertir vulnérabilité théorique en flux contraint.

Actualiser benchmarks et avis clearing; rechercher un événement contraignant documenté.

## Quel événement observable déclencherait un débouclage mécanique ?

Le PCE et l’emploi sont des catalyseurs économiques, pas des déclencheurs mécaniques prouvés. Un relèvement de marge applicable à des porteurs fragiles, des rachats imposant une vente ou une contrainte de financement documentée pourrait constituer un véritable déclencheur. Aucun n’est établi. Une hausse des taux suivie de ventes persistantes renforcerait le scénario baissier, mais le lien obligé entre événement et acteur doit encore être démontré.

Observation : Semaine du 28 septembre au 2 octobre.

Événements macro datés connus; aucune contrainte exécutoire observable reliée aux porteurs Gold

Pas de vente forcée présentée comme inévitable.

Identifier contrainte, échéance et exposition résiduelle, puis vérifier sa transmission effective.

## Le rebond de vendredi révèle-t-il un capital neuf ?

Le règlement GC décembre remonte de 0,54 % vendredi après −2,34 % sur la semaine. GLD reste à 369,70 millions de parts jeudi et vendredi: aucune création nette concomitante au rebond n’est observée dans ce véhicule. Le total OI presque stable et le roulement vers décembre laissent ouvertes les explications achats nouveaux ailleurs, rachats de shorts ou ajustements de portefeuille. La détente des taux/dollar peut permettre une reprise sans démontrer un capital neuf généralisé. Cette ambiguïté empêche de confirmer l’asymétrie de positionnement à partir du prix seul.

Observation : 2026-09-25.

GLD vendredi résolu et stable; IAU historique incomplet, OI préliminaire/roll et COT mardi ne partagent pas exactement la même fenêtre.

Aucune confirmation de capital neuf ou de piège de positionnement.

Aligner flux émetteurs, OI finaux et prochains relevés; tester persistance après les catalyseurs.

## Demande structurelle et monnaie

L’accumulation officielle et les ETF d’août expliquent pourquoi le cas haussier long reste vivant. Leurs dates ne permettent pas d’en faire le moteur marginal de la semaine. La demande physique pourrait absorber une baisse ou amplifier une reprise, mais la prime comparable manque. Le soutien structurel limite une projection baissière sans fin; il ne neutralise pas automatiquement le choc de rendement réel.

## Les banques centrales achètent-elles selon des données déclarées ?

La compilation WGC des déclarations IMF/banques centrales indique +23 t nettes en juillet, dont Chine +20 t et Pologne +8 t, contre des ventes russes de 6 t. Ce soutien structurel est réel dans son périmètre déclaré, mais ancien pour la semaine à venir. Les estimations d’achats non déclarés et les intentions d’enquête ne sont pas ajoutées à ce total. Il n’établit pas un acheteur marginal certain face au PCE de mercredi.

Observation : Juillet 2026; publication 3 septembre.

Compilation détaillée obtenue jusqu’à juillet; aucune mise à jour mondiale comparable capturée au cutoff

Soutien d’horizon long, pas confirmation du timing hebdomadaire.

Actualiser IMF et déclarations nationales; distinguer dates de transaction, publication et estimations.

## La demande physique chinoise confirme-t-elle la direction ?

La page WGC de primes est datée du 21 mais ses données s’arrêtent au 18, et les valeurs ne sont pas extraites. Le tableau SGE du 24 est un prix de référence NYAuTN: ce n’est pas une prime physique spot comparable Londres/Shanghai. La demande d’importation ne peut pas être inférée de ce tableau de référence. Aucun chiffre de prime du 25 n’est inventé, ni aucune divergence COMEX/SGE proclamée.

Observation : Données disponibles jusqu’au 18/24 septembre selon source.

WGC graphique non extrait et décalé; SGE NYAuTN autre instrument/fixing; recherche secondaire sans benchmark aligné

La demande physique ne confirme ni ne réfute le biais tactique de manière contemporaine.

Obtenir SGE Au99.99/benchmark, spot Londres, FX même heure, fiscalité/frictions et calendrier local; rapporter imports séparément.

## Quelles actions observables soutiennent la diversification hors dollar ?

Les achats officiels déclarés documentent une diversification en or. Ils ne prouvent pas que chaque tonne ait été financée par une vente de dollars, ni qu’un recul hebdomadaire du dollar soit imminent. Aucun nouveau flux de réserves transfrontières synchronisé à la semaine n’est établi. Cette distinction évite de transformer un thème de long terme en justification universelle d’une hausse lundi.

Observation : Juillet–septembre 2026, sources structurelles.

## Le thème de dépréciation monétaire domine-t-il déjà ?

Le thème devient convaincant si des investisseurs délaissent durablement dette et monnaie pour l’or, ou si une réaction monétaire/fiscale nouvelle érode les rendements réels anticipés. Ici, la hausse du réel et la force hebdomadaire du dollar soutiennent davantage le coût d’opportunité. La pentification longue et les achats structurels gardent l’hypothèse ouverte; ils ne prouvent pas une domination fiscale nouvelle. Aucun programme nouveau de monétisation n’est établi dans cette collecte.

Observation : 2026-09-25.

Prix compatibles avec plusieurs mécanismes; aucune mesure directe du transfert ni annonce primaire de programme nouveau capturée

Empêche de traiter debasement comme moteur tactique dominant.

Vérifier annonces officielles et combinaison persistante dollar faible, flux Gold, taux/prime de terme et demande obligataire.

## Par rapport à la semaine précédente

Comparaison historique avec le dernier état archivé ; son checkpoint autonome n’a pas été récupéré.

Le mécanisme macro baissier subsiste indépendamment. Le règlement CME remplace le prix intraday antérieur: 4 321,20, au lieu de comparer un instantané 4 327 à un règlement.

Le réel finit à 2,83 %: +15 pb vendredi-sur-vendredi; le +21 pb antérieur était lundi–vendredi. Les deux fenêtres ne se contredisent pas.

Le solde GLD −0,90 million de parts est revérifié auprès de l’émetteur et conservé. Sa séquence mixte et la stabilité vendredi ne prouvent pas des ventes futures contraintes.

L’asymétrie de positionnement antérieure était baissière. Ici elle est non établie: une baisse passée du net COT et de GLD ne démontre pas la vulnérabilité résiduelle ni l’obligation de vendre.

L’asymétrie directionnelle est également non démontrée: direction de base, taille du mouvement passé et déséquilibre des surprises sont des jugements différents.

Les catalyseurs JOLTS/PCE/emploi restent futurs au cutoff; aucun résultat ne leur est attribué. Le risque diplomatique du week-end exige une branche explicite.

Les anciens jugements d’exécution ne gouvernent pas ce périmètre fondamental. Leur absence ne modifie pas l’éligibilité macro futures.

Le mécanisme des taux réels subsiste sous condition.

Le solde hebdomadaire des parts GLD a été revérifié auprès de l’émetteur.

Le positionnement baissier précédent n’est pas retenu faute de preuve du déséquilibre résiduel.

## 18 septembre — référence

Fin de semaine précédente: réel dix ans 2,68 %, nominal 5,01 %, GC décembre 4 424,90 selon historique indexé.

## 21 septembre — lundi

Le réel revient à 2,62 %. GLD perd 0,60 million de parts depuis vendredi. Le yuan montre une dynamique de politique locale.

## 22 septembre — mardi

Réel 2,63 %. Date de photographie du COT; ce relevé ne contient pas la réaction aux annonces ultérieures. GLD crée 0,20 million de parts.

## 23 septembre — mercredi

Flash PMI de septembre; hausse quotidienne du réel de 13 pb. GLD crée encore 0,30 million de parts. Adjudication et énergie empêchent d’attribuer tout le mouvement au seul PMI.

## 24 septembre — jeudi

Claims faibles, réel 2,85 %, adjudication sept ans vérifiée. GLD rachète 0,80 million de parts. Le crédit s’élargit légèrement; financement benchmark sans dislocation établie.

## 25 septembre — vendredi

Publication biens durables et Michigan, COT publié avec photographie mardi. Réel 2,83 %. GC décembre règle 4 321,20, en rebond quotidien; GLD stable. Les observations FX sont intraday.

## 26–27 septembre — contexte après clôture

Nouvelles diplomatiques iraniennes. Aucune réponse de marché postérieure à ces nouvelles n’est incluse dans la semaine observée.

## Géopolitique / énergie

Diplomatie iranienne non résolue; double canal refuge/inflation, réponse de marché à venir.

## Politique de change / intervention

Avertissements de coordination sur le yen et gestion du yuan; exceptions au dollar large.

## Fiscal / offre de dette

Sept ans vérifié, courbe longue en tête; prime de terme non isolée, aucune nouvelle monétisation établie.

## Liquidité / fin de trimestre

TGA en hausse, SOFR proche IORB au 24; financement du 25 et contraintes individuelles non observés.

## Crédit / contagion

Élargissement modeste jusqu’au jeudi; pas de preuve suffisante d’une crise générale.

## Clearing / marges / liquidation

Table de marges non extraite; aucun acteur Gold contraint identifié.

## Commerce / sommet international

Sommet et politique du yuan peuvent expliquer une partie du FX; aucun nouveau choc quantifié autonome ajouté.

## Sanctions / réglementation

Conditions sur blocus/sanctions évoquées dans la diplomatie; aucun changement juridique effectif vérifié, aucune hypothèse de levée déjà appliquée.

## Réserves / physique

Demande structurelle retardée; pas de confirmation physique synchronisée de la semaine.

## Rendement réel

Rendement d’une obligation indexée sur l’inflation. Pour l’or sans coupon, c’est une alternative rémunérée; il n’impose pas mécaniquement le sens du prix.

## Breakeven

Écart entre rendements nominal et indexé de maturité identique; combine inflation attendue et primes de marché.

## Asymétrie directionnelle

Déséquilibre entre les conséquences plausibles des surprises opposées; ce n’est pas le simple signe du scénario de base.

## Asymétrie de positionnement

Répartition des expositions et contraintes qui rend une réponse future plus probable ou plus déséquilibrée dans un sens. Un flux passé seul ne suffit pas.

## Intérêt ouvert (OI)

Nombre de contrats encore ouverts. Chaque contrat a un acheteur et un vendeur; sa hausse ne révèle pas à elle seule le camp initiateur.

## Roll / roulement

Déplacement d’une exposition d’une échéance vers une autre. Il peut gonfler l’OI décembre sans augmenter l’exposition agrégée.

## COT

Photographie hebdomadaire CFTC des positions par catégorie; date de mesure et date de publication diffèrent.

## SOFR / IORB

Taux de financement garanti au jour le jour / rémunération des réserves par la Fed. Leur écart est un indice partiel de conditions de financement.

## TGA / RRP

Compte du Trésor auprès de la Fed / opérations de reverse repo. Leur variation ne suffit pas à mesurer à elle seule toute la liquidité.

## Tail d’adjudication

Écart entre rendement adjugé et rendement when-issued juste avant l’enchère; non calculable ici sans cette seconde observation.
